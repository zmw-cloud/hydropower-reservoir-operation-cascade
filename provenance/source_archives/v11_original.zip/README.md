# XiaoWan-NuoZhaDu Cascade Reservoir Benchmark

> Version 11.0.0 is an isolated action-conditioned Double-DQN diagnostic built
> from V6. The policy still observes the same five state variables. Two
> normalized candidate target levels describe the action being scored by
> Q(s,a); they add no environmental information. Physical reward, one-step TD,
> gamma=0.97, learning rate=1e-5, lambda=4000, random windows and resets remain
> unchanged. See [`docs/dqn_action_conditioned_workflow.md`](docs/dqn_action_conditioned_workflow.md).

P4 双库一步完美预报 SDP 已作为独立算法模块接入，正式基准采用 1 m 状态/动作水位网格并保留 2 m 参数化能力。本月小湾天然入流类别和糯扎渡区间入流类别在动作前已知；Bellman continuation value 在连续期末库容处做双线性插值，两个水库的实际期末库容连续传到下一月。状态、概率、Bellman 递推、运行命令和输出审计说明见 [`docs/p4_sdp_design.md`](docs/p4_sdp_design.md)。

DDP正式物理配置采用1 m目标水位网格、连续库容插值continuation和状态并行求解。完整4,800个月时域仅在起点和最终月末分别固定1240/812 m；5—10月的月末动作分别受小湾1236 m、糯扎渡804 m上限约束，从而保证6—10月月初/运行期进入汛限范围。糯扎渡最大过机流量为3537 m3/s，装机容量上限仍为5850 MW；3537 m3/s不限制总下泄，超过过机能力的下泄计入弃水。

P4 双库一步完美预报 Double DQN V1 采用 5 维水位状态和由工程边界、配置步长动态生成的联合目标水位动作，并提供 development/final 训练、内部 validation 与逐 seed 独立 evaluation。正式 1 m 网格为 3600 个固定编号动作。DQN 行为选择和 Double-DQN target 统一使用共享物理环境生成的物理可达性与汛限水位联合掩码。基础设计见 [`docs/p4_dqn_design.md`](docs/p4_dqn_design.md)，mask 契约见 [`docs/feasible_action_mask.md`](docs/feasible_action_mask.md)，正式流程见 [`docs/dqn_1m_l9_workflow.md`](docs/dqn_1m_l9_workflow.md)。旧单库 DQN 只保留为参考。

旧 Run02 的 3000→5000 episode 续训记录见 [`docs/dqn_1m_budget_extension_workflow.md`](docs/dqn_1m_budget_extension_workflow.md)。该记录产生于 V6 掩码、汛限水位和违约库月惩罚之前，只保留作历史参考，checkpoint 不得用于 V6 恢复训练。

DQN final的baseline/drought/wet三场景独立评价、400行yearly汇总和DDP显式路径对比流程见 [`docs/dqn_1m_final_evaluation_workflow.md`](docs/dqn_1m_final_evaluation_workflow.md)。

P4 双库离散 PPO 使用同一物理环境、5 维状态和 1 m 的 3600 个固定编号联合动作。DQN/PPO 均优化“实际梯级发电量减统一违约水库-月惩罚”，再整体除以 7332.48 GWh。rollout、PPO update、validation 和 evaluation 复用同一物理可达性与汛限水位联合 mask，同时保留八环境同步采样和正确的 240 月人工截断 bootstrap。实现流程见 [`docs/ppo_1m_workflow.md`](docs/ppo_1m_workflow.md)，mask 契约见 [`docs/feasible_action_mask.md`](docs/feasible_action_mask.md)。

DQN/PPO V6 的 lambda=0 超参数阶段、统一候选范围、逐算法惩罚校正与代表解选择规则见 [`docs/dqn_ppo_v6_failure_penalty_experiment_matrix.md`](docs/dqn_ppo_v6_failure_penalty_experiment_matrix.md)。

DQN confirmation完成后的11组惩罚系数扫描、33个完整400年训练/评价任务及保证率—发电量绘图流程见 [`docs/dqn_1m_penalty_scan_workflow.md`](docs/dqn_1m_penalty_scan_workflow.md)。

DQN rank02在8e-4下出现后期validation振荡后，固定其余参数并比较3e-4、1e-4、3e-5、1e-5的收敛诊断流程见 [`docs/dqn_1m_learning_rate_workflow.md`](docs/dqn_1m_learning_rate_workflow.md)。

PPO正式L9的81组合加性预测、自动Top3 unseen和9个confirmation任务流程见 [`docs/ppo_1m_confirmation_workflow.md`](docs/ppo_1m_confirmation_workflow.md)。

This is an independent two-reservoir cascade project copied from the
single-reservoir benchmark only as a reference baseline. Its installable Python
package is `cascade_reservoir_benchmark`; new inputs, configuration, outputs,
documentation, and tests are isolated from the original project.

The P4 V1 implementation uses a current-information-only environment with
zero-delay routing. The NuoZhaDu natural-flow record is the P4 V1 interval
natural inflow and is added to routed XiaoWan release. Real energy experiments
remain intentionally blocked until NuoZhaDu machine parameters and XiaoWan
tailwater coverage are source-backed. See
`docs/audit/xiaowan_nuozhadu_data_audit.md` and `docs/p4_v1_design.md`.

## Retained Legacy Baseline

The copied single-reservoir reference implements the following policy families
under its original one-month-ahead forecast setting:

The remaining legacy sections are retained for source-code comparison only. Do
not run their scripts or treat their root-level inputs as cascade experiments.

- **DDP**: deterministic dynamic programming
- **SDP**: stochastic dynamic programming
- **ISO-SURF**: fitted monthly rule surfaces based on upstream DDP trajectories
- **DQN**: deep Q-network reinforcement learning

The project is intended for reproducible comparison of reservoir operation policies, sensitivity analysis under different inflow conditions, and adaptation to new reservoirs by replacing input data and reservoir-specific parameters.

## Retained Legacy Features

- Shared reservoir model for all algorithms, including level-storage conversion, tailwater estimation, and hydropower calculation.
- Standardized input layout for training inflows, evaluation inflows, reservoir settings, level-storage curves, tailwater curves, penalty coefficients, and algorithm experiment settings.
- Policy generation workflows for SDP, ISO-SURF, and DQN.
- Direct deterministic evaluation with DDP.
- Standardized evaluation outputs for cross-method comparison.
- Scenario-level and overall visualization scripts for generating figures and summary tables.
- Sphinx documentation under `docs/`.

## Repository Layout

```text
data/
  SynMonthlyInflow_train.xlsx
  SynMonthlyInflow_evaluation.xlsx
  reservoir_settings.txt
  level_storage_curve.csv
  tailwater_discharge_curve.csv
  penalty_settings.yaml
  experiment_settings.yaml
scripts/
  run_policy_generation.py
  run_evaluation.py
  run_visualization.py
src/reservoir_benchmark/
  shared/
  policy_generation/
    ddp/
    sdp/
    iso_surf/
    dqn/
  evaluation/
    ddp/
    sdp/
    iso_surf/
    dqn/
  visualization/
docs/
  source/
```

Generated artifacts are written under `outputs/`.

## Installation

Python 3.11 is recommended.

```bash
conda create -n reservoir_benchmark python=3.11 -y
conda activate reservoir_benchmark
python -m pip install -e .
```

To run DQN experiments, install the optional DQN dependencies:

```bash
python -m pip install -e ".[dqn]"
```

To run the self-implemented PyTorch PPO experiments:

```bash
python -m pip install -e ".[ppo]"
```

The completed preliminary 2 m sweep remains in `configs/dqn_sweeps/`.  The
formal 1 m L9 design, isolated outputs, post-processing, confirmation runs, and
manual submission commands are documented in
[`docs/dqn_1m_l9_workflow.md`](docs/dqn_1m_l9_workflow.md).

For development tools:

```bash
python -m pip install -e ".[dev]"
```

## Input Data

The benchmark reads inputs from the repository-level `data/` directory.

### Inflow Files

Training and evaluation inflows use the same Excel format:

- `data/SynMonthlyInflow_train.xlsx`
- `data/SynMonthlyInflow_evaluation.xlsx`

The loader skips the first column and treats the next 12 columns as monthly inflows from January to December. The recommended columns are:

```text
Year, Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec
```

Requirements:

- The 12 monthly columns must be numeric monthly mean inflows in `m3/s`.
- Missing values are not allowed.
- Negative values are not allowed.
- After the first column is skipped, exactly 12 monthly columns must remain.

### Reservoir Parameters

Reservoir parameters are stored in `data/reservoir_settings.txt`.

Required fields include:

- `dead_level`
- `normal_level`
- `initial_level`
- `max_turbine_discharge`
- `max_power`
- `firm_power`
- `power_coefficient`
- `delta_t_days`
- `inflow_upper_bound`

`inflow_upper_bound` is the single source of truth for the DQN inflow upper bound. It is read by the DQN environment and agent for the inflow component of the observation space and state normalization. Update this value when adapting the benchmark to a reservoir whose inflow range exceeds the configured bound.

### Curves

The level-storage curve is read from `data/level_storage_curve.csv` and must contain:

```text
water_level_m,storage_1e9_m3
```

The tailwater-discharge curve is read from `data/tailwater_discharge_curve.csv` and must contain:

```text
discharge_m3s,tail_water_level_m
```

### Penalty Settings

Penalty candidates are defined in `data/penalty_settings.yaml`, for example:

```yaml
ddp:
  candidates: [0, 1, 2]
sdp:
  candidates: [0, 1, 2]
iso_surf:
  candidates: [0, 1, 2]
dqn:
  candidates: [0, 5, 10]
```

### Experiment Settings

Algorithm-specific experiment parameters are defined in `data/experiment_settings.yaml`. This file keeps reusable engineering settings out of the runners and separates algorithm hyperparameters from reservoir physical parameters. It includes:

- SDP inflow discretization settings such as `sdp.n_inflow_classes` and `sdp.threshold`.
- ISO-SURF fitting settings such as `iso_surf.smoothing_factor`, `iso_surf.spline_order`, `iso_surf.grid_size`, `iso_surf.max_factor`, and `iso_surf.min_samples_spline`.
- DQN agent, network, training, seed, and progress-display settings under `dqn.agent`, `dqn.network`, `dqn.train`, `dqn.experiment`, and `dqn.display`.

## Quick Start

### 1. Generate Policies

```bash
python scripts/run_policy_generation.py
```

Note: the current `scripts/run_policy_generation.py` enables SDP policy generation by default. The ISO-SURF and DQN calls may need to be enabled in the script if a complete retraining run is required.

### 2. Run Evaluation

```bash
python scripts/run_evaluation.py
```

The evaluation script runs DDP, SDP, ISO-SURF, and DQN in sequence. DDP solves directly on the evaluation inflow. SDP, ISO-SURF, and DQN load previously generated policy artifacts.

### 3. Generate Figures

```bash
python scripts/run_visualization.py
```

Figures and summary files are written to `outputs/visualization/`.

## Workflow Overview

```text
Input data
   |
   +-- Training inflow + reservoir parameters
   |      + experiment settings
   |      -> SDP / ISO-SURF / DQN policy generation
   |
   +-- Evaluation inflow + reservoir parameters + generated policies
   |      -> DDP / SDP / ISO-SURF / DQN evaluation
   |
   +-- Evaluation CSV files
          -> visualization and summary reports
```

## Outputs

Policy artifacts:

```text
outputs/policy_generation/
  sdp/
    preprocessed/sdp_inflow_intervals_detailed.csv
    policy/sdp_train_lambda_*.xlsx
  iso_surf/
    preprocessed/iso_upstream_dp_train_lambda_*.csv
    policy/iso_surf_train_lambda_*.pkl
  dqn/
    policy/dqn_train_lambda_*.pth
```

Evaluation results:

```text
outputs/evaluation/
  ddp/ddp_eval_lambda_*.csv
  sdp/sdp_eval_lambda_*.csv
  iso_surf/iso_surf_eval_lambda_*.csv
  dqn/dqn_eval_lambda_*.csv
```

Visualization outputs:

```text
outputs/visualization/
```

## Adapting the Benchmark to a New Reservoir

To apply the repository to a new reservoir, update at least:

- `data/reservoir_settings.txt`
- `data/level_storage_curve.csv`
- `data/tailwater_discharge_curve.csv`
- `data/SynMonthlyInflow_train.xlsx`
- `data/SynMonthlyInflow_evaluation.xlsx`
- `data/penalty_settings.yaml`
- `data/experiment_settings.yaml`

Before rerunning the benchmark, check that:

- `dead_level <= initial_level <= normal_level`
- The level-storage curve covers the full operating range.
- Storage generally increases monotonically with water level.
- The tailwater curve covers the normal total-discharge range.
- Inflow units are `m3/s`.
- `inflow_upper_bound` in `data/reservoir_settings.txt` covers the expected inflow range used by the DQN observation space and normalization.
- `max_power` and `firm_power` are expressed in kW.

After changing the training inflow or reservoir physical parameters, regenerate SDP, ISO-SURF, and DQN policy artifacts. DDP does not require a pre-trained policy, but evaluation must be rerun.

## Documentation

The full documentation is in `docs/source/` and can be built with Sphinx:

```bash
python -m pip install -r docs/requirements.txt
python -m sphinx -b html docs/source docs/_build/html
```

Open the built documentation at:

```text
docs/_build/html/index.html
```

For the local browser build used in this workspace, the same site may also be generated under:

```text
docs_build/html/index.html
```

## Notes and Known Assumptions

- Input paths currently point to the repository-level `data/` directory.
- DDP, SDP, and ISO-SURF use 1 m water-level discretization by default.
- SDP inflow discretization is configured by `sdp.n_inflow_classes` in `data/experiment_settings.yaml`.
- The DQN observation space and normalization use `inflow_upper_bound` from `data/reservoir_settings.txt`; this replaces the former hard-coded `5000.0 m3/s` inflow upper-bound assumption.
- Trained DQN models can be large and are ignored by default through `*.pth` and `*.pt` patterns.

## License

This project is released under the MIT License. See `LICENSE` for details.
