"""Reproducibly audit the copied XiaoWan-NuoZhaDu source files.

Raw files are read from ``data/xiaowan_nuozhadu/raw`` and are never altered.
Normalized data and audit outputs are written only inside this cascade project.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

import numpy as np
import pandas as pd
from docx import Document


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "xiaowan_nuozhadu"
RAW = DATA / "raw"
OUT = ROOT / "outputs" / "xiaowan_nuozhadu" / "audit"
DOCS = ROOT / "docs" / "audit"
STATIONS = ("xiaowan", "nuozhadu")
MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


def one_file(pattern: str) -> Path:
    files = sorted(RAW.glob(pattern))
    if len(files) != 1:
        raise FileNotFoundError(f"Expected one file matching {pattern!r}; found {files!r}.")
    return files[0]


def stats(values: pd.Series) -> dict[str, float | int]:
    values = values.dropna().astype(float)
    q = values.quantile([0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99])
    return {
        "count": int(len(values)), "mean": float(values.mean()), "std": float(values.std()),
        "min": float(values.min()), "p01": float(q.loc[0.01]), "p05": float(q.loc[0.05]),
        "p25": float(q.loc[0.25]), "p50": float(q.loc[0.5]), "p75": float(q.loc[0.75]),
        "p95": float(q.loc[0.95]), "p99": float(q.loc[0.99]), "max": float(values.max()),
    }


def robust_month_flags(frame: pd.DataFrame) -> pd.Series:
    flags = pd.Series(False, index=frame.index)
    for month, group in frame.groupby("month"):
        values = group["inflow_m3s"].dropna()
        median = values.median()
        mad = (values - median).abs().median()
        if mad > 0.0:
            flags.loc[values.index] = (0.6745 * (values - median) / mad).abs() > 3.5
    return flags


def audit_station(source: Path, sheet: str, station: str) -> tuple[pd.DataFrame, dict]:
    raw = pd.read_excel(source, sheet_name=sheet)
    if raw.shape[1] < 2:
        raise ValueError(f"{source.name}:{sheet} has fewer than two columns.")
    frame = pd.DataFrame({
        "date": pd.to_datetime(raw.iloc[:, 0], errors="coerce"),
        "inflow_m3s": pd.to_numeric(raw.iloc[:, 1], errors="coerce"),
    })
    frame["year"] = frame.date.dt.year
    frame["month"] = frame.date.dt.month
    frame["robust_outlier_flag"] = robust_month_flags(frame)
    frame["monthly_volume_1e9m3"] = (
        frame.inflow_m3s * frame.date.dt.days_in_month * 86400.0 / 1.0e9
    )

    dates = frame.date.dropna()
    expected = pd.date_range(dates.min(), dates.max(), freq="MS")
    observed = pd.DatetimeIndex(dates.unique())
    annual = frame.groupby("year").monthly_volume_1e9m3.sum(min_count=12)
    annual_summary = stats(annual)
    annual_summary["coefficient_of_variation"] = (
        annual_summary["std"] / annual_summary["mean"]
        if annual_summary["mean"] else None
    )
    monthly = []
    for month in range(1, 13):
        row = {"station": station, "month": month, "month_name": MONTHS[month - 1]}
        row.update({f"{key}_m3s": value for key, value in stats(frame.loc[frame.month == month, "inflow_m3s"]).items()})
        row["robust_outlier_count"] = int(frame.loc[frame.month == month, "robust_outlier_flag"].sum())
        monthly.append(row)
    pd.DataFrame(monthly).to_csv(OUT / f"{station}_monthly_statistics.csv", index=False)
    annual.rename("annual_volume_1e9m3").reset_index().to_csv(OUT / f"{station}_annual_volumes.csv", index=False)
    frame.to_csv(OUT / f"{station}_monthly_records_audited.csv", index=False)
    outliers = frame.loc[frame.robust_outlier_flag, ["date", "inflow_m3s", "month"]].copy()
    outliers.insert(0, "station", station)
    outliers.to_csv(OUT / f"{station}_robust_outlier_flags.csv", index=False)
    summary = {
        "sheet": sheet, "rows": int(len(frame)), "start": dates.min().strftime("%Y-%m-%d"),
        "end": dates.max().strftime("%Y-%m-%d"), "missing_dates": [d.strftime("%Y-%m-%d") for d in expected.difference(observed)],
        "duplicate_date_count": int(frame.date.duplicated(keep=False).sum()),
        "invalid_date_count": int(frame.date.isna().sum()), "missing_inflow_count": int(frame.inflow_m3s.isna().sum()),
        "negative_inflow_count": int((frame.inflow_m3s < 0.0).sum()), "robust_outlier_count": int(frame.robust_outlier_flag.sum()),
        "robust_outliers": [{"date": item.date.strftime("%Y-%m-%d"), "inflow_m3s": float(item.inflow_m3s)} for item in outliers.itertuples(index=False)],
        "overall_m3s": stats(frame.inflow_m3s), "annual_volume_1e9m3": annual_summary,
    }
    return frame, summary


def normalize_curves() -> dict:
    storage_file = one_file("4-*.xlsx")
    tailwater_file = one_file("7-*.xlsx")
    storage_book = pd.ExcelFile(storage_file)
    tailwater_book = pd.ExcelFile(tailwater_file)
    if len(storage_book.sheet_names) != 2 or len(tailwater_book.sheet_names) != 2:
        raise ValueError("Each curve workbook must have two station sheets.")
    summaries = {}
    for index, station in enumerate(STATIONS):
        station_dir = DATA / f"reservoir_{index + 1}"
        station_dir.mkdir(parents=True, exist_ok=True)
        s_raw = pd.read_excel(storage_file, sheet_name=storage_book.sheet_names[index])
        storage = pd.DataFrame({
            "water_level_m": pd.to_numeric(s_raw.iloc[:, 0], errors="coerce"),
            "storage_1e9_m3": pd.to_numeric(s_raw.iloc[:, 1], errors="coerce") / 100000.0,
        }).dropna()
        storage.to_csv(station_dir / "level_storage_curve.csv", index=False)
        t_raw = pd.read_excel(tailwater_file, sheet_name=tailwater_book.sheet_names[index])
        tailwater = pd.DataFrame({
            "discharge_m3s": pd.to_numeric(t_raw.iloc[:, 1], errors="coerce"),
            "tailwater_level_m": pd.to_numeric(t_raw.iloc[:, 0], errors="coerce"),
        }).dropna()
        tailwater.to_csv(station_dir / "tailwater_discharge_curve.csv", index=False)
        summaries[station] = {
            "storage_source_sheet": storage_book.sheet_names[index],
            "tailwater_source_sheet": tailwater_book.sheet_names[index],
            "storage_source_unit": "10000 m3", "storage_conversion": "divide by 100000",
            "level_range_m": [float(storage.water_level_m.min()), float(storage.water_level_m.max())],
            "storage_monotonic": bool(storage.storage_1e9_m3.is_monotonic_increasing),
            "tailwater_discharge_range_m3s": [float(tailwater.discharge_m3s.min()), float(tailwater.discharge_m3s.max())],
            "tailwater_discharge_monotonic": bool(tailwater.discharge_m3s.is_monotonic_increasing),
            "tailwater_level_monotonic": bool(tailwater.tailwater_level_m.is_monotonic_increasing),
        }
    return summaries


def first_number(value: str) -> float | None:
    match = re.search(r"-?\d+(?:\.\d+)?", value)
    return float(match.group()) if match else None


def parameter_inventory() -> pd.DataFrame:
    source = one_file("*docx")
    tables = Document(source).tables
    if len(tables) < 4:
        raise ValueError(f"Expected characteristic tables in {source.name}.")
    rows = []

    def add(station: str, parameter: str, unit: str, table: int, row: int, col: int) -> None:
        value = tables[table].cell(row, col).text.strip()
        rows.append({"station": station, "parameter": parameter, "value": first_number(value), "unit": unit,
                     "source": f"{source.name}: table {table}, row {row}, column {col}", "source_text": value.replace("\n", " / "), "status": "available"})

    for parameter, row, col, unit in (("check_flood_level", 1, 1, "m"), ("design_flood_level", 2, 1, "m"), ("normal_level", 3, 1, "m"), ("dead_level", 5, 1, "m"), ("check_flood_discharge", 1, 3, "m3/s"), ("design_flood_discharge", 2, 3, "m3/s")):
        add("xiaowan", parameter, unit, 0, row, col)
    flood_text = tables[0].cell(4, 1).text.strip()
    flood_values = re.findall(r"-?\d+(?:\.\d+)?", flood_text)
    for parameter, value in (("flood_limit_level_pre_nuozhadu", flood_values[0] if flood_values else None), ("flood_limit_level_post_nuozhadu", flood_values[1] if len(flood_values) > 1 else None)):
        rows.append({"station": "xiaowan", "parameter": parameter, "value": float(value) if value else None, "unit": "m", "source": f"{source.name}: table 0, row 4, column 1", "source_text": flood_text.replace("\n", " / "), "status": "available"})
    for parameter, row in (("check_flood_level", 1), ("design_flood_level", 2), ("normal_level", 3), ("flood_limit_level_p1", 4), ("flood_limit_level", 5), ("dead_level", 6)):
        add("nuozhadu", parameter, "m", 3, row, 2)
    missing = ("max_turbine_discharge", "installed_capacity", "max_power", "firm_power", "power_coefficient", "turbine_efficiency", "initial_level", "upstream_backwater_relation")
    for station in STATIONS:
        rows.extend({"station": station, "parameter": item, "value": None, "unit": "", "source": "not present in supplied files", "source_text": "", "status": "missing"} for item in missing)
    return pd.DataFrame(rows)


def cross_station(xiaowan: pd.DataFrame, nuozhadu: pd.DataFrame) -> dict:
    joined = xiaowan[["date", "inflow_m3s", "monthly_volume_1e9m3"]].merge(nuozhadu[["date", "inflow_m3s", "monthly_volume_1e9m3"]], on="date", suffixes=("_xiaowan", "_nuozhadu"))
    joined["natural_difference_proxy_m3s"] = joined.inflow_m3s_nuozhadu - joined.inflow_m3s_xiaowan
    joined.to_csv(OUT / "aligned_natural_inflows.csv", index=False)
    annual = joined.assign(year=joined.date.dt.year).groupby("year")[["monthly_volume_1e9m3_xiaowan", "monthly_volume_1e9m3_nuozhadu"]].sum()
    annual.to_csv(OUT / "aligned_annual_volumes.csv")
    lags = []
    for lag in range(-6, 7):
        pair = pd.DataFrame({"x": joined.inflow_m3s_xiaowan, "n": joined.inflow_m3s_nuozhadu.shift(-lag)}).dropna()
        lags.append({"lag_months": lag, "definition": "corr(xiaowan_t,nuozhadu_t_plus_lag)", "pearson": float(pair.corr().iloc[0, 1]), "spearman": float(pair.corr(method="spearman").iloc[0, 1]), "sample_size": int(len(pair))})
    pd.DataFrame(lags).to_csv(OUT / "monthly_lag_correlations.csv", index=False)
    return {"same_month_pearson": float(joined[["inflow_m3s_xiaowan", "inflow_m3s_nuozhadu"]].corr().iloc[0, 1]), "same_month_spearman": float(joined[["inflow_m3s_xiaowan", "inflow_m3s_nuozhadu"]].corr(method="spearman").iloc[0, 1]), "annual_pearson": float(annual.corr().iloc[0, 1]), "annual_spearman": float(annual.corr(method="spearman").iloc[0, 1]), "natural_difference_proxy_min_m3s": float(joined.natural_difference_proxy_m3s.min()), "natural_difference_proxy_negative_count": int((joined.natural_difference_proxy_m3s < 0.0).sum())}


def curve_coverage(curves: dict, xiaowan: pd.DataFrame, nuozhadu: pd.DataFrame) -> list[dict]:
    records = []
    for station, frame in (("xiaowan", xiaowan), ("nuozhadu", nuozhadu)):
        tailwater_min, tailwater_max = curves[station]["tailwater_discharge_range_m3s"]
        natural_min, natural_max = float(frame.inflow_m3s.min()), float(frame.inflow_m3s.max())
        records.append({
            "station": station,
            "tailwater_discharge_min_m3s": tailwater_min,
            "tailwater_discharge_max_m3s": tailwater_max,
            "observed_natural_inflow_min_m3s": natural_min,
            "observed_natural_inflow_max_m3s": natural_max,
            "covers_observed_natural_range": tailwater_min <= natural_min and tailwater_max >= natural_max,
            "interpretation": "Observed natural flow is only a screening comparator; release coverage also requires source-backed turbine and release limits.",
        })
    pd.DataFrame(records).to_csv(OUT / "tailwater_curve_coverage_screen.csv", index=False)
    return records


def report(summary: dict) -> str:
    x, n, c, curves = summary["inflows"]["xiaowan"], summary["inflows"]["nuozhadu"], summary["correlations"], summary["curves"]
    coverage = {item["station"]: item for item in summary["tailwater_coverage"]}
    return f"""# XiaoWan-NuoZhaDu Data Audit

## Audit result

Both supplied natural-runoff sheets cover {x['rows']} monthly records from {x['start']} through {x['end']}. XiaoWan: missing dates {len(x['missing_dates'])}, duplicate dates {x['duplicate_date_count']}, missing flows {x['missing_inflow_count']}, negative flows {x['negative_inflow_count']}, robust review flags {x['robust_outlier_count']}. NuoZhaDu: missing dates {len(n['missing_dates'])}, duplicate dates {n['duplicate_date_count']}, missing flows {n['missing_inflow_count']}, negative flows {n['negative_inflow_count']}, robust review flags {n['robust_outlier_count']}.

The flagged observations are retained rather than removed: XiaoWan {x['robust_outliers']}; NuoZhaDu {n['robust_outliers']}. They are month-specific modified-z-score review cues, not demonstrated source errors.

Monthly distribution tables, annual volumes, and all review flags are written to `outputs/xiaowan_nuozhadu/audit/`. Annual volumes use each actual calendar-month duration. XiaoWan mean annual volume is {x['annual_volume_1e9m3']['mean']:.3f} `10^9 m3` (CV {x['annual_volume_1e9m3']['coefficient_of_variation']:.3f}); NuoZhaDu mean is {n['annual_volume_1e9m3']['mean']:.3f} `10^9 m3` (CV {n['annual_volume_1e9m3']['coefficient_of_variation']:.3f}).

## Coupling interpretation

The source workbook labels both sheets as natural monthly runoff. Same-month Pearson/Spearman correlations are {c['same_month_pearson']:.4f}/{c['same_month_spearman']:.4f}; annual-volume correlations are {c['annual_pearson']:.4f}/{c['annual_spearman']:.4f}. For P4 V1, the supplied NuoZhaDu series is the user-confirmed interval natural inflow `I2_local`, so the cascade uses `I2_effective = I2_local + Q1_total`. The natural-difference statistic is retained only as a hydrological diagnostic and is not used to transform the supplied input.

P4 v1 declares zero propagation delay: `routed(Q1_total_t) = Q1_total_t`. The runtime interface reserves routing for later delay methods. It uses independent tailwater curves and records no upstream backwater relation. XiaoWan machine values are inherited from the senior student's benchmark when the raw engineering files are silent; NuoZhaDu machine values remain unresolved.

## Curves and parameters

The capacity headers use `10000 m3`; normalized capacity is therefore `capacity / 100000` in `10^9 m3`. XiaoWan level-storage coverage is {curves['xiaowan']['level_range_m'][0]:.0f}-{curves['xiaowan']['level_range_m'][1]:.0f} m and NuoZhaDu coverage is {curves['nuozhadu']['level_range_m'][0]:.0f}-{curves['nuozhadu']['level_range_m'][1]:.0f} m. Both storage curves and both rating curves are monotonic. The runtime P4 V1 rule fits a fourth-order polynomial to each tailwater curve; XiaoWan's two engineering high-flow anchors are included in that fit, and out-of-range values are reported as polynomial extrapolation.

XiaoWan's measured tailwater rating curve spans {coverage['xiaowan']['tailwater_discharge_min_m3s']:.0f}-{coverage['xiaowan']['tailwater_discharge_max_m3s']:.0f} `m3/s`, while its observed natural flow spans {coverage['xiaowan']['observed_natural_inflow_min_m3s']:.0f}-{coverage['xiaowan']['observed_natural_inflow_max_m3s']:.0f} `m3/s`. The engineering characteristic table adds high-flow anchors of 15666 `m3/s` at downstream level 1012.71 m (design flood) and 20683 `m3/s` at 1016.64 m (check flood). Total release may exceed turbine flow through spill; define a monotone interpolation or fit across the 2100-15666 `m3/s` gap. NuoZhaDu's rating curve spans {coverage['nuozhadu']['tailwater_discharge_min_m3s']:.0f}-{coverage['nuozhadu']['tailwater_discharge_max_m3s']:.0f} `m3/s` and covers its observed natural-flow screening range, but cascade effective inflow can be larger after routing. Neither result proves operational release coverage without source-backed maximum turbine and release limits.

`parameter_inventory.csv` describes only the four supplied raw files, so it lists source-backed characteristic levels and explicit nulls for machine parameters. `docs/audit/parameter_reconciliation.md` separately records the adopted XiaoWan values inherited from the senior benchmark; these are references, not newly extracted engineering facts. No value from the user's exploratory code overrides a conflicting senior-benchmark value.

## Data-extension recommendation

Use the 31 observed years first for transparent baseline and hold out complete hydrological years. For longer training, generate independent joint sequences from a fitted multivariate seasonal model with annual regime/block resampling, preserving paired XiaoWan-NuoZhaDu anomalies, wet/dry-year persistence, and extremal blocks. Do not tile the 31-year sequence or let a historical year occur in both training and evaluation. Bootstrap alone preserves events but has limited novelty; independent marginal monthly synthesis loses spatial and annual dependence. The joint generator should be validated against every output in this audit before supporting the 400-year experiment.
"""


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    DOCS.mkdir(parents=True, exist_ok=True)
    inflow = one_file("1-*.xlsx")
    book = pd.ExcelFile(inflow)
    if len(book.sheet_names) != 2:
        raise ValueError("The inflow workbook must have two station sheets.")
    xiaowan, x_summary = audit_station(inflow, book.sheet_names[0], "xiaowan")
    nuozhadu, n_summary = audit_station(inflow, book.sheet_names[1], "nuozhadu")
    inventory = parameter_inventory()
    inventory.to_csv(OUT / "parameter_inventory.csv", index=False)
    curves = normalize_curves()
    summary = {"inflow_source": inflow.name, "inflows": {"xiaowan": x_summary, "nuozhadu": n_summary}, "correlations": cross_station(xiaowan, nuozhadu), "curves": curves, "tailwater_coverage": curve_coverage(curves, xiaowan, nuozhadu), "parameter_inventory": {"available": int((inventory.status == "available").sum()), "missing": int((inventory.status == "missing").sum())}}
    (OUT / "audit_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    (DOCS / "xiaowan_nuozhadu_data_audit.md").write_text(report(summary), encoding="utf-8")
    print(f"Audit complete: {OUT}")


if __name__ == "__main__":
    main()
