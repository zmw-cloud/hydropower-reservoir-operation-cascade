"""Run the 11-point, 1 m SDP failed-station-month penalty experiment."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
import json
import math
from pathlib import Path
import subprocess
import sys

import matplotlib.pyplot as plt
import pandas as pd
import yaml


ROOT = Path(__file__).resolve().parents[1]
PENALTY_CONFIG = ROOT / "data" / "penalty_settings.yaml"
SINGLE_RUNNER = ROOT / "scripts" / "run_p4_v1_sdp.py"
OUTPUT_ROOT = (
    ROOT
    / "outputs"
    / "xiaowan_nuozhadu"
    / "evaluation"
    / "sdp"
    / "1m"
    / "bilinear_continuation"
)
SWEEP_OUTPUT_DIR = OUTPUT_ROOT / "failure_penalty_sweep"
WORKER_LOG_DIR = SWEEP_OUTPUT_DIR / "logs"

EXPECTED_CANDIDATES = (
    0.0,
    100.0,
    200.0,
    300.0,
    400.0,
    500.0,
    600.0,
    700.0,
    800.0,
    900.0,
    1000.0,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--force",
        action="store_true",
        help="Rerun penalties whose complete 4,800-month evaluation JSON already exists.",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=4,
        help="Number of independent penalty runs to execute concurrently (default: 4).",
    )
    parser.add_argument(
        "--verbose-solver",
        action="store_true",
        help="Write every monthly Bellman progress message to each penalty's separate log.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate configuration and print all 11 commands without training.",
    )
    args = parser.parse_args()
    if args.workers <= 0:
        parser.error("--workers must be positive.")
    return args


def format_penalty_label(value: float) -> str:
    value = float(value)
    if not math.isfinite(value) or value < 0.0:
        raise ValueError("SDP failure penalty must be finite and nonnegative.")
    return f"{value:.15g}".replace(".", "p")


def load_candidates() -> tuple[float, ...]:
    settings = yaml.safe_load(PENALTY_CONFIG.read_text(encoding="utf-8"))
    try:
        candidates = tuple(float(value) for value in settings["sdp"]["candidates"])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError("penalty_settings.yaml must contain numeric sdp.candidates.") from exc
    if candidates != EXPECTED_CANDIDATES:
        raise ValueError(
            "SDP failure penalties do not exactly match the fixed 11-point experiment."
        )
    return candidates


def evaluation_summary_path(failure_penalty_gwh: float) -> Path:
    label = format_penalty_label(failure_penalty_gwh)
    stem = (
        "sdp_p4_v4_one_step_forecast_bilinear_continuation_"
        f"evaluation_400y_1m_failure_count_penalty_{label}"
    )
    return OUTPUT_ROOT / f"failure_penalty_{label}" / f"{stem}.json"


def load_completed_summary(path: Path, failure_penalty_gwh: float) -> dict | None:
    if not path.exists():
        return None
    try:
        summary = json.loads(path.read_text(encoding="utf-8"))
        reliability = summary["firm_power_reliability"]
        valid = (
            int(summary["months"]) == 4800
            and float(summary["grid_step_m"]) == 1.0
            and float(summary["firm_power_failure_penalty_gwh"])
            == float(failure_penalty_gwh)
            and all(
                math.isfinite(float(reliability[name]))
                and 0.0 <= float(reliability[name]) <= 1.0
                for name in ("xiaowan", "nuozhadu")
            )
        )
    except (KeyError, TypeError, ValueError, json.JSONDecodeError):
        return None
    return summary if valid else None


def sensitivity_row(summary: dict, failure_penalty_gwh: float) -> dict:
    reliability = summary["firm_power_reliability"]
    xiaowan = float(reliability["xiaowan"])
    nuozhadu = float(reliability["nuozhadu"])
    minimum = min(xiaowan, nuozhadu)
    return {
        "failure_penalty_gwh": float(failure_penalty_gwh),
        "xiaowan_reliability": xiaowan,
        "nuozhadu_reliability": nuozhadu,
        "min_station_reliability": minimum,
        "xiaowan_reliability_pct": 100.0 * xiaowan,
        "nuozhadu_reliability_pct": 100.0 * nuozhadu,
        "min_station_reliability_pct": 100.0 * minimum,
        "both_stations_ge_90pct": bool(xiaowan >= 0.9 and nuozhadu >= 0.9),
        "penalized_objective_gwh": float(summary["objective_gwh"]),
        "xiaowan_failed_months": int(
            summary["firm_power_failed_months"]["xiaowan"]
        ),
        "nuozhadu_failed_months": int(
            summary["firm_power_failed_months"]["nuozhadu"]
        ),
        "total_failed_station_months": int(
            summary["total_failed_station_months"]
        ),
        "joint_firm_power_satisfaction_pct": 100.0
        * float(summary["joint_firm_power_satisfaction"]),
        "total_generation_gwh": float(summary["total_generation_gwh"]),
        "evaluation_json": str(evaluation_summary_path(failure_penalty_gwh)),
    }


def write_aggregate(rows: list[dict], candidates: tuple[float, ...]) -> None:
    if not rows:
        return
    SWEEP_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(rows).sort_values("failure_penalty_gwh").reset_index(drop=True)
    for metric in (
        "xiaowan_reliability_pct",
        "nuozhadu_reliability_pct",
        "min_station_reliability_pct",
    ):
        frame[f"delta_{metric}_points_vs_previous_penalty"] = frame[metric].diff()

    csv_path = SWEEP_OUTPUT_DIR / "sdp_failure_penalty_summary.csv"
    frame.to_csv(csv_path, index=False, encoding="utf-8-sig")

    qualifying = frame.loc[
        frame["both_stations_ge_90pct"], "failure_penalty_gwh"
    ]
    experiment_summary = {
        "method": "SDP",
        "water_level_step_m": 1.0,
        "candidate_count": len(candidates),
        "completed_count": len(frame),
        "candidate_failure_penalties_gwh": list(candidates),
        "completed_failure_penalties_gwh": frame[
            "failure_penalty_gwh"
        ].tolist(),
        "first_failure_penalty_both_stations_ge_90pct": (
            None if qualifying.empty else float(qualifying.iloc[0])
        ),
        "platform_detection": (
            "not_automated; inspect the reliability curves and adjacent percentage-point changes"
        ),
        "summary_csv": str(csv_path),
        "plot_png": str(SWEEP_OUTPUT_DIR / "sdp_failure_penalty.png"),
    }
    json_path = SWEEP_OUTPUT_DIR / "sdp_failure_penalty_summary.json"
    json_path.write_text(
        json.dumps(experiment_summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    figure, axis = plt.subplots(figsize=(10.5, 6.2))
    axis.plot(
        frame["failure_penalty_gwh"],
        frame["xiaowan_reliability_pct"],
        marker="o",
        markersize=3.5,
        linewidth=1.5,
        label="Xiaowan",
    )
    axis.plot(
        frame["failure_penalty_gwh"],
        frame["nuozhadu_reliability_pct"],
        marker="s",
        markersize=3.5,
        linewidth=1.5,
        label="Nuozhadu",
    )
    axis.plot(
        frame["failure_penalty_gwh"],
        frame["min_station_reliability_pct"],
        color="black",
        linestyle="--",
        linewidth=1.8,
        label="min(Xiaowan, Nuozhadu)",
    )
    axis.axhline(90.0, color="tab:red", linestyle=":", linewidth=1.5, label="90%")
    axis.set_xlabel("Failure penalty (GWh per failed station-month)")
    axis.set_ylabel("Firm-power reliability (%)")
    axis.set_title("SDP 1 m failure-count penalty on the 400-year evaluation set")
    axis.grid(True, which="both", alpha=0.25)
    axis.legend()
    figure.tight_layout()
    figure.savefig(SWEEP_OUTPUT_DIR / "sdp_failure_penalty.png", dpi=220)
    plt.close(figure)


def single_run_command(failure_penalty_gwh: float, *, verbose_solver: bool) -> list[str]:
    command = [
        sys.executable,
        str(SINGLE_RUNNER),
        "--stage",
        "all",
        "--water-level-step",
        "1.0",
        "--failure-penalty-gwh",
        f"{failure_penalty_gwh:.15g}",
        "--skip-policy-csv",
        "--reuse-probabilities",
    ]
    if not verbose_solver:
        command.append("--quiet")
    return command


def prepare_probabilities(*, dry_run: bool) -> None:
    """Create and validate the shared probability artifacts exactly once."""
    command = [
        sys.executable,
        str(SINGLE_RUNNER),
        "--stage",
        "preprocess",
        "--water-level-step",
        "1.0",
        "--failure-penalty-gwh",
        "0",
        "--quiet",
    ]
    if dry_run:
        print("[preprocess] " + " ".join(command), flush=True)
        return
    print("Preparing one shared set of monthly inflow probabilities.", flush=True)
    subprocess.run(command, cwd=ROOT, check=True)


def run_candidate(
    position: int,
    candidate_count: int,
    failure_penalty_gwh: float,
    *,
    verbose_solver: bool,
) -> dict:
    label = format_penalty_label(failure_penalty_gwh)
    WORKER_LOG_DIR.mkdir(parents=True, exist_ok=True)
    log_path = WORKER_LOG_DIR / f"failure_penalty_{label}.log"
    command = single_run_command(
        failure_penalty_gwh,
        verbose_solver=verbose_solver,
    )
    with log_path.open("a", encoding="utf-8", buffering=1) as stream:
        stream.write(
            f"\n[{datetime.now().isoformat(timespec='seconds')}] "
            f"starting failure_penalty_gwh={failure_penalty_gwh:g}\n"
        )
        stream.write("command: " + " ".join(command) + "\n")
        completed_process = subprocess.run(
            command,
            cwd=ROOT,
            stdout=stream,
            stderr=subprocess.STDOUT,
        )
        stream.write(
            f"[{datetime.now().isoformat(timespec='seconds')}] "
            f"returncode={completed_process.returncode}\n"
        )
    if completed_process.returncode != 0:
        raise RuntimeError(
            f"Failure penalty {failure_penalty_gwh:g} failed with return code "
            f"{completed_process.returncode}; see {log_path}."
        )
    summary_path = evaluation_summary_path(failure_penalty_gwh)
    completed = load_completed_summary(summary_path, failure_penalty_gwh)
    if completed is None:
        raise RuntimeError(
            f"Failure penalty {failure_penalty_gwh:g} finished without a valid evaluation summary: "
            f"{summary_path}"
        )
    row = sensitivity_row(completed, failure_penalty_gwh)
    row["worker_log"] = str(log_path)
    row["sweep_position"] = int(position)
    row["sweep_candidate_count"] = int(candidate_count)
    return row


def main() -> None:
    args = parse_args()
    candidates = load_candidates()
    print(
        f"SDP failure-penalty sweep: {len(candidates)} candidates, 1 m grid, "
        f"up to {args.workers} concurrent workers, followed by 4,800-month evaluation.",
        flush=True,
    )
    rows: list[dict] = []
    pending: list[tuple[int, float]] = []
    for position, failure_penalty_gwh in enumerate(candidates, start=1):
        summary_path = evaluation_summary_path(failure_penalty_gwh)
        completed = None if args.force else load_completed_summary(
            summary_path, failure_penalty_gwh
        )
        if completed is not None:
            row = sensitivity_row(completed, failure_penalty_gwh)
            rows.append(row)
            print(
                f"[{position:02d}/{len(candidates)}] "
                f"failure_penalty_gwh={failure_penalty_gwh:g}: "
                "complete output found, skipping",
                flush=True,
            )
        else:
            pending.append((position, failure_penalty_gwh))

    if args.dry_run:
        prepare_probabilities(dry_run=True)
        for position, failure_penalty_gwh in pending:
            print(
                f"[{position:02d}/{len(candidates)}] "
                f"failure_penalty_gwh={failure_penalty_gwh:g}: "
                + " ".join(
                    single_run_command(
                        failure_penalty_gwh,
                        verbose_solver=args.verbose_solver,
                    )
                ),
                flush=True,
            )
        print("Dry run complete: configuration is valid; no experiment was executed.")
        return

    if rows:
        write_aggregate(rows, candidates)
    if pending:
        prepare_probabilities(dry_run=False)
        worker_count = min(int(args.workers), len(pending))
        print(
            f"Launching {len(pending)} pending penalties with {worker_count} workers. "
            f"Per-penalty logs: {WORKER_LOG_DIR}",
            flush=True,
        )
        failures: list[str] = []
        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            future_metadata = {}
            for position, failure_penalty_gwh in pending:
                print(
                    f"[{position:02d}/{len(candidates)}] "
                    f"failure_penalty_gwh={failure_penalty_gwh:g}: queued",
                    flush=True,
                )
                future = executor.submit(
                    run_candidate,
                    position,
                    len(candidates),
                    failure_penalty_gwh,
                    verbose_solver=args.verbose_solver,
                )
                future_metadata[future] = (position, failure_penalty_gwh)

            for future in as_completed(future_metadata):
                position, failure_penalty_gwh = future_metadata[future]
                try:
                    row = future.result()
                except Exception as exc:
                    message = (
                        f"[{position:02d}/{len(candidates)}] "
                        f"failure_penalty_gwh={failure_penalty_gwh:g}: "
                        f"FAILED: {exc}"
                    )
                    failures.append(message)
                    print(message, flush=True)
                    continue
                rows.append(row)
                write_aggregate(rows, candidates)
                print(
                    f"[{position:02d}/{len(candidates)}] "
                    f"failure_penalty_gwh={failure_penalty_gwh:g}: "
                    f"Xiaowan={row['xiaowan_reliability_pct']:.3f}%, "
                    f"Nuozhadu={row['nuozhadu_reliability_pct']:.3f}%, "
                    f"min={row['min_station_reliability_pct']:.3f}%",
                    flush=True,
                )
        if failures:
            raise RuntimeError(
                f"{len(failures)} failure-penalty runs failed.\n"
                + "\n".join(failures)
            )

    write_aggregate(rows, candidates)
    print(f"Sweep complete: {len(rows)}/{len(candidates)} penalties.", flush=True)
    print(
        f"Summary CSV: {SWEEP_OUTPUT_DIR / 'sdp_failure_penalty_summary.csv'}",
        flush=True,
    )
    print(
        f"Summary JSON: {SWEEP_OUTPUT_DIR / 'sdp_failure_penalty_summary.json'}",
        flush=True,
    )
    print(
        f"Reliability plot: {SWEEP_OUTPUT_DIR / 'sdp_failure_penalty.png'}",
        flush=True,
    )


if __name__ == "__main__":
    main()
