"""Compare final three-seed DQN with explicit existing DDP scenario CSVs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
import pandas as pd

from cascade_reservoir_benchmark.dqn_evaluation import (
    summarize_monthly_physical_trajectory,
)
from cascade_reservoir_benchmark.environment import (
    _as_month_period_index,
    load_specs_from_yaml,
)


SCENARIOS = ("baseline", "drought", "wet")
SEEDS = (1, 42, 100)
EXPERIMENT_ID = "dqn_1m_final_selected"
DEFAULT_DQN_ROOT = ROOT / "outputs" / "xiaowan_nuozhadu" / "dqn_1m_final"
DEFAULT_COMPARISON_ROOT = (
    ROOT / "outputs" / "xiaowan_nuozhadu" / "comparisons" / "dqn_vs_ddp"
)
DEFAULT_PHYSICAL_CONFIG = ROOT / "configs" / "xiaowan_nuozhadu_v1.yaml"

COMPARISON_METRICS = (
    ("xiaowan_total_generation_gwh", "GWh"),
    ("nuozhadu_total_generation_gwh", "GWh"),
    ("cascade_total_generation_gwh", "GWh"),
    ("xiaowan_mean_annual_generation_gwh", "GWh/year"),
    ("nuozhadu_mean_annual_generation_gwh", "GWh/year"),
    ("cascade_mean_annual_generation_gwh", "GWh/year"),
    ("xiaowan_firm_power_reliability", "fraction"),
    ("nuozhadu_firm_power_reliability", "fraction"),
    ("cascade_firm_power_reliability", "fraction"),
    ("xiaowan_spill_volume_1e9m3", "1e9 m3"),
    ("nuozhadu_spill_volume_1e9m3", "1e9 m3"),
    ("cascade_spill_volume_1e9m3", "1e9 m3"),
)


def _resolved(path: str | Path) -> Path:
    value = Path(path)
    return value.resolve() if value.is_absolute() else (ROOT / value).resolve()


def _dqn_scenario_paths(dqn_root: Path, scenario: str, seed: int) -> tuple[Path, Path]:
    root = (
        dqn_root
        / "experiments"
        / EXPERIMENT_ID
        / f"seed_{seed}"
        / "final"
        / "evaluation"
        / scenario
    )
    return root / "monthly_trajectory.csv", root / "yearly_summary.csv"


def _validate_same_inflows(
    ddp: pd.DataFrame,
    dqn: pd.DataFrame,
    scenario: str,
) -> None:
    columns = ("date", "inflow_1_m3s", "inflow_2_local_m3s")
    missing_ddp = set(columns) - set(ddp.columns)
    missing_dqn = set(columns) - set(dqn.columns)
    if missing_ddp or missing_dqn:
        raise ValueError(
            f"Cannot align {scenario} inflows; DDP missing={sorted(missing_ddp)}, "
            f"DQN missing={sorted(missing_dqn)}."
        )
    if len(ddp) != 4800 or len(dqn) != 4800:
        raise ValueError(f"{scenario} comparison requires 4800 monthly rows.")
    ddp_months = _as_month_period_index(ddp["date"])
    dqn_months = _as_month_period_index(dqn["date"])
    if not ddp_months.equals(dqn_months):
        raise ValueError(f"{scenario} DDP/DQN dates differ.")
    for column in columns[1:]:
        if not np.allclose(
            pd.to_numeric(ddp[column], errors="coerce"),
            pd.to_numeric(dqn[column], errors="coerce"),
            rtol=0.0,
            atol=1.0e-9,
        ):
            raise ValueError(f"{scenario} DDP/DQN {column} values differ.")


def _load_all(
    *,
    dqn_root: Path,
    ddp_paths: dict[str, Path],
    physical_config: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    reservoir_1, reservoir_2, _ = load_specs_from_yaml(physical_config)
    summary_rows: list[dict[str, Any]] = []
    yearly_rows: list[pd.DataFrame] = []
    source_manifest: dict[str, Any] = {}

    for scenario in SCENARIOS:
        ddp_path = ddp_paths[scenario]
        if not ddp_path.is_file():
            raise FileNotFoundError(
                f"Existing formal DDP {scenario} result was not found: {ddp_path}"
            )
        ddp_monthly = pd.read_csv(ddp_path)
        ddp_yearly, ddp_metrics = summarize_monthly_physical_trajectory(
            ddp_monthly,
            reservoir_1,
            reservoir_2,
        )
        if len(ddp_monthly) != 4800 or len(ddp_yearly) != 400:
            raise ValueError(f"DDP {scenario} result is not 400 years.")
        dqn_metrics_by_seed: dict[int, dict[str, float]] = {}
        dqn_yearly_by_seed: dict[int, pd.DataFrame] = {}
        for seed in SEEDS:
            monthly_path, yearly_path = _dqn_scenario_paths(
                dqn_root, scenario, seed
            )
            if not monthly_path.is_file() or not yearly_path.is_file():
                raise FileNotFoundError(
                    f"Missing DQN {scenario} seed={seed} evaluation output."
                )
            dqn_monthly = pd.read_csv(monthly_path)
            _validate_same_inflows(ddp_monthly, dqn_monthly, scenario)
            _, dqn_metrics = summarize_monthly_physical_trajectory(
                dqn_monthly,
                reservoir_1,
                reservoir_2,
            )
            dqn_yearly = pd.read_csv(yearly_path)
            if len(dqn_yearly) != 400:
                raise ValueError(f"DQN {scenario} seed={seed} yearly rows are not 400.")
            dqn_metrics_by_seed[seed] = {
                key: float(value) for key, value in dqn_metrics.items()
            }
            dqn_yearly_by_seed[seed] = dqn_yearly

        for metric, unit in COMPARISON_METRICS:
            values = np.asarray(
                [dqn_metrics_by_seed[seed][metric] for seed in SEEDS],
                dtype=float,
            )
            ddp_value = float(ddp_metrics[metric])
            dqn_mean = float(values.mean())
            gap = ddp_value - dqn_mean
            summary_rows.append(
                {
                    "scenario": scenario,
                    "metric": metric,
                    "unit": unit,
                    "ddp_value": ddp_value,
                    "dqn_seed1_value": float(values[0]),
                    "dqn_seed42_value": float(values[1]),
                    "dqn_seed100_value": float(values[2]),
                    "dqn_mean": dqn_mean,
                    "dqn_std": float(values.std(ddof=1)),
                    "dqn_min": float(values.min()),
                    "dqn_max": float(values.max()),
                    "ddp_minus_dqn_seed1": float(ddp_value - values[0]),
                    "ddp_minus_dqn_seed42": float(ddp_value - values[1]),
                    "ddp_minus_dqn_seed100": float(ddp_value - values[2]),
                    "ddp_minus_dqn_seed1_percent": (
                        float((ddp_value - values[0]) / ddp_value * 100.0)
                        if abs(ddp_value) > 1.0e-12 else float("nan")
                    ),
                    "ddp_minus_dqn_seed42_percent": (
                        float((ddp_value - values[1]) / ddp_value * 100.0)
                        if abs(ddp_value) > 1.0e-12 else float("nan")
                    ),
                    "ddp_minus_dqn_seed100_percent": (
                        float((ddp_value - values[2]) / ddp_value * 100.0)
                        if abs(ddp_value) > 1.0e-12 else float("nan")
                    ),
                    "ddp_minus_dqn_mean": gap,
                    "ddp_minus_dqn_mean_percent": (
                        float(gap / ddp_value * 100.0)
                        if abs(ddp_value) > 1.0e-12
                        else float("nan")
                    ),
                    "positive_gap_definition": "DQN mean is below DDP",
                }
            )

        paired = ddp_yearly[
            ["year_index", "calendar_year", "cascade_annual_generation_gwh"]
        ].rename(
            columns={"cascade_annual_generation_gwh": "ddp_generation_gwh"}
        )
        for seed in SEEDS:
            seed_yearly = dqn_yearly_by_seed[seed][
                ["year_index", "cascade_annual_generation_gwh"]
            ].rename(
                columns={
                    "cascade_annual_generation_gwh": (
                        f"dqn_seed{seed}_generation_gwh"
                    )
                }
            )
            paired = paired.merge(
                seed_yearly,
                on="year_index",
                how="inner",
                validate="one_to_one",
            )
        dqn_columns = [f"dqn_seed{seed}_generation_gwh" for seed in SEEDS]
        paired["dqn_mean_generation_gwh"] = paired[dqn_columns].mean(axis=1)
        paired["dqn_std_generation_gwh"] = paired[dqn_columns].std(
            axis=1, ddof=1
        )
        paired["ddp_minus_dqn_mean_gwh"] = (
            paired["ddp_generation_gwh"]
            - paired["dqn_mean_generation_gwh"]
        )
        paired.insert(0, "scenario", scenario)
        yearly_rows.append(paired)
        source_manifest[scenario] = {
            "ddp_monthly_csv": str(ddp_path),
            "dqn_seed_monthly_csvs": {
                str(seed): str(_dqn_scenario_paths(dqn_root, scenario, seed)[0])
                for seed in SEEDS
            },
            "months": 4800,
            "years": 400,
            "inflow_alignment_verified": True,
        }

    return (
        pd.DataFrame(summary_rows),
        pd.concat(yearly_rows, ignore_index=True),
        source_manifest,
    )


def _write_report(summary: pd.DataFrame, yearly: pd.DataFrame, path: Path) -> None:
    with PdfPages(path) as pdf:
        metric = "cascade_mean_annual_generation_gwh"
        subset = summary[summary["metric"] == metric].set_index("scenario").loc[list(SCENARIOS)]
        positions = np.arange(3)
        width = 0.36
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        ax.bar(positions - width / 2, subset["ddp_value"], width, label="DDP perfect-foresight reference", color="#4472C4")
        ax.bar(positions + width / 2, subset["dqn_mean"], width, yerr=subset["dqn_std"], capsize=5, label="DQN three-seed mean ± std", color="#ED7D31")
        ax.set_xticks(positions)
        ax.set_xticklabels(SCENARIOS)
        ax.set_ylabel("Cascade mean annual generation (GWh/year)")
        ax.set_title("DDP versus final DQN across hold-out scenarios")
        ax.legend()
        ax.grid(axis="y", alpha=0.25)
        fig.text(0.5, 0.02, "Same physical system and inflow sequence; DDP has complete future inflow while DQN observes current-month external inflows only.", ha="center", fontsize=9)
        fig.tight_layout(rect=(0, 0.04, 1, 1))
        pdf.savefig(fig)
        plt.close(fig)

        for scenario in SCENARIOS:
            frame = yearly[yearly["scenario"] == scenario]
            fig, axes = plt.subplots(2, 1, figsize=(11.7, 8.3))
            axes[0].plot(frame["year_index"], frame["ddp_generation_gwh"], color="#4472C4", linewidth=1, label="DDP")
            axes[0].plot(frame["year_index"], frame["dqn_mean_generation_gwh"], color="#ED7D31", linewidth=1, label="DQN mean")
            years = frame["year_index"].to_numpy(dtype=float)
            dqn_mean = frame["dqn_mean_generation_gwh"].to_numpy(dtype=float)
            dqn_std = frame["dqn_std_generation_gwh"].to_numpy(dtype=float)
            axes[0].fill_between(years, dqn_mean - dqn_std, dqn_mean + dqn_std, color="#ED7D31", alpha=0.15)
            axes[0].set_ylabel("Annual generation (GWh)")
            axes[0].set_title(f"{scenario}: paired annual cascade generation")
            axes[0].legend()
            axes[0].grid(alpha=0.2)
            axes[1].hist(frame["ddp_minus_dqn_mean_gwh"], bins=30, color="#70AD47", alpha=0.85)
            axes[1].axvline(0.0, color="black", linestyle="--")
            axes[1].set_xlabel("DDP minus DQN mean annual generation (GWh)")
            axes[1].set_ylabel("Years")
            axes[1].grid(alpha=0.2)
            fig.tight_layout()
            pdf.savefig(fig)
            plt.close(fig)

        reliability_metrics = (
            "xiaowan_firm_power_reliability",
            "nuozhadu_firm_power_reliability",
            "cascade_firm_power_reliability",
        )
        fig, axes = plt.subplots(1, 3, figsize=(11.7, 8.3), sharey=True)
        for ax, metric in zip(axes, reliability_metrics, strict=True):
            subset = summary[summary["metric"] == metric].set_index("scenario").loc[list(SCENARIOS)]
            ax.bar(positions - width / 2, subset["ddp_value"], width, color="#4472C4", label="DDP")
            ax.bar(positions + width / 2, subset["dqn_mean"], width, yerr=subset["dqn_std"], capsize=4, color="#ED7D31", label="DQN")
            ax.set_xticks(positions)
            ax.set_xticklabels(SCENARIOS, rotation=25)
            ax.set_title(metric.replace("_firm_power_reliability", ""))
            ax.grid(axis="y", alpha=0.2)
        axes[0].set_ylabel("Firm-power reliability")
        axes[0].legend()
        fig.suptitle("Firm-power reliability by scenario")
        fig.tight_layout(rect=(0, 0, 1, 0.96))
        pdf.savefig(fig)
        plt.close(fig)

        subset = summary[summary["metric"] == "cascade_spill_volume_1e9m3"].set_index("scenario").loc[list(SCENARIOS)]
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        ax.bar(positions - width / 2, subset["ddp_value"], width, color="#4472C4", label="DDP")
        ax.bar(positions + width / 2, subset["dqn_mean"], width, yerr=subset["dqn_std"], capsize=5, color="#ED7D31", label="DQN")
        ax.set_xticks(positions)
        ax.set_xticklabels(SCENARIOS)
        ax.set_ylabel("Cascade spill volume (1e9 m3 over 400 years)")
        ax.set_title("Spill comparison across hold-out scenarios")
        ax.legend()
        ax.grid(axis="y", alpha=0.25)
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dqn-output-root", default=str(DEFAULT_DQN_ROOT))
    parser.add_argument("--ddp-baseline", required=True)
    parser.add_argument("--ddp-drought", required=True)
    parser.add_argument("--ddp-wet", required=True)
    parser.add_argument("--physical-config", default=str(DEFAULT_PHYSICAL_CONFIG))
    parser.add_argument("--output-dir", default=str(DEFAULT_COMPARISON_ROOT))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    dqn_root = _resolved(args.dqn_output_root)
    output_dir = _resolved(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    ddp_paths = {
        "baseline": _resolved(args.ddp_baseline),
        "drought": _resolved(args.ddp_drought),
        "wet": _resolved(args.ddp_wet),
    }
    summary, yearly, sources = _load_all(
        dqn_root=dqn_root,
        ddp_paths=ddp_paths,
        physical_config=_resolved(args.physical_config),
    )
    summary_path = output_dir / "dqn_vs_ddp_summary.csv"
    yearly_path = output_dir / "dqn_vs_ddp_yearly.csv"
    report_path = output_dir / "dqn_vs_ddp_report.pdf"
    metadata_path = output_dir / "dqn_vs_ddp_metadata.json"
    summary.to_csv(summary_path, index=False)
    yearly.to_csv(yearly_path, index=False)
    _write_report(summary, yearly, report_path)
    metadata = {
        "comparison": "DQN versus DDP across baseline, drought, and wet",
        "dqn_seed_reporting": "all seeds plus mean/std/min/max; no best-seed selection",
        "ddp_role": "perfect-foresight dynamic-programming reference/upper benchmark",
        "information_condition_note": (
            "Both methods use the same physical system and evaluation inflows, "
            "but DDP has complete realized future inflow while DQN has only "
            "current-month external inflows."
        ),
        "gap_definition": "DDP minus DQN; positive generation gap means DQN is below DDP",
        "paired_significance_tests_performed": False,
        "sources": sources,
        "summary_csv": str(summary_path),
        "yearly_csv": str(yearly_path),
        "report_pdf": str(report_path),
    }
    metadata_path.write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print("Completed three-scenario DQN-DDP comparison.")
    print("Summary:", summary_path)
    print("Yearly paired comparison:", yearly_path)
    print("PDF report:", report_path)
    print("Metadata:", metadata_path)


if __name__ == "__main__":
    main()
