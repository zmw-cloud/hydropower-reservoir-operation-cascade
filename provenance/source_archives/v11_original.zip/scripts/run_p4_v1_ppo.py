"""Inspect, train, validate, and evaluate the P4 discrete cascade PPO."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np
import pandas as pd
import torch
import yaml

from cascade_reservoir_benchmark.data import load_configured_joint_inflows
from cascade_reservoir_benchmark.dqn_adapter import (
    JointActionGrid,
    StateNormalizer,
    normalized_inflow_sha256,
)
from cascade_reservoir_benchmark.dqn_training import (
    configuration_sha256,
    experiment_id_from_config,
    split_training_inflows,
)
from cascade_reservoir_benchmark.environment import (
    CascadeSpecError,
    load_specs_from_yaml,
)
from cascade_reservoir_benchmark.ppo_agent import ACTION_MASK_MODE, DiscretePPOAgent
from cascade_reservoir_benchmark.ppo_evaluation import (
    evaluate_deterministic_trajectory,
)
from cascade_reservoir_benchmark.ppo_training import (
    PPO_TRAINING_MODES,
    _normalized_action_features,
    build_ppo_training_paths,
    inspect_ppo_configuration,
    load_ppo_checkpoint,
    train_ppo_seed,
)
from cascade_reservoir_benchmark.sdp import reservoir_pair_sha256


DEFAULT_PPO_CONFIG = ROOT / "configs" / "xiaowan_nuozhadu_ppo.yaml"


def _load_yaml(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise CascadeSpecError(f"PPO configuration must be a mapping: {path}")
    return payload


def _mapping(parent: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    value = parent.get(key)
    if not isinstance(value, Mapping):
        raise CascadeSpecError(f"PPO configuration section {key!r} is missing.")
    return value


def _resolve_path(value: Any, *, label: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise CascadeSpecError(f"{label} must be a nonempty path string.")
    candidate = Path(value)
    return candidate.resolve() if candidate.is_absolute() else (ROOT / candidate).resolve()


def _resolve_config_path(value: str | None) -> Path:
    if value is None:
        return DEFAULT_PPO_CONFIG
    candidate = Path(value)
    return candidate.resolve() if candidate.is_absolute() else (ROOT / candidate).resolve()


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    raise TypeError(f"Cannot serialize {type(value).__name__}.")


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            dict(payload),
            indent=2,
            ensure_ascii=False,
            sort_keys=True,
            default=_json_default,
        )
        + "\n",
        encoding="utf-8",
    )


def _configured_seeds(
    config: Mapping[str, Any], override: Sequence[int] | None
) -> list[int]:
    raw = override if override is not None else _mapping(config, "training").get("seeds")
    if isinstance(raw, (str, bytes)) or not isinstance(raw, Sequence):
        raise CascadeSpecError("training.seeds must be a sequence.")
    seeds: list[int] = []
    for value in raw:
        if isinstance(value, bool) or not isinstance(value, (int, np.integer)):
            raise CascadeSpecError("Every PPO seed must be an integer.")
        seed = int(value)
        if seed < 0 or seed in seeds:
            raise CascadeSpecError("PPO seeds must be nonnegative and unique.")
        seeds.append(seed)
    if not seeds:
        raise CascadeSpecError("At least one PPO seed is required.")
    return seeds


def _device_from_config(config: Mapping[str, Any]) -> str:
    value = _mapping(config, "training").get("device")
    if not isinstance(value, str) or not value.strip():
        raise CascadeSpecError("training.device must be a nonempty string.")
    requested = value.strip().lower()
    if requested == "auto":
        return "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(requested)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise CascadeSpecError("CUDA was requested for PPO but is unavailable.")
    return str(device)


def _agent_from_checkpoint(
    checkpoint: Mapping[str, Any],
    *,
    action_grid: JointActionGrid,
    device: str,
) -> DiscretePPOAgent:
    state = checkpoint.get("agent_state")
    if not isinstance(state, Mapping):
        raise CascadeSpecError("PPO checkpoint is missing agent_state.")
    settings = state.get("configuration")
    if not isinstance(settings, Mapping):
        raise CascadeSpecError("PPO checkpoint is missing agent configuration.")
    agent = DiscretePPOAgent(
        state_dimension=int(settings["state_dimension"]),
        action_count=int(settings["action_count"]),
        action_features=_normalized_action_features(action_grid),
        action_score_chunk_size=int(settings["action_score_chunk_size"]),
        actor_hidden_dimensions=settings["actor_hidden_dimensions"],
        critic_hidden_dimensions=settings["critic_hidden_dimensions"],
        learning_rate=float(settings["learning_rate"]),
        gamma=float(settings["gamma"]),
        gae_lambda=float(settings["gae_lambda"]),
        clip_range=float(settings["clip_range"]),
        normalized_entropy_coefficient=float(
            settings["normalized_entropy_coefficient"]
        ),
        value_loss_coefficient=float(settings["value_loss_coefficient"]),
        max_gradient_norm=float(settings["max_gradient_norm"]),
        minibatch_size=int(settings["minibatch_size"]),
        update_epochs=int(settings["update_epochs"]),
        advantage_normalization=bool(settings["advantage_normalization"]),
        adam_epsilon=float(settings["adam_epsilon"]),
        seed=int(settings["seed"]),
        device=device,
    )
    agent.load_inference_state(state)
    return agent


def _selected_checkpoint_path(
    output_root: Path,
    *,
    config: Mapping[str, Any],
    mode: str,
    seed: int,
) -> Path:
    experiment_id = experiment_id_from_config(config)
    if experiment_id is None:
        raise CascadeSpecError("PPO configuration requires experiment_id.")
    paths = build_ppo_training_paths(
        output_root,
        mode=mode,
        seed=seed,
        experiment_id=experiment_id,
    )
    selected = (
        paths.best_validation_checkpoint
        if mode == "development"
        else paths.final_checkpoint
    )
    if selected is None:
        raise CascadeSpecError(f"No selected PPO checkpoint for mode {mode}.")
    return selected


def _load_selected_policy(
    checkpoint_path: Path,
    *,
    config: Mapping[str, Any],
    mode: str,
    seed: int,
    reservoir_1,
    reservoir_2,
    training_frame: pd.DataFrame,
    physical_configuration_sha256: str,
) -> tuple[DiscretePPOAgent, StateNormalizer, JointActionGrid, dict[str, Any]]:
    checkpoint = load_ppo_checkpoint(
        checkpoint_path,
        map_location=_device_from_config(config),
    )
    expected_role = "best_validation" if mode == "development" else "final"
    expected = {
        "checkpoint_role": expected_role,
        "experiment_id": experiment_id_from_config(config),
        "mode": mode,
        "seed": seed,
        "configuration_sha256": configuration_sha256(config),
        "physical_configuration_sha256": physical_configuration_sha256,
        "reservoir_physics_sha256": reservoir_pair_sha256(
            reservoir_1, reservoir_2
        ),
    }
    for name, value in expected.items():
        if checkpoint.get(name) != value:
            raise CascadeSpecError(
                f"Selected PPO checkpoint {name} does not match configuration."
            )
    validation = _mapping(config, "validation")
    learning_frame, _ = split_training_inflows(
        training_frame,
        mode=mode,
        development_years=int(validation["development_years"]),
        validation_years=int(validation["validation_years"]),
    )
    expected_training_hash = normalized_inflow_sha256(learning_frame)
    if checkpoint.get("training_inflow_sha256") != expected_training_hash:
        raise CascadeSpecError("PPO checkpoint training inflow hash is incompatible.")
    normalizer = StateNormalizer.from_state_dict(
        checkpoint["normalizer"], reservoir_1, reservoir_2
    )
    expected_normalizer = StateNormalizer.fit(
        learning_frame,
        reservoir_1,
        reservoir_2,
        clip=True,
    )
    if normalizer.state_dict() != expected_normalizer.state_dict():
        raise CascadeSpecError("PPO checkpoint normalization is incompatible.")
    action_grid = JointActionGrid.from_state_dict(
        checkpoint["action_grid"], reservoir_1, reservoir_2
    )
    expected_grid = JointActionGrid(
        reservoir_1,
        reservoir_2,
        step_m=float(_mapping(config, "problem")["action_level_step_m"]),
    )
    if action_grid.state_dict() != expected_grid.state_dict():
        raise CascadeSpecError("PPO checkpoint action grid is incompatible.")
    agent = _agent_from_checkpoint(
        checkpoint,
        action_grid=action_grid,
        device=_device_from_config(config),
    )
    return agent, normalizer, action_grid, checkpoint


def _write_trajectory_outputs(
    schedule: pd.DataFrame,
    summary: Mapping[str, Any],
    *,
    csv_path: Path,
) -> None:
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    schedule.to_csv(csv_path, index=False)
    _write_json(csv_path.with_suffix(".json"), summary)


def _progress(payload: Mapping[str, Any]) -> None:
    training = payload.get("training", {})
    validation = payload.get("validation")
    message = (
        f"PPO {payload.get('mode')} seed={payload.get('seed')} "
        f"update={training.get('update_number')} "
        f"steps={training.get('environment_steps')} "
        f"episodes={training.get('completed_episode_windows')} "
        f"reward_gwh={training.get('raw_generation_mean_gwh')} "
        f"policy_loss={training.get('policy_loss')} "
        f"value_loss={training.get('value_loss')} "
        f"entropy={training.get('normalized_entropy')} "
        f"approx_kl={training.get('approx_kl')}"
    )
    if isinstance(validation, Mapping):
        message += f" validation={validation.get('score')}"
    print(message, flush=True)


def _trajectory_seed_row(summary: Mapping[str, Any]) -> dict[str, Any]:
    reliability = summary["firm_power_reliability"]
    target_counts = summary["target_unreached_count"]
    target_rates = summary["target_unreached_rate"]
    kind = str(summary["trajectory_kind"])
    return {
        "seed": int(summary["seed"]),
        "months": int(summary["months"]),
        "total_cascade_generation_gwh": float(
            summary["total_cascade_generation_gwh"]
        ),
        "mean_annual_cascade_generation_gwh": float(
            summary["mean_annual_cascade_generation_gwh"]
        ),
        "total_penalized_objective_gwh": float(
            summary["total_penalized_objective_gwh"]
        ),
        "mean_annual_penalized_objective_gwh": float(
            summary["mean_annual_penalized_objective_gwh"]
        ),
        "firm_power_failure_penalty_gwh": float(
            summary["firm_power_failure_penalty_gwh"]
        ),
        "total_failure_penalty_gwh": float(
            summary["total_failure_penalty_gwh"]
        ),
        "failed_station_months": int(summary["failed_station_months"]),
        "xiaowan_firm_power_reliability": float(reliability["xiaowan"]),
        "nuozhadu_firm_power_reliability": float(reliability["nuozhadu"]),
        "cascade_firm_power_reliability": float(reliability["cascade"]),
        "xiaowan_target_unreached_count": int(target_counts["xiaowan"]),
        "nuozhadu_target_unreached_count": int(target_counts["nuozhadu"]),
        "either_reservoir_target_unreached_count": int(
            target_counts["either_reservoir"]
        ),
        "xiaowan_target_unreached_rate": float(target_rates["xiaowan"]),
        "nuozhadu_target_unreached_rate": float(target_rates["nuozhadu"]),
        "either_reservoir_target_unreached_rate": float(
            target_rates["either_reservoir"]
        ),
        "mean_raw_policy_entropy": float(summary["mean_raw_policy_entropy"]),
        "mean_normalized_policy_entropy": float(
            summary["mean_normalized_policy_entropy"]
        ),
        "mean_max_action_probability": float(
            summary["mean_max_action_probability"]
        ),
        "unique_selected_actions": int(summary["unique_selected_actions"]),
        "max_abs_water_balance_error_m3": float(
            summary["max_abs_water_balance_error_m3"]
        ),
        f"{kind}_wall_time_seconds": float(
            summary[f"{kind}_wall_time_seconds"]
        ),
        f"{kind}_inflow_sha256": str(summary[f"{kind}_inflow_sha256"]),
        "checkpoint": str(summary["checkpoint"]),
        "checkpoint_environment_steps": int(
            summary["checkpoint_environment_steps"]
        ),
    }


def _write_trajectory_seed_summary(
    summaries: Sequence[Mapping[str, Any]],
    *,
    output_root: Path,
    experiment_id: str,
    trajectory_kind: str,
) -> None:
    if not summaries:
        return
    rows = [_trajectory_seed_row(summary) for summary in summaries]
    frame = pd.DataFrame(rows).sort_values("seed").reset_index(drop=True)
    if frame["seed"].duplicated().any():
        raise CascadeSpecError("PPO trajectory summaries contain duplicate seeds.")
    if frame["months"].nunique() != 1:
        raise CascadeSpecError("PPO trajectory summaries have different lengths.")
    hash_column = f"{trajectory_kind}_inflow_sha256"
    if frame[hash_column].nunique() != 1:
        raise CascadeSpecError("PPO trajectory summaries use different inflow data.")
    summary_dir = output_root / "experiments" / experiment_id / trajectory_kind
    summary_dir.mkdir(parents=True, exist_ok=True)
    frame.to_csv(
        summary_dir / f"{trajectory_kind}_seed_summary.csv",
        index=False,
    )
    excluded = {
        "seed",
        "months",
        "checkpoint",
        "checkpoint_environment_steps",
        hash_column,
    }
    metric_columns = [
        column
        for column in frame.columns
        if column not in excluded and pd.api.types.is_numeric_dtype(frame[column])
    ]
    metrics: dict[str, dict[str, Any]] = {}
    for column in metric_columns:
        values = frame[column].to_numpy(dtype=float)
        metrics[column] = {
            "values_by_seed": {
                str(seed): float(value)
                for seed, value in zip(frame["seed"], values, strict=True)
            },
            "mean": float(values.mean()),
            "sample_std": float(values.std(ddof=1)) if len(values) > 1 else 0.0,
        }
    aggregate = {
        "method": "PPO",
        "experiment_id": experiment_id,
        "trajectory_kind": trajectory_kind,
        "policy_execution": "argmax_actor_logits",
        "seeds": [int(seed) for seed in frame["seed"]],
        "seed_count": int(len(frame)),
        "months_per_seed": int(frame["months"].iloc[0]),
        hash_column: str(frame[hash_column].iloc[0]),
        "metrics": metrics,
    }
    _write_json(
        summary_dir / f"{trajectory_kind}_aggregate.json",
        aggregate,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--config",
        default=None,
        help=(
            "PPO YAML path relative to the project root. Default: "
            "configs/xiaowan_nuozhadu_ppo.yaml"
        ),
    )
    parser.add_argument(
        "--stage",
        choices=["inspect", "train", "validate", "evaluate", "all"],
        required=True,
    )
    parser.add_argument(
        "--mode", choices=list(PPO_TRAINING_MODES), required=True
    )
    parser.add_argument("--seeds", type=int, nargs="+", default=None)
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume only from a strictly matching complete PPO update boundary.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = _resolve_config_path(args.config)
    config = _load_yaml(config_path)
    experiment_id = experiment_id_from_config(config)
    if experiment_id is None:
        raise CascadeSpecError("PPO configuration requires experiment_id.")
    physical_path = _resolve_path(
        _mapping(config, "problem").get("physical_config"),
        label="problem.physical_config",
    )
    reservoir_1, reservoir_2, physical = load_specs_from_yaml(physical_path)
    constraints = _mapping(physical, "ddp_constraints")
    monthly_max_target_levels = list(
        zip(
            constraints["monthly_max_target_levels_m"]["xiaowan"],
            constraints["monthly_max_target_levels_m"]["nuozhadu"],
            strict=True,
        )
    )
    physical_hash = _sha256(physical_path)
    output_root = _resolve_path(
        _mapping(config, "outputs").get("root"),
        label="outputs.root",
    )
    seeds = _configured_seeds(config, args.seeds)

    if args.stage == "inspect":
        inspection = inspect_ppo_configuration(
            reservoir_1,
            reservoir_2,
            config,
            mode=args.mode,
            seed=seeds[0],
        )
        inspection.update(
            {
                "configuration": str(config_path),
                "configuration_file_sha256": _sha256(config_path),
                "physical_configuration": str(physical_path),
                "physical_configuration_file_sha256": physical_hash,
                "output_root": str(output_root),
                "monthly_max_target_levels_m": monthly_max_target_levels,
                "action_mask_mode": ACTION_MASK_MODE,
            }
        )
        print(json.dumps(inspection, indent=2, sort_keys=True, default=_json_default))
        return

    training_frame = load_configured_joint_inflows(physical, "train")
    if args.stage == "validate" and args.mode != "development":
        raise CascadeSpecError("Standalone PPO validation requires development mode.")
    if args.stage == "evaluate" and args.mode != "final":
        raise CascadeSpecError("Independent PPO evaluation requires final mode.")

    if args.stage in {"train", "all"}:
        for seed in seeds:
            paths = build_ppo_training_paths(
                output_root,
                mode=args.mode,
                seed=seed,
                experiment_id=experiment_id,
            )
            _write_json(
                paths.configuration_snapshot_json,
                {
                    "action_mask_mode": ACTION_MASK_MODE,
                    "experiment_id": experiment_id,
                    "seed": seed,
                    "mode": args.mode,
                    "source_config": str(config_path),
                    "source_config_file_sha256": _sha256(config_path),
                    "configuration_sha256": configuration_sha256(config),
                    "configuration": config,
                },
            )
            result = train_ppo_seed(
                reservoir_1,
                reservoir_2,
                training_frame,
                config,
                mode=args.mode,
                seed=seed,
                output_root=output_root,
                resume_latest=args.resume,
                physical_configuration_sha256=physical_hash,
                monthly_max_target_levels_m=monthly_max_target_levels,
                progress_callback=_progress,
            )
            metadata = result.as_dict()
            metadata.update(
                {
                    "ppo_configuration": str(config_path),
                    "ppo_configuration_file_sha256": _sha256(config_path),
                    "physical_configuration": str(physical_path),
                    "physical_configuration_file_sha256": physical_hash,
                    "training_inflow_source": physical["data"]["train_inflow_file"],
                    "hyperparameters": _mapping(config, "ppo"),
                    "network": _mapping(config, "network"),
                    "training": _mapping(config, "training"),
                }
            )
            _write_json(result.paths.metadata_json, metadata)
            print(
                f"Completed PPO {args.mode} seed={seed}: "
                f"{result.selected_checkpoint}",
                flush=True,
            )

    run_trajectory = bool(
        args.stage in {"validate", "evaluate"}
        or (args.stage == "all" and args.mode == "final")
    )
    if run_trajectory:
        if args.stage == "validate":
            _, trajectory = split_training_inflows(
                training_frame,
                mode="development",
                development_years=int(
                    _mapping(config, "validation")["development_years"]
                ),
                validation_years=int(
                    _mapping(config, "validation")["validation_years"]
                ),
            )
            if trajectory is None:
                raise CascadeSpecError("PPO validation trajectory is missing.")
            trajectory_kind = "validation"
        else:
            trajectory = load_configured_joint_inflows(physical, "evaluation")
            if normalized_inflow_sha256(trajectory) == normalized_inflow_sha256(
                training_frame
            ):
                raise CascadeSpecError(
                    "PPO training and independent evaluation inflows are identical."
                )
            trajectory_kind = "evaluation"

        trajectory_summaries: list[dict[str, Any]] = []
        for seed in seeds:
            checkpoint_path = _selected_checkpoint_path(
                output_root,
                config=config,
                mode=args.mode,
                seed=seed,
            )
            agent, normalizer, action_grid, checkpoint = _load_selected_policy(
                checkpoint_path,
                config=config,
                mode=args.mode,
                seed=seed,
                reservoir_1=reservoir_1,
                reservoir_2=reservoir_2,
                training_frame=training_frame,
                physical_configuration_sha256=physical_hash,
            )
            reward_scaling = checkpoint["reward_scaling"]
            schedule, summary = evaluate_deterministic_trajectory(
                reservoir_1,
                reservoir_2,
                agent,
                normalizer,
                action_grid,
                trajectory,
                _mapping(config, "problem")["initial_levels_m"],
                training_inflow_sha256=checkpoint["training_inflow_sha256"],
                seed=seed,
                reward_reference_days=float(reward_scaling["reference_days"]),
                reward_clip=reward_scaling["clip"],
                firm_power_failure_penalty_gwh=float(
                    reward_scaling["firm_power_failure_penalty_gwh"]
                ),
                monthly_max_target_levels_m=monthly_max_target_levels,
                trajectory_kind=trajectory_kind,
                collect_rows=True,
            )
            if schedule is None:
                raise CascadeSpecError("PPO trajectory did not return monthly rows.")
            summary.update(
                {
                    "mode": args.mode,
                    "experiment_id": experiment_id,
                    "checkpoint": str(checkpoint_path),
                    "checkpoint_role": checkpoint["checkpoint_role"],
                    "checkpoint_environment_steps": checkpoint["environment_steps"],
                    "ppo_configuration": str(config_path),
                    "ppo_configuration_file_sha256": _sha256(config_path),
                    "physical_configuration": str(physical_path),
                    "physical_configuration_file_sha256": physical_hash,
                    "training_inflow_source": physical["data"]["train_inflow_file"],
                    "trajectory_source": (
                        physical["data"]["evaluation_inflow_file"]
                        if trajectory_kind == "evaluation"
                        else "chronological_final_80_years_of_training_split"
                    ),
                }
            )
            paths = build_ppo_training_paths(
                output_root,
                mode=args.mode,
                seed=seed,
                experiment_id=experiment_id,
            )
            csv_path = paths.run_root / trajectory_kind / f"{trajectory_kind}_monthly.csv"
            _write_trajectory_outputs(schedule, summary, csv_path=csv_path)
            trajectory_summaries.append(dict(summary))
            print(f"Wrote PPO {trajectory_kind} seed={seed}: {csv_path}")
        _write_trajectory_seed_summary(
            trajectory_summaries,
            output_root=output_root,
            experiment_id=experiment_id,
            trajectory_kind=trajectory_kind,
        )
        print(
            f"Wrote PPO {trajectory_kind} cross-seed summary: "
            f"{output_root / 'experiments' / experiment_id / trajectory_kind}",
            flush=True,
        )


if __name__ == "__main__":
    main()
