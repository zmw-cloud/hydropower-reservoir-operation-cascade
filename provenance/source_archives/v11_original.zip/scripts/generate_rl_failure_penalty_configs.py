"""Generate isolated DQN/PPO failure-count penalty-scan configurations.

This command copies one already selected hyperparameter configuration and changes
only the shared station-month failure penalty, experiment id, and output root.
It never starts training or evaluation.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any, Mapping

import yaml


DEFAULT_PENALTIES_GWH = tuple(range(0, 1001, 100))
EXPECTED_OBJECTIVE = (
    "generation_gwh_minus_penalty_gwh_per_failed_station_month"
)
BASELINE_ROLE = "penalty_calibration_baseline_evaluation"


def _load_mapping(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError(f"Configuration must be a mapping: {path}")
    return payload


def _required_mapping(parent: Mapping[str, Any], key: str) -> dict[str, Any]:
    value = parent.get(key)
    if not isinstance(value, dict):
        raise ValueError(f"Missing mapping {key!r} in source configuration.")
    return value


def _penalty_code(value: float) -> str:
    if value < 0.0:
        raise ValueError("Penalty candidates must be nonnegative.")
    return f"lambda_{value:07.2f}".replace(".", "p")


def _validated_penalties(values: list[float] | None) -> tuple[float, ...]:
    selected = DEFAULT_PENALTIES_GWH if values is None else tuple(values)
    if not selected:
        raise ValueError("At least one penalty candidate is required.")
    result = tuple(float(value) for value in selected)
    if any(value < 0.0 for value in result) or len(set(result)) != len(result):
        raise ValueError("Penalty candidates must be unique and nonnegative.")
    return tuple(sorted(result))


def generate_configs(
    *,
    algorithm: str,
    source_config: Path,
    destination: Path,
    output_root: str,
    penalties_gwh: tuple[float, ...],
) -> list[dict[str, Any]]:
    source = _load_mapping(source_config)
    reward = _required_mapping(source, "reward")
    if reward.get("objective") != EXPECTED_OBJECTIVE:
        raise ValueError(
            "Source configuration does not use the frozen station-month "
            "failure-count objective."
        )
    if float(reward.get("firm_power_failure_penalty_gwh", float("nan"))) != 0.0:
        raise ValueError(
            "Source configuration must be the frozen lambda=0 selected-"
            "hyperparameter configuration."
        )
    experiment_id = source.get("experiment_id")
    if not isinstance(experiment_id, str) or not experiment_id.strip():
        raise ValueError("Source configuration requires experiment_id.")

    if algorithm == "dqn" and "evaluation_scenarios" not in source:
        problem = _required_mapping(source, "problem")
        physical_path = Path(str(problem.get("physical_config", "")))
        if not physical_path.is_absolute():
            physical_path = Path.cwd() / physical_path
        physical = _load_mapping(physical_path.resolve())
        data = _required_mapping(physical, "data")
        baseline_file = data.get("evaluation_inflow_file")
        if not isinstance(baseline_file, str) or not baseline_file.strip():
            raise ValueError(
                "Physical configuration is missing data.evaluation_inflow_file."
            )
        source["evaluation_scenarios"] = {
            "baseline": {
                "role": BASELINE_ROLE,
                "inflow_file": baseline_file,
            }
        }

    destination.mkdir(parents=True, exist_ok=True)
    manifest_rows: list[dict[str, Any]] = []
    for rank, penalty in enumerate(penalties_gwh, start=1):
        candidate = copy.deepcopy(source)
        candidate_reward = _required_mapping(candidate, "reward")
        candidate_reward["firm_power_failure_penalty_gwh"] = float(penalty)
        code = _penalty_code(penalty)
        candidate["experiment_id"] = f"{algorithm}_1m_v6_penalty_{code}"
        candidate_outputs = _required_mapping(candidate, "outputs")
        candidate_outputs["root"] = output_root
        candidate["penalty_scan"] = {
            "source_config": source_config.as_posix(),
            "source_experiment_id": experiment_id,
            "candidate_rank": rank,
            "firm_power_failure_penalty_gwh": float(penalty),
            "hyperparameters_frozen": True,
            "train_from_scratch": True,
            "training_mode": "final_full_400_year_training_split",
            "evaluation_scenario": "baseline",
            "evaluation_role": BASELINE_ROLE,
        }
        filename = f"{algorithm}_1m_v6_penalty_{code}.yaml"
        target = destination / filename
        target.write_text(
            yaml.safe_dump(candidate, sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        manifest_rows.append(
            {
                "rank": rank,
                "algorithm": algorithm,
                "penalty_gwh": float(penalty),
                "experiment_id": candidate["experiment_id"],
                "config": target.as_posix(),
                "output_root": output_root,
            }
        )

    manifest = {
        "schema_version": 1,
        "algorithm": algorithm,
        "objective": EXPECTED_OBJECTIVE,
        "failure_definition": (
            "station_specific_monthly_power_below_firm_power"
        ),
        "source_config": source_config.as_posix(),
        "source_experiment_id": experiment_id,
        "hyperparameters_frozen": True,
        "train_from_scratch_for_each_candidate": True,
        "training_mode": "final_full_400_year_training_split",
        "evaluation_scenario": "baseline",
        "evaluation_role": BASELINE_ROLE,
        "candidates": manifest_rows,
    }
    (destination / "penalty_scan_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    return manifest_rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--algorithm", choices=("dqn", "ppo"), required=True)
    parser.add_argument("--source-config", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--output-root", required=True)
    parser.add_argument("--penalties-gwh", type=float, nargs="+", default=None)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = generate_configs(
        algorithm=args.algorithm,
        source_config=args.source_config,
        destination=args.destination,
        output_root=args.output_root,
        penalties_gwh=_validated_penalties(args.penalties_gwh),
    )
    print(json.dumps(rows, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
