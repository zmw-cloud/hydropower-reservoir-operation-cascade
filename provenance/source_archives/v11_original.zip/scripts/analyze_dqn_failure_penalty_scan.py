"""Analyze DQN failure-penalty baseline evaluations and plot trade-offs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG_DIR = ROOT / "configs" / "dqn_penalty_scan_1m"
DEFAULT_OUTPUT_ROOT = (
    ROOT / "outputs" / "xiaowan_nuozhadu" / "dqn_1m_v6_penalty_scan"
)
DEFAULT_ANALYSIS_DIR = DEFAULT_OUTPUT_ROOT / "analysis"
ALLOWED_SEEDS = (1, 42, 100)
RELIABILITY_TARGET = 0.90


def _resolved(value: str | Path) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (ROOT / path).resolve()


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"JSON must be a mapping: {path}")
    return payload


def _read_seed_results(
    *, config_dir: Path, output_root: Path
) -> pd.DataFrame:
    manifest_path = config_dir / "penalty_scan_manifest.json"
    manifest = _load_json(manifest_path)
    candidates = manifest.get("candidates")
    if not isinstance(candidates, list) or len(candidates) != 11:
        raise ValueError("Penalty manifest must contain exactly 11 candidates.")

    rows: list[dict[str, Any]] = []
    for candidate in candidates:
        if not isinstance(candidate, dict):
            raise ValueError("Every penalty candidate must be a mapping.")
        experiment_id = str(candidate["experiment_id"])
        penalty_gwh = float(candidate["penalty_gwh"])
        candidate_rows = 0
        for seed in ALLOWED_SEEDS:
            summary_path = (
                output_root
                / "experiments"
                / experiment_id
                / f"seed_{seed}"
                / "final"
                / "evaluation"
                / "baseline"
                / "summary.json"
            )
            if not summary_path.is_file():
                continue
            summary = _load_json(summary_path)
            required = (
                "xiaowan_firm_power_reliability",
                "nuozhadu_firm_power_reliability",
                "cascade_mean_annual_generation_gwh",
                "firm_power_failure_penalty_gwh",
            )
            missing = [name for name in required if name not in summary]
            if missing:
                raise ValueError(
                    f"Evaluation summary is missing {missing}: {summary_path}"
                )
            if (
                summary.get("evaluation_scenario") != "baseline"
                or summary.get("checkpoint_role") != "final"
                or int(summary.get("checkpoint_episode", -1)) != 3000
                or int(summary.get("months", -1)) != 4800
                or int(summary.get("seed", -1)) != seed
                or not np.isclose(
                    float(summary["firm_power_failure_penalty_gwh"]),
                    penalty_gwh,
                    rtol=0.0,
                    atol=1.0e-9,
                )
            ):
                raise ValueError(
                    f"Evaluation metadata is incompatible: {summary_path}"
                )
            xw = float(summary["xiaowan_firm_power_reliability"])
            nzd = float(summary["nuozhadu_firm_power_reliability"])
            generation = float(summary["cascade_mean_annual_generation_gwh"])
            if not (
                0.0 <= xw <= 1.0
                and 0.0 <= nzd <= 1.0
                and np.isfinite(generation)
            ):
                raise ValueError(f"Invalid metrics in {summary_path}")
            rows.append(
                {
                    "penalty_gwh": penalty_gwh,
                    "experiment_id": experiment_id,
                    "seed": seed,
                    "xiaowan_firm_power_reliability": xw,
                    "nuozhadu_firm_power_reliability": nzd,
                    "minimum_firm_power_reliability": min(xw, nzd),
                    "cascade_mean_annual_generation_gwh": generation,
                    "summary_json": str(summary_path),
                }
            )
            candidate_rows += 1
        if candidate_rows == 0:
            raise FileNotFoundError(
                f"Penalty {penalty_gwh:g} has no completed seed evaluation."
            )
    frame = pd.DataFrame(rows).sort_values(
        ["penalty_gwh", "seed"]
    ).reset_index(drop=True)
    return frame


def _aggregate(seed_results: pd.DataFrame) -> pd.DataFrame:
    summary = (
        seed_results.groupby("penalty_gwh", as_index=False)
        .agg(
            seed_count=("seed", "count"),
            xiaowan_reliability_mean=(
                "xiaowan_firm_power_reliability", "mean"
            ),
            xiaowan_reliability_std=(
                "xiaowan_firm_power_reliability", "std"
            ),
            nuozhadu_reliability_mean=(
                "nuozhadu_firm_power_reliability", "mean"
            ),
            nuozhadu_reliability_std=(
                "nuozhadu_firm_power_reliability", "std"
            ),
            minimum_reliability_mean=(
                "minimum_firm_power_reliability", "mean"
            ),
            minimum_reliability_std=(
                "minimum_firm_power_reliability", "std"
            ),
            mean_annual_generation_gwh=(
                "cascade_mean_annual_generation_gwh", "mean"
            ),
            mean_annual_generation_std_gwh=(
                "cascade_mean_annual_generation_gwh", "std"
            ),
        )
        .sort_values("penalty_gwh")
        .reset_index(drop=True)
    )
    if len(summary) != 11:
        raise ValueError("All 11 coarse penalties must have at least one seed.")
    summary["both_reliabilities_at_least_90pct"] = (
        (summary["xiaowan_reliability_mean"] >= RELIABILITY_TARGET)
        & (summary["nuozhadu_reliability_mean"] >= RELIABILITY_TARGET)
    )
    summary["maximum_one_sided_shortfall"] = np.maximum(
        np.maximum(
            0.0,
            RELIABILITY_TARGET - summary["xiaowan_reliability_mean"],
        ),
        np.maximum(
            0.0,
            RELIABILITY_TARGET - summary["nuozhadu_reliability_mean"],
        ),
    )

    maximum_seed_count = int(summary["seed_count"].max())
    selection_pool = summary[summary["seed_count"] == maximum_seed_count]
    eligible = selection_pool[
        selection_pool["both_reliabilities_at_least_90pct"]
    ]
    if len(eligible):
        selected_index = eligible.sort_values(
            ["mean_annual_generation_gwh", "penalty_gwh"],
            ascending=[False, True],
        ).index[0]
        rule = "both_reliabilities_ge_90pct_then_max_generation"
    else:
        selected_index = selection_pool.sort_values(
            [
                "maximum_one_sided_shortfall",
                "mean_annual_generation_gwh",
                "penalty_gwh",
            ],
            ascending=[True, False, True],
        ).index[0]
        rule = "minimum_worst_shortfall_then_max_generation"
    summary["provisional_selected"] = False
    summary.loc[selected_index, "provisional_selected"] = True
    summary["selection_rule"] = rule
    summary["selection_seed_count"] = maximum_seed_count
    summary["eligible_for_current_selection"] = (
        summary["seed_count"] == maximum_seed_count
    )
    summary[
        [
            "xiaowan_reliability_std",
            "nuozhadu_reliability_std",
            "minimum_reliability_std",
            "mean_annual_generation_std_gwh",
        ]
    ] = summary[
        [
            "xiaowan_reliability_std",
            "nuozhadu_reliability_std",
            "minimum_reliability_std",
            "mean_annual_generation_std_gwh",
        ]
    ].fillna(0.0)
    return summary


def _plot_tradeoff(
    seed_results: pd.DataFrame,
    summary: pd.DataFrame,
    *, output_png: Path,
    output_pdf: Path,
) -> None:
    panels = (
        (
            "xiaowan_firm_power_reliability",
            "xiaowan_reliability_mean",
            "xiaowan_reliability_std",
            "(a) XiaoWan",
        ),
        (
            "nuozhadu_firm_power_reliability",
            "nuozhadu_reliability_mean",
            "nuozhadu_reliability_std",
            "(b) NuoZhaDu",
        ),
        (
            "minimum_firm_power_reliability",
            "minimum_reliability_mean",
            "minimum_reliability_std",
            "(c) Minimum of two reliabilities",
        ),
    )
    fig, axes = plt.subplots(1, 3, figsize=(16, 5.2), sharey=True)
    y_mean = summary["mean_annual_generation_gwh"] / 1000.0
    y_std = summary["mean_annual_generation_std_gwh"] / 1000.0
    for ax, (seed_x, mean_x, std_x, title) in zip(
        axes, panels, strict=True
    ):
        ax.scatter(
            seed_results[seed_x] * 100.0,
            seed_results["cascade_mean_annual_generation_gwh"] / 1000.0,
            color="#9467bd",
            alpha=0.22,
            s=20,
            label="Available seed runs",
        )
        ax.errorbar(
            summary[mean_x] * 100.0,
            y_mean,
            xerr=summary[std_x] * 100.0,
            yerr=y_std,
            color="#6f42c1",
            marker="o",
            linewidth=1.8,
            capsize=3,
            label="Available-seed mean ± std",
        )
        for row in summary.itertuples(index=False):
            x_value = float(getattr(row, mean_x)) * 100.0
            y_value = float(row.mean_annual_generation_gwh) / 1000.0
            ax.annotate(
                f"{row.penalty_gwh:g}",
                (x_value, y_value),
                xytext=(4, 4),
                textcoords="offset points",
                fontsize=7,
            )
        ax.axvline(90.0, color="black", linestyle="--", linewidth=1.0)
        ax.set_title(title)
        ax.set_xlabel("Firm-power reliability (%)")
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("Mean annual cascade generation (TWh/year)")
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=2, frameon=False)
    fig.suptitle(
        "DQN failure-penalty scan: reliability-generation trade-off",
        y=1.02,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.93))
    output_png.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_png, dpi=300, bbox_inches="tight")
    fig.savefig(output_pdf, bbox_inches="tight")
    plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config-dir", default=str(DEFAULT_CONFIG_DIR))
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--analysis-dir", default=str(DEFAULT_ANALYSIS_DIR))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_dir = _resolved(args.config_dir)
    output_root = _resolved(args.output_root)
    analysis_dir = _resolved(args.analysis_dir)
    analysis_dir.mkdir(parents=True, exist_ok=True)

    seed_results = _read_seed_results(
        config_dir=config_dir,
        output_root=output_root,
    )
    summary = _aggregate(seed_results)
    seed_results.to_csv(analysis_dir / "penalty_seed_results.csv", index=False)
    summary.to_csv(analysis_dir / "penalty_summary.csv", index=False)
    selected = summary[summary["provisional_selected"]].iloc[0].to_dict()
    (analysis_dir / "provisional_selection.json").write_text(
        json.dumps(selected, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    _plot_tradeoff(
        seed_results,
        summary,
        output_png=analysis_dir / "dqn_reliability_generation_tradeoff.png",
        output_pdf=analysis_dir / "dqn_reliability_generation_tradeoff.pdf",
    )
    print("Completed DQN penalty analysis.")
    print(summary.to_string(index=False))
    print("Provisional selection:")
    print(json.dumps(selected, indent=2, ensure_ascii=False))
    print(f"Analysis directory: {analysis_dir}")


if __name__ == "__main__":
    main()
