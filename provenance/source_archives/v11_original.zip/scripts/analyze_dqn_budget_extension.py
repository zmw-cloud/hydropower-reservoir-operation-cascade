"""Analyze the completed Run02 3000-to-5000 development continuation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
import pandas as pd

from cascade_reservoir_benchmark.environment import CascadeSpecError


EXPERIMENT_ID = "dqn_1m_run02_budget_extension_5000"
SEEDS = (1, 42, 100)
SOURCE_EPISODES = 3000
TARGET_EPISODES = 5000
VALIDATION_INTERVAL = 100
ROLLING_VALIDATION_POINTS = 5
ROLLING_TRAINING_EPISODES = 50
DEFAULT_OUTPUT_ROOT = (
    ROOT / "outputs" / "xiaowan_nuozhadu" / "dqn_1m_budget_extension"
)
REPORT_FILENAME = "dqn_1m_run02_budget_extension_report.pdf"

# Validation is about 40,000--44,000 GWh. These thresholds treat changes below
# roughly 0.25--0.50% as small, while requiring multiple signals before calling
# a continuing trend. Loss alone is never a budget stopping rule.
PLATEAU_SLOPE_GWH_PER_100 = 25.0
IMPROVING_SLOPE_GWH_PER_100 = 75.0
PLATEAU_LAST5_RELATIVE_PERCENT = 0.25
IMPROVING_LAST5_RELATIVE_PERCENT = 0.75
SMALL_POST3000_IMPROVEMENT_PERCENT = 0.50
MEANINGFUL_POST3000_IMPROVEMENT_PERCENT = 1.00

TRAINING_COLUMNS = (
    "episode",
    "environment_steps",
    "learning_steps",
    "mean_loss",
    "last_loss",
    "mean_predicted_q",
    "mean_target_q",
    "mean_gradient_norm",
    "raw_episode_cascade_generation_gwh",
    "normalized_episode_reward",
    "epsilon",
)
VALIDATION_COLUMNS = ("episode", "score")


def _require_columns(
    frame: pd.DataFrame,
    required: Sequence[str],
    label: str,
) -> None:
    missing = set(required) - set(frame.columns)
    if missing:
        raise CascadeSpecError(f"{label} is missing columns: {sorted(missing)}")


def _read_completed_runs(
    output_root: Path,
) -> tuple[pd.DataFrame, pd.DataFrame, list[dict[str, Any]]]:
    training_frames: list[pd.DataFrame] = []
    validation_frames: list[pd.DataFrame] = []
    metadata_records: list[dict[str, Any]] = []
    expected_episodes = np.arange(1, TARGET_EPISODES + 1)
    expected_validation = np.arange(
        VALIDATION_INTERVAL,
        TARGET_EPISODES + 1,
        VALIDATION_INTERVAL,
    )

    for seed in SEEDS:
        run_root = (
            output_root
            / "experiments"
            / EXPERIMENT_ID
            / f"seed_{seed}"
            / "development"
        )
        metadata_path = run_root / "metadata.json"
        training_path = run_root / "training" / "history.csv"
        validation_path = run_root / "validation" / "history.csv"
        latest_path = run_root / "checkpoints" / "latest.pt"
        best_path = run_root / "checkpoints" / "best_validation.pt"
        for required in (
            metadata_path,
            training_path,
            validation_path,
            latest_path,
            best_path,
        ):
            if not required.is_file():
                raise FileNotFoundError(
                    f"Incomplete budget extension seed={seed}: {required}"
                )

        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        training = pd.read_csv(training_path).sort_values("episode")
        validation = pd.read_csv(validation_path).sort_values("episode")
        _require_columns(training, TRAINING_COLUMNS, str(training_path))
        _require_columns(validation, VALIDATION_COLUMNS, str(validation_path))
        if not np.array_equal(
            training["episode"].to_numpy(dtype=int), expected_episodes
        ):
            raise CascadeSpecError(
                f"Budget extension seed={seed} lacks the continuous 1--5000 history."
            )
        if not np.array_equal(
            validation["episode"].to_numpy(dtype=int), expected_validation
        ):
            raise CascadeSpecError(
                f"Budget extension seed={seed} lacks validation episodes 100--5000."
            )
        if (
            metadata.get("experiment_id") != EXPERIMENT_ID
            or int(metadata.get("seed", -1)) != seed
            or int(metadata.get("completed_episodes", -1)) != TARGET_EPISODES
            or int(metadata.get("environment_steps", -1))
            != TARGET_EPISODES * 240
        ):
            raise CascadeSpecError(
                f"Budget extension seed={seed} metadata is incomplete."
            )
        provenance = metadata.get("budget_extension_provenance")
        if not isinstance(provenance, Mapping):
            raise CascadeSpecError(
                f"Budget extension seed={seed} has no source provenance."
            )
        if (
            provenance.get("source_checkpoint_role") != "latest"
            or provenance.get("source_experiment_id") != "dqn_1m_l9_run02"
            or int(provenance.get("source_completed_episode", -1))
            != SOURCE_EPISODES
            or int(provenance.get("continuation_first_episode", -1)) != 3001
        ):
            raise CascadeSpecError(
                f"Budget extension seed={seed} did not continue the Run02 latest trajectory."
            )
        best_row = validation.loc[validation["score"].idxmax()]
        if not np.isclose(
            float(metadata["best_validation_score"]),
            float(best_row["score"]),
            rtol=0.0,
            atol=1.0e-9,
        ) or int(metadata["best_validation_episode"]) != int(
            best_row["episode"]
        ):
            raise CascadeSpecError(
                f"Budget extension seed={seed} best-validation metadata differs."
            )

        training.insert(0, "seed", seed)
        validation.insert(0, "seed", seed)
        training_frames.append(training)
        validation_frames.append(validation)
        metadata_records.append(metadata)

    return (
        pd.concat(training_frames, ignore_index=True),
        pd.concat(validation_frames, ignore_index=True),
        metadata_records,
    )


def _slope_per_100(episodes: np.ndarray, values: np.ndarray) -> float:
    if len(episodes) < 2 or np.any(~np.isfinite(values)):
        raise CascadeSpecError("Trend calculation requires at least two finite points.")
    return float(np.polyfit(episodes, values, 1)[0] * 100.0)


def _relative_percent(difference: float, baseline: float) -> float:
    if not np.isfinite(baseline) or abs(baseline) <= 1.0e-12:
        return float("nan")
    return float(difference / abs(baseline) * 100.0)


def _seed_policy_diagnostic(
    *,
    slope: float,
    last5_relative: float,
    post_improvement_relative: float,
    best_episode: int,
) -> str:
    if (
        slope > IMPROVING_SLOPE_GWH_PER_100
        or last5_relative > IMPROVING_LAST5_RELATIVE_PERCENT
        or post_improvement_relative > MEANINGFUL_POST3000_IMPROVEMENT_PERCENT
        or best_episode >= 4900
    ):
        return "STILL IMPROVING"
    if (
        abs(slope) <= 50.0
        and abs(last5_relative) <= 0.50
        and post_improvement_relative <= 0.75
        and best_episode < 4500
    ):
        return "PLATEAU"
    return "NOT CLEAR"


def _validation_diagnostics(
    validation: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    pivot = validation.pivot(index="episode", columns="seed", values="score").sort_index()
    if list(pivot.columns.astype(int)) != list(SEEDS):
        raise CascadeSpecError("Validation history does not contain seeds 1, 42, 100.")
    curve = pd.DataFrame(
        {
            "episode": pivot.index.astype(int),
            "three_seed_mean_validation": pivot.mean(axis=1),
            "three_seed_std_validation": pivot.std(axis=1, ddof=1),
        }
    ).reset_index(drop=True)
    curve["five_point_rolling_mean_validation"] = curve[
        "three_seed_mean_validation"
    ].rolling(ROLLING_VALIDATION_POINTS, min_periods=1).mean()
    for seed in SEEDS:
        curve[f"seed_{seed}_validation"] = pivot[seed].to_numpy(dtype=float)

    rows: list[dict[str, Any]] = []
    for seed in SEEDS:
        series = pivot[seed]
        pre = series[series.index <= SOURCE_EPISODES]
        post = series[series.index > SOURCE_EPISODES]
        last10 = series[(series.index >= 4100) & (series.index <= 5000)]
        previous5 = series[(series.index >= 4100) & (series.index <= 4500)]
        last5 = series[(series.index >= 4600) & (series.index <= 5000)]
        best_episode = int(series.idxmax())
        best_score = float(series.max())
        pre_best = float(pre.max())
        post_best = float(post.max())
        improvement = post_best - pre_best
        improvement_relative = _relative_percent(improvement, pre_best)
        previous5_mean = float(previous5.mean())
        last5_mean = float(last5.mean())
        last5_difference = last5_mean - previous5_mean
        last5_relative = _relative_percent(last5_difference, previous5_mean)
        slope = _slope_per_100(
            last10.index.to_numpy(dtype=float), last10.to_numpy(dtype=float)
        )
        rows.append(
            {
                "seed": seed,
                "best_validation_episode": best_episode,
                "best_validation_score": best_score,
                "best_validation_score_le_3000": pre_best,
                "best_validation_score_3100_5000": post_best,
                "post_3000_best_improvement_gwh": improvement,
                "post_3000_best_improvement_percent": improvement_relative,
                "last1000_slope_gwh_per_100_episodes": slope,
                "previous5_mean_validation_gwh": previous5_mean,
                "last5_mean_validation_gwh": last5_mean,
                "last5_minus_previous5_gwh": last5_difference,
                "last5_minus_previous5_percent": last5_relative,
                "best_at_or_after_4500": bool(best_episode >= 4500),
                "best_at_or_after_4900": bool(best_episode >= 4900),
                "policy_plateau_diagnostic": _seed_policy_diagnostic(
                    slope=slope,
                    last5_relative=last5_relative,
                    post_improvement_relative=improvement_relative,
                    best_episode=best_episode,
                ),
            }
        )

    seed_diagnostics = pd.DataFrame(rows)
    mean_series = curve.set_index("episode")["three_seed_mean_validation"]
    pre_mean = mean_series[mean_series.index <= SOURCE_EPISODES]
    post_mean = mean_series[mean_series.index > SOURCE_EPISODES]
    last10_mean = mean_series[(mean_series.index >= 4100) & (mean_series.index <= 5000)]
    previous5_mean_series = mean_series[
        (mean_series.index >= 4100) & (mean_series.index <= 4500)
    ]
    last5_mean_series = mean_series[
        (mean_series.index >= 4600) & (mean_series.index <= 5000)
    ]
    aggregate_pre_best = float(pre_mean.max())
    aggregate_post_best = float(post_mean.max())
    aggregate_improvement = aggregate_post_best - aggregate_pre_best
    aggregate_improvement_relative = _relative_percent(
        aggregate_improvement, aggregate_pre_best
    )
    aggregate_previous5 = float(previous5_mean_series.mean())
    aggregate_last5 = float(last5_mean_series.mean())
    aggregate_difference = aggregate_last5 - aggregate_previous5
    aggregate_difference_relative = _relative_percent(
        aggregate_difference, aggregate_previous5
    )
    aggregate_slope = _slope_per_100(
        last10_mean.index.to_numpy(dtype=float),
        last10_mean.to_numpy(dtype=float),
    )
    endpoint_best_count = int(seed_diagnostics["best_at_or_after_4500"].sum())
    near_endpoint_best_count = int(seed_diagnostics["best_at_or_after_4900"].sum())

    if (
        (
            aggregate_slope > IMPROVING_SLOPE_GWH_PER_100
            and aggregate_difference_relative
            > PLATEAU_LAST5_RELATIVE_PERCENT
        )
        or aggregate_improvement_relative
        > MEANINGFUL_POST3000_IMPROVEMENT_PERCENT
        or (
            endpoint_best_count >= 2
            and aggregate_improvement_relative
            > SMALL_POST3000_IMPROVEMENT_PERCENT
        )
    ):
        status = "STILL IMPROVING"
    elif (
        abs(aggregate_slope) <= PLATEAU_SLOPE_GWH_PER_100
        and abs(aggregate_difference_relative)
        <= PLATEAU_LAST5_RELATIVE_PERCENT
        and aggregate_improvement_relative
        <= SMALL_POST3000_IMPROVEMENT_PERCENT
        and endpoint_best_count < 2
    ):
        status = "PLATEAU"
    else:
        status = "NOT CLEAR"

    aggregate = {
        "policy_performance_plateau_status": status,
        "three_seed_mean_last1000_slope_gwh_per_100_episodes": aggregate_slope,
        "three_seed_mean_previous5_validation_gwh": aggregate_previous5,
        "three_seed_mean_last5_validation_gwh": aggregate_last5,
        "three_seed_mean_last5_minus_previous5_gwh": aggregate_difference,
        "three_seed_mean_last5_minus_previous5_percent": (
            aggregate_difference_relative
        ),
        "three_seed_mean_best_validation_le_3000": aggregate_pre_best,
        "three_seed_mean_best_validation_3100_5000": aggregate_post_best,
        "three_seed_mean_post_3000_best_improvement_gwh": aggregate_improvement,
        "three_seed_mean_post_3000_best_improvement_percent": (
            aggregate_improvement_relative
        ),
        "mean_of_seed_best_validation_le_3000": float(
            seed_diagnostics["best_validation_score_le_3000"].mean()
        ),
        "mean_of_seed_best_validation_3100_5000": float(
            seed_diagnostics["best_validation_score_3100_5000"].mean()
        ),
        "mean_of_seed_post_3000_best_improvement_gwh": float(
            seed_diagnostics["post_3000_best_improvement_gwh"].mean()
        ),
        "mean_of_seed_post_3000_best_improvement_percent": float(
            seed_diagnostics["post_3000_best_improvement_percent"].mean()
        ),
        "seeds_with_best_at_or_after_4500": endpoint_best_count,
        "seeds_with_best_at_or_after_4900": near_endpoint_best_count,
        "seed_diagnostic_counts": {
            label: int((seed_diagnostics["policy_plateau_diagnostic"] == label).sum())
            for label in ("PLATEAU", "NOT CLEAR", "STILL IMPROVING")
        },
    }
    return curve, seed_diagnostics, aggregate


def _window_mean(frame: pd.DataFrame, column: str, mask: pd.Series) -> float:
    values = pd.to_numeric(frame.loc[mask, column], errors="coerce")
    finite = values[np.isfinite(values)]
    return float(finite.mean()) if len(finite) else float("nan")


def _window_max(frame: pd.DataFrame, column: str, mask: pd.Series) -> float:
    values = pd.to_numeric(frame.loc[mask, column], errors="coerce")
    finite = values[np.isfinite(values)]
    return float(finite.max()) if len(finite) else float("nan")


def _training_diagnostics(
    training: pd.DataFrame,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for seed in SEEDS:
        frame = training[training["seed"] == seed].sort_values("episode")
        pre = frame["episode"] <= SOURCE_EPISODES
        post = frame["episode"] > SOURCE_EPISODES
        last500 = frame["episode"] > 4500
        previous500 = (frame["episode"] > 4000) & (frame["episode"] <= 4500)
        predicted_last = _window_mean(frame, "mean_predicted_q", last500)
        target_last = _window_mean(frame, "mean_target_q", last500)
        q_gap = _window_mean(
            frame.assign(
                q_gap=(
                    pd.to_numeric(frame["mean_predicted_q"], errors="coerce")
                    - pd.to_numeric(frame["mean_target_q"], errors="coerce")
                ).abs()
            ),
            "q_gap",
            last500,
        )
        monitored = (
            "mean_loss",
            "last_loss",
            "mean_predicted_q",
            "mean_target_q",
            "mean_gradient_norm",
            "raw_episode_cascade_generation_gwh",
            "normalized_episode_reward",
            "epsilon",
        )
        nonfinite_post = 0
        for column in monitored:
            values = pd.to_numeric(frame.loc[post, column], errors="coerce")
            nonfinite_post += int(
                (~np.isfinite(values.to_numpy(dtype=float))).sum()
            )

        loss_last = _window_mean(frame, "mean_loss", last500)
        loss_previous = _window_mean(frame, "mean_loss", previous500)
        q_magnitude_last = max(abs(predicted_last), abs(target_last))
        q_magnitude_previous = max(
            abs(_window_mean(frame, "mean_predicted_q", previous500)),
            abs(_window_mean(frame, "mean_target_q", previous500)),
        )
        gradient_last = _window_mean(frame, "mean_gradient_norm", last500)
        gradient_previous = _window_mean(
            frame, "mean_gradient_norm", previous500
        )
        generation_last = _window_mean(
            frame, "raw_episode_cascade_generation_gwh", last500
        )
        generation_previous = _window_mean(
            frame, "raw_episode_cascade_generation_gwh", previous500
        )
        epsilon_3000 = float(
            frame.loc[frame["episode"] == 3000, "epsilon"].iloc[0]
        )
        epsilon_5000 = float(
            frame.loc[frame["episode"] == 5000, "epsilon"].iloc[0]
        )
        post_epsilon = pd.to_numeric(frame.loc[post, "epsilon"], errors="coerce")
        epsilon_fixed_at_floor = bool(
            np.allclose(
                post_epsilon.to_numpy(dtype=float),
                0.01,
                rtol=0.0,
                atol=1.0e-12,
            )
        )
        loss_ratio = loss_last / max(abs(loss_previous), 1.0e-12)
        q_magnitude_ratio = q_magnitude_last / max(q_magnitude_previous, 1.0e-12)
        gradient_ratio = gradient_last / max(abs(gradient_previous), 1.0e-12)
        generation_change_percent = _relative_percent(
            generation_last - generation_previous,
            generation_previous,
        )

        unstable = bool(
            nonfinite_post > 0
            or loss_ratio > 5.0
            or q_magnitude_ratio > 5.0
            or gradient_ratio > 5.0
        )
        warning = bool(
            loss_ratio > 2.0
            or q_magnitude_ratio > 2.0
            or gradient_ratio > 2.0
            or generation_change_percent < -5.0
            or not epsilon_fixed_at_floor
        )
        status = "UNSTABLE" if unstable else ("WARNING" if warning else "STABLE")
        rows.append(
            {
                "seed": seed,
                "mean_loss_0_3000": _window_mean(frame, "mean_loss", pre),
                "mean_loss_3000_5000": _window_mean(frame, "mean_loss", post),
                "mean_loss_last500": loss_last,
                "max_loss_3000_5000": _window_max(frame, "mean_loss", post),
                "last_loss_at_5000": float(frame.iloc[-1]["last_loss"]),
                "mean_predicted_q_last500": predicted_last,
                "mean_target_q_last500": target_last,
                "q_gap_last500": q_gap,
                "q_magnitude_last500_to_previous500_ratio": q_magnitude_ratio,
                "mean_gradient_norm_last500": gradient_last,
                "max_gradient_norm_3000_5000": _window_max(
                    frame, "mean_gradient_norm", post
                ),
                "gradient_last500_to_previous500_ratio": gradient_ratio,
                "mean_training_generation_0_3000": _window_mean(
                    frame, "raw_episode_cascade_generation_gwh", pre
                ),
                "mean_training_generation_3000_5000": _window_mean(
                    frame, "raw_episode_cascade_generation_gwh", post
                ),
                "mean_training_generation_last500": generation_last,
                "training_generation_last500_change_percent": (
                    generation_change_percent
                ),
                "mean_normalized_reward_last500": _window_mean(
                    frame, "normalized_episode_reward", last500
                ),
                "epsilon_at_3000": epsilon_3000,
                "epsilon_at_5000": epsilon_5000,
                "epsilon_min_3000_5000": float(post_epsilon.min()),
                "epsilon_max_3000_5000": float(post_epsilon.max()),
                "epsilon_fixed_at_0_01_3000_5000": epsilon_fixed_at_floor,
                "nonfinite_post_3000_count": nonfinite_post,
                "training_numerical_stability": status,
            }
        )

    diagnostics = pd.DataFrame(rows)
    if (diagnostics["training_numerical_stability"] == "UNSTABLE").any():
        aggregate_status = "UNSTABLE"
    elif (diagnostics["training_numerical_stability"] == "WARNING").any():
        aggregate_status = "WARNING"
    else:
        aggregate_status = "STABLE"
    aggregate = {
        "training_numerical_stability": aggregate_status,
        "seed_statuses": {
            str(row.seed): row.training_numerical_stability
            for row in diagnostics.itertuples(index=False)
        },
        "all_seeds_epsilon_at_3000": {
            str(row.seed): float(row.epsilon_at_3000)
            for row in diagnostics.itertuples(index=False)
        },
        "all_seeds_epsilon_at_5000": {
            str(row.seed): float(row.epsilon_at_5000)
            for row in diagnostics.itertuples(index=False)
        },
        "epsilon_fixed_at_0_01_for_all_post_3000_episodes": bool(
            diagnostics["epsilon_fixed_at_0_01_3000_5000"].all()
        ),
        "interpretation": (
            "DQN bootstrap TD loss need not decrease monotonically or approach zero. "
            "Loss, Q values, gradients, reward, and epsilon diagnose numerical "
            "stability but do not independently determine the training budget."
        ),
    }
    return diagnostics, aggregate


def _recommend_budget(policy_status: str, stability_status: str) -> str:
    if stability_status == "UNSTABLE":
        return "evidence still insufficient"
    if policy_status == "PLATEAU":
        return "3000 episodes"
    if policy_status == "STILL IMPROVING":
        return "5000 episodes"
    return "evidence still insufficient"


def _write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.write_text(
        json.dumps(dict(payload), indent=2, ensure_ascii=False, sort_keys=True)
        + "\n",
        encoding="utf-8",
    )


def _add_budget_boundary(ax: plt.Axes) -> None:
    ax.axvline(
        SOURCE_EPISODES,
        color="#C00000",
        linestyle="--",
        linewidth=1.5,
        label="original 3000-episode boundary",
    )


def _write_report(
    *,
    training: pd.DataFrame,
    validation: pd.DataFrame,
    curve: pd.DataFrame,
    policy_seed_diagnostics: pd.DataFrame,
    policy_aggregate: Mapping[str, Any],
    training_diagnostics: pd.DataFrame,
    training_aggregate: Mapping[str, Any],
    recommendation: str,
    path: Path,
) -> None:
    pivot = validation.pivot(index="episode", columns="seed", values="score").sort_index()
    colors = {1: "#4472C4", 42: "#ED7D31", 100: "#70AD47"}
    with PdfPages(path) as pdf:
        # Page 1: complete validation history.
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        for seed in SEEDS:
            ax.plot(pivot.index, pivot[seed], color=colors[seed], alpha=0.4, label=f"seed {seed}")
        episodes = curve["episode"].to_numpy(dtype=float)
        mean = curve["three_seed_mean_validation"].to_numpy(dtype=float)
        std = curve["three_seed_std_validation"].to_numpy(dtype=float)
        rolling = curve["five_point_rolling_mean_validation"].to_numpy(dtype=float)
        ax.plot(episodes, mean, color="black", linewidth=2, label="three-seed mean")
        ax.fill_between(episodes, mean - std, mean + std, color="black", alpha=0.10, label="mean ± std")
        ax.plot(episodes, rolling, color="#7030A0", linewidth=2.2, label="5-point rolling mean")
        _add_budget_boundary(ax)
        ax.set_xlim(0, TARGET_EPISODES)
        ax.set_xlabel("Episode")
        ax.set_ylabel("Validation score (GWh)")
        ax.set_title("Run02 budget extension: complete development validation history")
        ax.grid(alpha=0.25)
        ax.legend(ncol=2)
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)

        # Page 2: extension interval and last-1000 trend.
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        zoom = curve[curve["episode"] >= SOURCE_EPISODES]
        for seed in SEEDS:
            subset = pivot[pivot.index >= SOURCE_EPISODES]
            ax.plot(subset.index, subset[seed], color=colors[seed], alpha=0.45, label=f"seed {seed}")
        ax.plot(zoom["episode"], zoom["three_seed_mean_validation"], color="black", linewidth=2, label="three-seed mean")
        ax.plot(zoom["episode"], zoom["five_point_rolling_mean_validation"], color="#7030A0", linewidth=2.2, label="5-point rolling mean")
        last10 = curve[curve["episode"] >= 4100]
        slope_per_episode = float(policy_aggregate["three_seed_mean_last1000_slope_gwh_per_100_episodes"]) / 100.0
        intercept = float(last10["three_seed_mean_validation"].mean() - slope_per_episode * last10["episode"].mean())
        trend = intercept + slope_per_episode * last10["episode"].to_numpy(dtype=float)
        ax.plot(last10["episode"], trend, color="#C00000", linestyle="--", linewidth=2, label="last-1000 linear trend")
        _add_budget_boundary(ax)
        ax.set_xlim(SOURCE_EPISODES, TARGET_EPISODES)
        ax.set_xlabel("Episode")
        ax.set_ylabel("Validation score (GWh)")
        ax.set_title(
            "Episodes 3000--5000\n"
            f"mean trend = {policy_aggregate['three_seed_mean_last1000_slope_gwh_per_100_episodes']:.2f} GWh per 100 episodes"
        )
        ax.grid(alpha=0.25)
        ax.legend(ncol=2)
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)

        # Page 3: best score before and after the extension boundary.
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        positions = np.arange(len(SEEDS) + 1)
        pre_values = policy_seed_diagnostics["best_validation_score_le_3000"].tolist()
        post_values = policy_seed_diagnostics["best_validation_score_3100_5000"].tolist()
        pre_values.append(float(policy_aggregate["mean_of_seed_best_validation_le_3000"]))
        post_values.append(float(policy_aggregate["mean_of_seed_best_validation_3100_5000"]))
        width = 0.36
        ax.bar(positions - width / 2, pre_values, width, label="best ≤ 3000", color="#4472C4")
        ax.bar(positions + width / 2, post_values, width, label="best 3100--5000", color="#ED7D31")
        ax.set_xticks(positions)
        ax.set_xticklabels(["seed 1", "seed 42", "seed 100", "three-seed mean"])
        ax.set_ylabel("Best validation score (GWh)")
        ax.set_title("Best validation performance before and after episode 3000")
        ax.grid(axis="y", alpha=0.25)
        ax.legend()
        for index, row in enumerate(policy_seed_diagnostics.itertuples(index=False)):
            ax.text(index, max(pre_values[index], post_values[index]), f"\nbest ep {row.best_validation_episode}", ha="center", va="bottom", fontsize=8)
        lower = min(pre_values + post_values)
        upper = max(pre_values + post_values)
        padding = max((upper - lower) * 0.20, 1.0)
        ax.set_ylim(lower - padding, upper + padding)
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)

        # Page 4: numerical convergence/plateau diagnostics.
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        ax.axis("off")
        table_rows = []
        for row in policy_seed_diagnostics.itertuples(index=False):
            table_rows.append(
                [
                    str(row.seed),
                    str(row.best_validation_episode),
                    f"{row.best_validation_score:.2f}",
                    f"{row.post_3000_best_improvement_gwh:.2f}",
                    f"{row.last1000_slope_gwh_per_100_episodes:.2f}",
                    f"{row.previous5_mean_validation_gwh:.2f}",
                    f"{row.last5_mean_validation_gwh:.2f}",
                    f"{row.last5_minus_previous5_gwh:.2f}",
                    row.policy_plateau_diagnostic,
                ]
            )
        table_rows.append(
            [
                "mean",
                "--",
                "--",
                f"{policy_aggregate['three_seed_mean_post_3000_best_improvement_gwh']:.2f}",
                f"{policy_aggregate['three_seed_mean_last1000_slope_gwh_per_100_episodes']:.2f}",
                f"{policy_aggregate['three_seed_mean_previous5_validation_gwh']:.2f}",
                f"{policy_aggregate['three_seed_mean_last5_validation_gwh']:.2f}",
                f"{policy_aggregate['three_seed_mean_last5_minus_previous5_gwh']:.2f}",
                str(policy_aggregate["policy_performance_plateau_status"]),
            ]
        )
        table = ax.table(
            cellText=table_rows,
            colLabels=["seed", "best ep", "best GWh", "post gain", "slope/100", "prev5", "last5", "difference", "diagnostic"],
            cellLoc="center",
            colLoc="center",
            bbox=[0.01, 0.38, 0.98, 0.48],
        )
        table.auto_set_font_size(False)
        table.set_fontsize(7.5)
        ax.set_title("Policy-performance plateau diagnostics", fontsize=15, pad=15)
        ax.text(0.02, 0.28, f"Conclusion A — Policy performance plateau: {policy_aggregate['policy_performance_plateau_status']}", fontsize=12, weight="bold")
        ax.text(0.02, 0.22, f"Conclusion B — Training numerical stability: {training_aggregate['training_numerical_stability']}", fontsize=12, weight="bold")
        ax.text(0.02, 0.16, f"Recommended final training budget: {recommendation}", fontsize=12, weight="bold")
        ax.text(0.02, 0.07, "Budget selection is led by development validation. Loss/Q/gradient/reward/epsilon are secondary numerical-stability evidence.", fontsize=9)
        pdf.savefig(fig)
        plt.close(fig)

        # Page 5: true DQN loss, Q-value, and gradient diagnostics.
        fig, axes = plt.subplots(3, 1, figsize=(11.7, 10.5), sharex=True)
        for seed in SEEDS:
            frame = training[training["seed"] == seed].sort_values("episode")
            loss = pd.to_numeric(frame["mean_loss"], errors="coerce")
            axes[0].plot(frame["episode"], loss, color=colors[seed], alpha=0.12)
            axes[0].plot(frame["episode"], loss.rolling(ROLLING_TRAINING_EPISODES, min_periods=1).mean(), color=colors[seed], linewidth=1.5, label=f"seed {seed}")
            predicted = pd.to_numeric(frame["mean_predicted_q"], errors="coerce").rolling(ROLLING_TRAINING_EPISODES, min_periods=1).mean()
            target = pd.to_numeric(frame["mean_target_q"], errors="coerce").rolling(ROLLING_TRAINING_EPISODES, min_periods=1).mean()
            axes[1].plot(frame["episode"], predicted, color=colors[seed], linewidth=1.4, label=f"seed {seed} predicted")
            axes[1].plot(frame["episode"], target, color=colors[seed], linewidth=1.2, linestyle="--", label=f"seed {seed} target")
            gradient = pd.to_numeric(frame["mean_gradient_norm"], errors="coerce")
            axes[2].plot(frame["episode"], gradient, color=colors[seed], alpha=0.12)
            axes[2].plot(frame["episode"], gradient.rolling(ROLLING_TRAINING_EPISODES, min_periods=1).mean(), color=colors[seed], linewidth=1.5, label=f"seed {seed}")
        axes[0].set_ylabel("Mean TD loss")
        axes[0].set_yscale("symlog", linthresh=1.0e-6)
        axes[0].set_title("Mean TD loss: raw and 50-episode rolling mean")
        axes[1].set_ylabel("Q value")
        axes[1].set_title("Predicted and Double-DQN target Q: 50-episode rolling means")
        axes[2].set_ylabel("Gradient norm")
        axes[2].set_xlabel("Episode")
        axes[2].set_title("Mean gradient norm: raw and 50-episode rolling mean")
        for ax in axes:
            _add_budget_boundary(ax)
            ax.grid(alpha=0.22)
            ax.legend(ncol=3, fontsize=7)
        fig.suptitle("DQN training diagnostics: loss, Q values, and gradients")
        fig.text(0.5, 0.01, "TD loss uses moving bootstrap targets and need not decrease monotonically or approach zero; it is not an independent stopping rule.", ha="center", fontsize=9)
        fig.tight_layout(rect=(0, 0.025, 1, 0.97))
        pdf.savefig(fig)
        plt.close(fig)

        # Page 6: training generation/reward and epsilon diagnostics.
        fig, axes = plt.subplots(3, 1, figsize=(11.7, 10.5), sharex=True)
        for seed in SEEDS:
            frame = training[training["seed"] == seed].sort_values("episode")
            generation = pd.to_numeric(frame["raw_episode_cascade_generation_gwh"], errors="coerce")
            axes[0].plot(frame["episode"], generation, color=colors[seed], alpha=0.10)
            axes[0].plot(frame["episode"], generation.rolling(ROLLING_TRAINING_EPISODES, min_periods=1).mean(), color=colors[seed], linewidth=1.5, label=f"seed {seed}")
            reward = pd.to_numeric(frame["normalized_episode_reward"], errors="coerce")
            axes[1].plot(frame["episode"], reward.rolling(ROLLING_TRAINING_EPISODES, min_periods=1).mean(), color=colors[seed], linewidth=1.5, label=f"seed {seed}")
            axes[2].plot(frame["episode"], frame["epsilon"], color=colors[seed], linewidth=1.5, label=f"seed {seed}")
        axes[0].set_ylabel("Generation (GWh)")
        axes[0].set_title("Training-window generation: raw and 50-episode rolling mean")
        axes[1].set_ylabel("Normalized reward")
        axes[1].set_title("Normalized training reward: 50-episode rolling mean")
        axes[2].set_ylabel("Epsilon")
        axes[2].set_xlabel("Episode")
        axes[2].set_title("Actual epsilon schedule")
        for ax in axes:
            _add_budget_boundary(ax)
            ax.grid(alpha=0.22)
            ax.legend(ncol=3, fontsize=8)
        fig.suptitle("DQN training diagnostics: generation, reward, and exploration")
        fig.text(0.5, 0.01, "Different 240-month hydrological windows cause natural reward variation. Epsilon should already equal 0.01 throughout episodes 3000--5000.", ha="center", fontsize=9)
        fig.tight_layout(rect=(0, 0.025, 1, 0.97))
        pdf.savefig(fig)
        plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-root",
        default=str(DEFAULT_OUTPUT_ROOT),
        help="Budget-extension output root containing the isolated experiment.",
    )
    parser.add_argument(
        "--analysis-dir",
        default=None,
        help="Optional analysis directory; default is OUTPUT_ROOT/analysis.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_root = Path(args.output_root)
    if not output_root.is_absolute():
        output_root = (ROOT / output_root).resolve()
    analysis_dir = (
        output_root / "analysis"
        if args.analysis_dir is None
        else Path(args.analysis_dir).resolve()
    )
    analysis_dir.mkdir(parents=True, exist_ok=True)

    training, validation, metadata = _read_completed_runs(output_root)
    curve, policy_seed, policy_aggregate = _validation_diagnostics(validation)
    training_seed, training_aggregate = _training_diagnostics(training)
    recommendation = _recommend_budget(
        str(policy_aggregate["policy_performance_plateau_status"]),
        str(training_aggregate["training_numerical_stability"]),
    )
    combined = {
        "experiment_id": EXPERIMENT_ID,
        "source_training_budget_episodes": SOURCE_EPISODES,
        "target_training_budget_episodes": TARGET_EPISODES,
        "validation_thresholds": {
            "plateau_slope_abs_gwh_per_100_episodes": PLATEAU_SLOPE_GWH_PER_100,
            "improving_slope_gwh_per_100_episodes": IMPROVING_SLOPE_GWH_PER_100,
            "plateau_last5_relative_abs_percent": PLATEAU_LAST5_RELATIVE_PERCENT,
            "improving_last5_relative_percent": IMPROVING_LAST5_RELATIVE_PERCENT,
            "small_post3000_best_improvement_percent": SMALL_POST3000_IMPROVEMENT_PERCENT,
            "meaningful_post3000_best_improvement_percent": MEANINGFUL_POST3000_IMPROVEMENT_PERCENT,
        },
        "training_stability_thresholds": {
            "warning_last500_to_previous500_ratio": 2.0,
            "unstable_last500_to_previous500_ratio": 5.0,
            "warning_training_generation_decline_percent": -5.0,
            "required_post3000_epsilon": 0.01,
            "any_post3000_nan_or_inf_is_unstable": True,
        },
        "policy_performance": dict(policy_aggregate),
        "training_stability": dict(training_aggregate),
        "recommended_final_training_budget": recommendation,
        "decision_priority": "development_validation_then_training_stability",
        "evaluation_data_used": False,
        "metadata_sources": [record["paths"]["metadata_json"] for record in metadata],
    }

    curve.to_csv(analysis_dir / "budget_extension_validation_curve.csv", index=False)
    policy_seed.to_csv(analysis_dir / "budget_extension_policy_diagnostics.csv", index=False)
    training_seed.to_csv(
        analysis_dir / "dqn_1m_run02_budget_extension_training_diagnostics.csv",
        index=False,
    )
    _write_json(
        analysis_dir / "dqn_1m_run02_budget_extension_summary.json",
        combined,
    )
    report_path = analysis_dir / REPORT_FILENAME
    _write_report(
        training=training,
        validation=validation,
        curve=curve,
        policy_seed_diagnostics=policy_seed,
        policy_aggregate=policy_aggregate,
        training_diagnostics=training_seed,
        training_aggregate=training_aggregate,
        recommendation=recommendation,
        path=report_path,
    )

    print("DQN Run02 budget-extension analysis completed.")
    print(
        "Policy performance plateau status:",
        policy_aggregate["policy_performance_plateau_status"],
    )
    print(
        "Training numerical stability:",
        training_aggregate["training_numerical_stability"],
    )
    print("Recommended final training budget:", recommendation)
    print("Analysis directory:", analysis_dir)
    print("PDF report:", report_path)


if __name__ == "__main__":
    main()
