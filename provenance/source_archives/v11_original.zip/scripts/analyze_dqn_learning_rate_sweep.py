"""Compare DQN learning rates using convergence and policy diagnostics."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG_DIR = ROOT / "configs" / "dqn_learning_rate_sweep_1m"
DEFAULT_ANALYSIS_DIR = (
    ROOT / "outputs" / "xiaowan_nuozhadu" / "dqn_1m_v6_learning_rate_sweep" / "analysis"
)
SEEDS = (1, 42, 100)


def _resolve(value: str | Path) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (ROOT / path).resolve()


def _slope_per_100(frame: pd.DataFrame) -> float:
    return float(
        np.polyfit(
            frame["episode"].to_numpy(dtype=float),
            frame["score"].to_numpy(dtype=float),
            1,
        )[0]
        * 100.0
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config-dir", default=str(DEFAULT_CONFIG_DIR))
    parser.add_argument("--analysis-dir", default=str(DEFAULT_ANALYSIS_DIR))
    args = parser.parse_args()

    config_dir = _resolve(args.config_dir)
    analysis_dir = _resolve(args.analysis_dir)
    manifest = json.loads(
        (config_dir / "learning_rate_manifest.json").read_text(encoding="utf-8")
    )
    candidates = manifest["candidates"]
    if len(candidates) != 5:
        raise ValueError("Expected one control and four new learning rates.")

    seed_rows: list[dict] = []
    validation_frames: list[pd.DataFrame] = []
    for candidate in candidates:
        learning_rate = float(candidate["learning_rate"])
        experiment_id = str(candidate["experiment_id"])
        output_root = _resolve(candidate["output_root"])
        for seed in SEEDS:
            run_root = (
                output_root
                / "experiments"
                / experiment_id
                / f"seed_{seed}"
                / "development"
            )
            metadata_path = run_root / "metadata.json"
            validation_path = run_root / "validation" / "history.csv"
            trajectory_path = run_root / "validation" / "validation_monthly.csv"
            for required in (metadata_path, validation_path, trajectory_path):
                if not required.is_file():
                    raise FileNotFoundError(f"Missing learning-rate result: {required}")
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            validation = pd.read_csv(validation_path).sort_values("episode")
            trajectory = pd.read_csv(trajectory_path)
            if len(validation) != 30 or len(trajectory) != 960:
                raise ValueError(f"Unexpected history length under {run_root}")
            late = validation.tail(10)
            late_mean = float(late["score"].mean())
            late_std = float(late["score"].std(ddof=1))
            best = float(validation["score"].max())
            final = float(validation.iloc[-1]["score"])
            actions = trajectory["action_index"].value_counts(normalize=True)
            seed_rows.append(
                {
                    "learning_rate": learning_rate,
                    "experiment_id": experiment_id,
                    "seed": seed,
                    "best_validation_score": best,
                    "best_validation_episode": int(
                        validation.loc[validation["score"].idxmax(), "episode"]
                    ),
                    "final_validation_score": final,
                    "late10_mean": late_mean,
                    "late10_std": late_std,
                    "late10_cv": late_std / abs(late_mean),
                    "late10_slope_gwh_per_100_episodes": _slope_per_100(late),
                    "best_to_final_drop_fraction": (best - final) / abs(best),
                    "unique_validation_actions": int(trajectory["action_index"].nunique()),
                    "maximum_action_share": float(actions.iloc[0]),
                    "xiaowan_mean_level_m": float(trajectory["r1_end_level_m"].mean()),
                    "nuozhadu_mean_level_m": float(trajectory["r2_end_level_m"].mean()),
                    "xiaowan_terminal_level_m": float(trajectory.iloc[-1]["r1_end_level_m"]),
                    "nuozhadu_terminal_level_m": float(trajectory.iloc[-1]["r2_end_level_m"]),
                    "xiaowan_reliability": float(
                        trajectory["xiaowan_firm_power_satisfied"].astype(bool).mean()
                    ),
                    "nuozhadu_reliability": float(
                        trajectory["nuozhadu_firm_power_satisfied"].astype(bool).mean()
                    ),
                    "metadata_json": str(metadata_path),
                }
            )
            copy = validation[["episode", "score"]].copy()
            copy.insert(0, "seed", seed)
            copy.insert(0, "experiment_id", experiment_id)
            copy.insert(0, "learning_rate", learning_rate)
            validation_frames.append(copy)

    seed_summary = pd.DataFrame(seed_rows).sort_values(["learning_rate", "seed"])
    validation_all = pd.concat(validation_frames, ignore_index=True)
    aggregate = (
        seed_summary.groupby("learning_rate", as_index=False)
        .agg(
            late10_mean=("late10_mean", "mean"),
            late10_seed_std=("late10_mean", "std"),
            late10_temporal_std_mean=("late10_std", "mean"),
            late10_cv_mean=("late10_cv", "mean"),
            late10_abs_slope_mean=(
                "late10_slope_gwh_per_100_episodes",
                lambda values: float(np.mean(np.abs(values))),
            ),
            best_to_final_drop_mean=("best_to_final_drop_fraction", "mean"),
            best_episode_mean=("best_validation_episode", "mean"),
            unique_actions_mean=("unique_validation_actions", "mean"),
            maximum_action_share_mean=("maximum_action_share", "mean"),
            xiaowan_mean_level_m=("xiaowan_mean_level_m", "mean"),
            nuozhadu_mean_level_m=("nuozhadu_mean_level_m", "mean"),
            xiaowan_reliability=("xiaowan_reliability", "mean"),
            nuozhadu_reliability=("nuozhadu_reliability", "mean"),
        )
        .sort_values("learning_rate", ascending=False)
        .reset_index(drop=True)
    )
    aggregate["late_cv_below_2pct"] = aggregate["late10_cv_mean"] < 0.02
    aggregate["late_slope_below_200_gwh"] = aggregate["late10_abs_slope_mean"] < 200.0
    aggregate["best_to_final_drop_below_3pct"] = (
        aggregate["best_to_final_drop_mean"] < 0.03
    )
    aggregate["stability_checks_passed"] = aggregate[
        [
            "late_cv_below_2pct",
            "late_slope_below_200_gwh",
            "best_to_final_drop_below_3pct",
        ]
    ].sum(axis=1)
    aggregate = aggregate.sort_values(
        ["stability_checks_passed", "late10_mean", "learning_rate"],
        ascending=[False, False, True],
    ).reset_index(drop=True)
    aggregate.insert(0, "diagnostic_rank", np.arange(1, len(aggregate) + 1))

    analysis_dir.mkdir(parents=True, exist_ok=True)
    seed_summary.to_csv(analysis_dir / "learning_rate_seed_summary.csv", index=False)
    aggregate.to_csv(analysis_dir / "learning_rate_summary.csv", index=False)
    validation_all.to_csv(analysis_dir / "learning_rate_validation_history.csv", index=False)

    rates = sorted(validation_all["learning_rate"].unique(), reverse=True)
    fig, axes = plt.subplots(2, 3, figsize=(15, 8.5), sharex=True, sharey=True)
    for ax, learning_rate in zip(axes.flat, rates, strict=False):
        subset = validation_all[validation_all["learning_rate"] == learning_rate]
        pivot = subset.pivot(index="episode", columns="seed", values="score").sort_index()
        for seed in pivot.columns:
            ax.plot(pivot.index, pivot[seed], alpha=0.38, linewidth=1.0, label=f"seed {seed}")
        mean = pivot.mean(axis=1)
        std = pivot.std(axis=1)
        x = mean.index.to_numpy(dtype=float)
        y = mean.to_numpy(dtype=float)
        s = std.to_numpy(dtype=float)
        ax.plot(x, y, color="black", linewidth=2.2, label="mean")
        ax.fill_between(x, y - s, y + s, color="black", alpha=0.10)
        ax.set_title(f"learning rate = {learning_rate:.0e}")
        ax.grid(alpha=0.22)
    for ax in axes.flat[len(rates):]:
        ax.axis("off")
    for ax in axes[-1, :]:
        ax.set_xlabel("Episode")
    for ax in axes[:, 0]:
        ax.set_ylabel("Validation reward (GWh/year)")
    handles, labels = axes.flat[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=4, frameon=False)
    fig.suptitle("DQN learning-rate convergence diagnostic", y=0.99)
    fig.tight_layout(rect=(0, 0, 1, 0.95))
    fig.savefig(analysis_dir / "learning_rate_validation_curves.png", dpi=300)
    fig.savefig(analysis_dir / "learning_rate_validation_curves.pdf")
    plt.close(fig)

    print("Completed DQN learning-rate analysis.")
    print(aggregate.to_string(index=False))
    print(f"Analysis directory: {analysis_dir}")


if __name__ == "__main__":
    main()
