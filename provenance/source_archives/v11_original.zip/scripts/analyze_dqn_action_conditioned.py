"""Summarize V11 action-conditioned physical baseline evaluation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
SEEDS = (1, 42, 100)
EXPERIMENT_ID = "dqn_1m_v11_action_conditioned_gamma097_lambda4000"
REFERENCE_EXPERIMENT_ID = "dqn_1m_v6_penalty_lambda_4000p00"
DEFAULT_OUTPUT_ROOT = (
    ROOT
    / "outputs"
    / "xiaowan_nuozhadu"
    / "dqn_1m_v11_action_conditioned_gamma097_lambda4000"
)


def _resolve(value: str | Path) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (ROOT / path).resolve()


def _as_bool(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series
    normalized = series.astype(str).str.strip().str.lower()
    if not normalized.isin({"true", "false"}).all():
        raise ValueError(f"Cannot interpret {series.name} as Boolean values.")
    return normalized.eq("true")


def _run_root(output_root: Path, experiment_id: str, seed: int) -> Path:
    return output_root / "experiments" / experiment_id / f"seed_{seed}" / "final"


def _metrics(
    output_root: Path, experiment_id: str, seed: int, variant: str
) -> tuple[dict[str, float | int | str], pd.DataFrame]:
    run_root = _run_root(output_root, experiment_id, seed)
    evaluation_root = run_root / "evaluation" / "baseline"
    summary_path = evaluation_root / "summary.json"
    trajectory_path = evaluation_root / "monthly_trajectory.csv"
    for required in (summary_path, trajectory_path):
        if not required.is_file():
            raise FileNotFoundError(required)
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    trajectory = pd.read_csv(trajectory_path)
    if len(trajectory) != 4800:
        raise ValueError(f"Expected 4800 baseline months in {trajectory_path}.")
    dry = trajectory["calendar_month"].isin([11, 12, 1, 2, 3, 4])
    flood = trajectory["calendar_month"].isin([6, 7, 8, 9])
    row: dict[str, float | int | str] = {
        "variant": variant,
        "gamma": 0.97,
        "penalty_gwh": 4000.0,
        "seed": seed,
        "xiaowan_reliability_pct": float(
            _as_bool(trajectory["xiaowan_firm_power_satisfied"]).mean() * 100.0
        ),
        "nuozhadu_reliability_pct": float(
            _as_bool(trajectory["nuozhadu_firm_power_satisfied"]).mean() * 100.0
        ),
        "mean_annual_generation_gwh": float(
            (trajectory["r1_energy_gwh"] + trajectory["r2_energy_gwh"]).sum() / 400.0
        ),
        "xiaowan_mean_level_m": float(trajectory["r1_end_level_m"].mean()),
        "nuozhadu_mean_level_m": float(trajectory["r2_end_level_m"].mean()),
        "xiaowan_dry_season_mean_level_m": float(
            trajectory.loc[dry, "r1_end_level_m"].mean()
        ),
        "nuozhadu_dry_season_mean_level_m": float(
            trajectory.loc[dry, "r2_end_level_m"].mean()
        ),
        "xiaowan_flood_season_mean_level_m": float(
            trajectory.loc[flood, "r1_end_level_m"].mean()
        ),
        "nuozhadu_flood_season_mean_level_m": float(
            trajectory.loc[flood, "r2_end_level_m"].mean()
        ),
        "xiaowan_december_mean_level_m": float(
            trajectory.loc[trajectory["calendar_month"] == 12, "r1_end_level_m"].mean()
        ),
        "nuozhadu_december_mean_level_m": float(
            trajectory.loc[trajectory["calendar_month"] == 12, "r2_end_level_m"].mean()
        ),
        "xiaowan_terminal_level_m": float(trajectory.iloc[-1]["r1_end_level_m"]),
        "nuozhadu_terminal_level_m": float(trajectory.iloc[-1]["r2_end_level_m"]),
        "failed_station_months": int(trajectory["failed_station_months"].sum()),
        "checkpoint_episode": int(summary["checkpoint_episode"]),
    }
    monthly = trajectory.groupby("calendar_month", as_index=False).agg(
        xiaowan_level_m=("r1_end_level_m", "mean"),
        nuozhadu_level_m=("r2_end_level_m", "mean"),
    )
    monthly.insert(0, "seed", seed)
    monthly.insert(0, "variant", variant)
    return row, monthly


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    parser.add_argument("--analysis-dir", default=None)
    parser.add_argument("--reference-root", default=None)
    args = parser.parse_args()
    output_root = _resolve(args.output_root)
    analysis_dir = (
        _resolve(args.analysis_dir)
        if args.analysis_dir is not None
        else output_root / "analysis"
    )
    rows = []
    monthly_frames = []
    for seed in SEEDS:
        row, monthly = _metrics(output_root, EXPERIMENT_ID, seed, "action_conditioned")
        rows.append(row)
        monthly_frames.append(monthly)
    current = pd.DataFrame(rows).sort_values("seed")
    monthly_all = pd.concat(monthly_frames, ignore_index=True)
    analysis_dir.mkdir(parents=True, exist_ok=True)
    current.to_csv(analysis_dir / "action_conditioned_seed_summary.csv", index=False)
    monthly_all.to_csv(
        analysis_dir / "action_conditioned_monthly_climatology.csv", index=False
    )

    comparison = None
    if args.reference_root is not None:
        reference_rows = []
        reference_monthly = []
        reference_root = _resolve(args.reference_root)
        for seed in SEEDS:
            row, monthly = _metrics(
                reference_root, REFERENCE_EXPERIMENT_ID, seed, "v6_indexed_output"
            )
            reference_rows.append(row)
            reference_monthly.append(monthly)
        reference = pd.DataFrame(reference_rows).sort_values("seed")
        shared = [
            column
            for column in current.select_dtypes(include="number").columns
            if column in reference.columns
            and column not in {"gamma", "penalty_gwh", "seed"}
        ]
        comparison = current[["seed"]].copy()
        for column in shared:
            comparison[f"{column}_action_conditioned_minus_v6"] = (
                current[column].to_numpy() - reference[column].to_numpy()
            )
        comparison.to_csv(
            analysis_dir / "action_conditioned_minus_v6_gamma097_lambda4000.csv",
            index=False,
        )
        monthly_all = pd.concat(
            [pd.concat(reference_monthly, ignore_index=True), monthly_all],
            ignore_index=True,
        )

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
    for axis, column, title in (
        (axes[0], "xiaowan_level_m", "Xiaowan monthly mean level"),
        (axes[1], "nuozhadu_level_m", "Nuozhadu monthly mean level"),
    ):
        means = monthly_all.groupby(["variant", "calendar_month"])[column].mean()
        for variant, values in means.groupby(level=0):
            series = values.droplevel(0)
            axis.plot(series.index, series.to_numpy(), marker="o", label=str(variant))
        axis.set_title(title)
        axis.set_xlabel("Calendar month")
        axis.set_ylabel("Level (m)")
        axis.set_xticks(range(1, 13))
        axis.grid(alpha=0.22)
        axis.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(analysis_dir / "action_conditioned_storage_levels.png", dpi=300)
    fig.savefig(analysis_dir / "action_conditioned_storage_levels.pdf")
    plt.close(fig)

    print("Completed V11 action-conditioned analysis.")
    print(current.to_string(index=False))
    if comparison is not None:
        print("\nPaired action-conditioned minus V6 differences:")
        print(comparison.to_string(index=False))
    print(f"Analysis directory: {analysis_dir}")


if __name__ == "__main__":
    main()
