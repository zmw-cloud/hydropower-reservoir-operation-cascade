"""Aggregate all nine final DQN hold-out evaluations without seed selection."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
EXPERIMENT_ID = "dqn_1m_final_selected"
SCENARIOS = ("baseline", "drought", "wet")
SEEDS = (1, 42, 100)
DEFAULT_OUTPUT_ROOT = ROOT / "outputs" / "xiaowan_nuozhadu" / "dqn_1m_final"

METRICS = (
    "xiaowan_total_generation_gwh",
    "nuozhadu_total_generation_gwh",
    "cascade_total_generation_gwh",
    "xiaowan_mean_annual_generation_gwh",
    "nuozhadu_mean_annual_generation_gwh",
    "cascade_mean_annual_generation_gwh",
    "xiaowan_firm_power_reliability",
    "nuozhadu_firm_power_reliability",
    "cascade_firm_power_reliability",
    "xiaowan_spill_volume_1e9m3",
    "nuozhadu_spill_volume_1e9m3",
    "cascade_spill_volume_1e9m3",
    "xiaowan_target_unreached_count",
    "nuozhadu_target_unreached_count",
    "either_reservoir_target_unreached_count",
    "xiaowan_mean_abs_target_error_m",
    "nuozhadu_mean_abs_target_error_m",
    "max_abs_water_balance_error_m3",
    "evaluation_wall_time_seconds",
)


def _normalization_hash(value: Mapping[str, Any]) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )
    return hashlib.sha256(payload).hexdigest()


def _read_results(
    output_root: Path,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    seed_rows: list[dict[str, Any]] = []
    yearly_frames: list[pd.DataFrame] = []
    normalization_hashes: set[str] = set()
    for scenario in SCENARIOS:
        scenario_inflow_hashes: set[str] = set()
        for seed in SEEDS:
            scenario_root = (
                output_root
                / "experiments"
                / EXPERIMENT_ID
                / f"seed_{seed}"
                / "final"
                / "evaluation"
                / scenario
            )
            summary_path = scenario_root / "summary.json"
            monthly_path = scenario_root / "monthly_trajectory.csv"
            yearly_path = scenario_root / "yearly_summary.csv"
            for required in (summary_path, monthly_path, yearly_path):
                if not required.is_file():
                    raise FileNotFoundError(
                        f"Incomplete DQN evaluation {scenario} seed={seed}: {required}"
                    )
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
            if (
                summary.get("evaluation_scenario") != scenario
                or int(summary.get("seed", -1)) != seed
                or int(summary.get("monthly_trajectory_rows", -1)) != 4800
                or int(summary.get("yearly_summary_rows", -1)) != 400
                or summary.get("checkpoint_role") != "final"
                or int(summary.get("checkpoint_episode", -1)) != 3000
                or summary.get("normalization_updated_during_evaluation") is not False
                or summary.get("evaluation_data_used_for_model_selection") is not False
            ):
                raise ValueError(
                    f"DQN evaluation metadata is incompatible: {summary_path}"
                )
            missing_metrics = set(METRICS) - set(summary)
            if missing_metrics:
                raise ValueError(
                    f"DQN evaluation summary is missing: {sorted(missing_metrics)}"
                )
            monthly_rows = sum(1 for _ in monthly_path.open("r", encoding="utf-8")) - 1
            if monthly_rows != 4800:
                raise ValueError(f"Monthly row count is not 4800: {monthly_path}")
            yearly = pd.read_csv(yearly_path)
            if len(yearly) != 400 or not np.array_equal(
                yearly["year_index"].to_numpy(dtype=int), np.arange(1, 401)
            ):
                raise ValueError(f"Yearly summary is not 400 aligned years: {yearly_path}")
            normalization_hashes.add(_normalization_hash(summary["normalization"]))
            scenario_inflow_hashes.add(str(summary["evaluation_inflow_sha256"]))
            row = {
                "scenario": scenario,
                "scenario_role": summary["evaluation_scenario_role"],
                "seed": seed,
                "checkpoint": summary["checkpoint"],
                "checkpoint_episode": int(summary["checkpoint_episode"]),
                "evaluation_inflow_file": summary["evaluation_inflow_file"],
                "evaluation_inflow_sha256": summary["evaluation_inflow_sha256"],
                "normalization_sha256": _normalization_hash(
                    summary["normalization"]
                ),
            }
            row.update({metric: float(summary[metric]) for metric in METRICS})
            seed_rows.append(row)
            yearly.insert(0, "seed", seed)
            yearly.insert(0, "scenario", scenario)
            yearly_frames.append(yearly)
        if len(scenario_inflow_hashes) != 1:
            raise ValueError(f"DQN seeds used different {scenario} inflows.")
    if len(normalization_hashes) != 1:
        raise ValueError(
            "All final seeds must use the same full-training normalization, "
            "frozen across all scenarios."
        )
    return pd.DataFrame(seed_rows), pd.concat(yearly_frames, ignore_index=True)


def _aggregate(seed_summary: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for scenario in SCENARIOS:
        subset = seed_summary[seed_summary["scenario"] == scenario]
        row: dict[str, Any] = {
            "scenario": scenario,
            "scenario_role": subset["scenario_role"].iloc[0],
            "seed_count": int(len(subset)),
            "seeds": "1,42,100",
        }
        for metric in METRICS:
            values = subset[metric].to_numpy(dtype=float)
            row[f"{metric}_mean"] = float(values.mean())
            row[f"{metric}_std"] = float(values.std(ddof=1))
            row[f"{metric}_min"] = float(values.min())
            row[f"{metric}_max"] = float(values.max())
        rows.append(row)
    return pd.DataFrame(rows)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", default=str(DEFAULT_OUTPUT_ROOT))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_root = Path(args.output_root)
    if not output_root.is_absolute():
        output_root = (ROOT / output_root).resolve()
    analysis_dir = output_root / "analysis"
    analysis_dir.mkdir(parents=True, exist_ok=True)
    seed_summary, yearly = _read_results(output_root)
    aggregate = _aggregate(seed_summary)
    seed_path = analysis_dir / "dqn_final_all_scenarios_seed_summary.csv"
    aggregate_path = analysis_dir / "dqn_final_all_scenarios_aggregate.csv"
    yearly_path = analysis_dir / "dqn_final_all_scenarios_yearly.csv"
    seed_summary.to_csv(seed_path, index=False)
    aggregate.to_csv(aggregate_path, index=False)
    yearly.to_csv(yearly_path, index=False)
    metadata = {
        "experiment_id": EXPERIMENT_ID,
        "scenarios": list(SCENARIOS),
        "seeds": list(SEEDS),
        "seed_selection": "none_all_three_seeds_reported",
        "normalization": "same_full_training_normalizer_frozen_for_all_seeds_and_scenarios",
        "evaluation_data_used_for_training_or_selection": False,
        "seed_summary_csv": str(seed_path),
        "aggregate_csv": str(aggregate_path),
        "yearly_csv": str(yearly_path),
    }
    metadata_path = analysis_dir / "dqn_final_all_scenarios_summary.json"
    metadata_path.write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print("Completed DQN three-scenario aggregate analysis.")
    print("Seed summary:", seed_path)
    print("Aggregate summary:", aggregate_path)
    print("Combined yearly summary:", yearly_path)
    print("Metadata:", metadata_path)


if __name__ == "__main__":
    main()
