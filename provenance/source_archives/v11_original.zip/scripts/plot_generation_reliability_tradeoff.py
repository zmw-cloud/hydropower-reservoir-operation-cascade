from __future__ import annotations

"""Plot observed generation--firm-power reliability trade-off points.

This script only reads existing result summaries.  It does not run or modify
DDP, SDP, or ISO.  DDP and SDP use their 400-year evaluation penalty sweeps.
ISO uses the existing 80-year validation results for its 48 random-forest
hyperparameter candidates trained from the DDP lambda=1000 teacher; its
non-dominated candidates are drawn as a Pareto frontier.
"""

import json
from pathlib import Path
from typing import Callable

import matplotlib as mpl

mpl.use("Agg")

import matplotlib.pyplot as plt
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUTS_ROOT = PROJECT_ROOT / "outputs"
COMPARISON_ROOT = OUTPUTS_ROOT / "comparison_ddp_sdp_iso"
FIGURES_DIR = COMPARISON_ROOT / "figures"
TABLES_DIR = COMPARISON_ROOT / "tables"

DDP_ROOT = OUTPUTS_ROOT / "DDP" / "ddp_failure_penalty_1m_results_20260924"
SDP_ROOT = OUTPUTS_ROOT / "SDP" / "evaluation" / "sdp" / "1m" / "bilinear_continuation"
ISO_ROOT = OUTPUTS_ROOT / "ISO" / "最终评价" / "outputs" / "ISO_lambda1000_rf_coarse"

REFERENCE_RATES_PCT = (80.0, 90.0)

FONT_RC = {
    "font.family": "serif",
    "font.serif": ["Times New Roman", "DejaVu Serif"],
    "mathtext.fontset": "dejavuserif",
    "axes.unicode_minus": False,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
}

LABEL_FT = 13
TICK_FT = 11
LEGEND_FT = 10
ANNOTATION_FT = 7.5

ALGORITHM_STYLES = {
    "DDP": {"color": "#1f77b4", "marker": "o", "linestyle": "-"},
    "SDP": {"color": "#2ca02c", "marker": "s", "linestyle": "--"},
    "ISO": {"color": "#d62728", "marker": "D", "linestyle": "-"},
    # Reserved styles make later DQN/PPO additions consistent.
    "DQN": {"color": "#9467bd", "marker": "^", "linestyle": "-."},
    "PPO": {"color": "#ff7f0e", "marker": "v", "linestyle": ":"},
}


def _read_json(path: Path) -> dict:
    if not path.is_file():
        raise FileNotFoundError(path)
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _penalty_token(value: float) -> str:
    return str(int(value)) if float(value).is_integer() else f"{value:g}"


def _as_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() == "true"


def _years_from_evaluation_json(path: Path) -> float:
    months = float(_read_json(path)["months"])
    if months <= 0 or months % 12 != 0:
        raise ValueError(f"Expected complete calendar years in {path}, got {months} months")
    return months / 12.0


def load_ddp_points() -> pd.DataFrame:
    summary_path = DDP_ROOT / "failure_penalty_sweep_summary.csv"
    summary = pd.read_csv(summary_path)
    records: list[dict] = []

    for row in summary.itertuples(index=False):
        penalty = float(row.failure_penalty_gwh)
        token = _penalty_token(penalty)
        result_dir = DDP_ROOT / f"penalty_{token}"
        json_files = sorted(result_dir.glob("ddp_*evaluation*.json"))
        if len(json_files) != 1:
            raise RuntimeError(f"Expected one DDP evaluation JSON in {result_dir}, found {len(json_files)}")
        years = _years_from_evaluation_json(json_files[0])
        total_generation = float(row.generation_gwh)
        records.append(
            {
                "algorithm": "DDP",
                "candidate_id": f"penalty_{token}",
                "failure_penalty_gwh": penalty,
                "xw_guarantee_rate_pct": float(row.xiaowan_reliability_pct),
                "nzd_guarantee_rate_pct": float(row.nuozhadu_reliability_pct),
                "min_guarantee_rate_pct": min(
                    float(row.xiaowan_reliability_pct),
                    float(row.nuozhadu_reliability_pct),
                ),
                "total_generation_gwh": total_generation,
                "period_years": years,
                "mean_annual_generation_gwh": total_generation / years,
                "data_split": "evaluation",
                "is_selected": False,
                "source_is_pareto": False,
                "source_summary": str(summary_path.relative_to(PROJECT_ROOT).as_posix()),
                "source_evaluation_json": str(json_files[0].relative_to(PROJECT_ROOT).as_posix()),
            }
        )
    return pd.DataFrame.from_records(records)


def load_sdp_points() -> pd.DataFrame:
    summary_path = SDP_ROOT / "failure_penalty_sweep" / "sdp_all_failure_penalty_summary.csv"
    summary = pd.read_csv(summary_path)
    records: list[dict] = []

    for row in summary.itertuples(index=False):
        penalty = float(row.failure_penalty_gwh)
        token = _penalty_token(penalty)
        result_dir = SDP_ROOT / f"failure_penalty_{token}"
        json_files = sorted(result_dir.glob("sdp_*evaluation*.json"))
        if len(json_files) != 1:
            raise RuntimeError(f"Expected one SDP evaluation JSON in {result_dir}, found {len(json_files)}")
        years = _years_from_evaluation_json(json_files[0])
        total_generation = float(row.total_generation_gwh)
        records.append(
            {
                "algorithm": "SDP",
                "candidate_id": f"penalty_{token}",
                "failure_penalty_gwh": penalty,
                "xw_guarantee_rate_pct": float(row.xiaowan_reliability_pct),
                "nzd_guarantee_rate_pct": float(row.nuozhadu_reliability_pct),
                "min_guarantee_rate_pct": min(
                    float(row.xiaowan_reliability_pct),
                    float(row.nuozhadu_reliability_pct),
                ),
                "total_generation_gwh": total_generation,
                "period_years": years,
                "mean_annual_generation_gwh": total_generation / years,
                "data_split": "evaluation",
                "is_selected": False,
                "source_is_pareto": False,
                "source_summary": str(summary_path.relative_to(PROJECT_ROOT).as_posix()),
                "source_evaluation_json": str(json_files[0].relative_to(PROJECT_ROOT).as_posix()),
            }
        )
    return pd.DataFrame.from_records(records)


def load_iso_points() -> pd.DataFrame:
    plot_data_path = ISO_ROOT / "analysis" / "rf_reliability_generation_plot_data.csv"
    selection_path = ISO_ROOT / "development" / "best_iso_config.json"
    selection = _read_json(selection_path)
    candidates = pd.read_csv(plot_data_path)
    selected_id = str(selection["candidate_id"])
    validation_years = float(selection["split"]["validation_year_count"])
    teacher_penalty = float(selection["firm_power_failure_penalty_gwh"])

    if validation_years <= 0:
        raise ValueError(f"Invalid validation year count in {selection_path}")
    if candidates.empty:
        raise ValueError(f"No ISO validation candidates in {plot_data_path}")
    if set(candidates["model_type"].dropna().unique()) != {"random_forest"}:
        raise ValueError("ISO plot data must contain only random-forest candidates")

    records: list[dict] = []
    for row in candidates.itertuples(index=False):
        xw_rate = 100.0 * float(row.xiaowan_firm_power_reliability)
        nzd_rate = 100.0 * float(row.nuozhadu_firm_power_reliability)
        total_generation = float(row.validation_cascade_generation_gwh)
        records.append(
            {
                "algorithm": "ISO",
                "candidate_id": str(row.candidate_id),
                "failure_penalty_gwh": teacher_penalty,
                "xw_guarantee_rate_pct": xw_rate,
                "nzd_guarantee_rate_pct": nzd_rate,
                "min_guarantee_rate_pct": min(xw_rate, nzd_rate),
                "total_generation_gwh": total_generation,
                "period_years": validation_years,
                "mean_annual_generation_gwh": float(row.validation_mean_annual_generation_gwh),
                "data_split": "validation",
                "is_selected": str(row.candidate_id) == selected_id,
                "source_is_pareto": _as_bool(row.is_pareto),
                "source_summary": str(plot_data_path.relative_to(PROJECT_ROOT).as_posix()),
                "source_evaluation_json": "",
            }
        )
    return pd.DataFrame.from_records(records)


POINT_LOADERS: dict[str, Callable[[], pd.DataFrame]] = {
    "DDP": load_ddp_points,
    "SDP": load_sdp_points,
    "ISO": load_iso_points,
}


def load_tradeoff_points() -> pd.DataFrame:
    points = pd.concat([loader() for loader in POINT_LOADERS.values()], ignore_index=True)
    numeric_columns = [
        "failure_penalty_gwh",
        "xw_guarantee_rate_pct",
        "nzd_guarantee_rate_pct",
        "min_guarantee_rate_pct",
        "total_generation_gwh",
        "period_years",
        "mean_annual_generation_gwh",
    ]
    if points[numeric_columns].isna().any().any():
        raise ValueError("Trade-off data contain missing numeric values")
    for column in ("xw_guarantee_rate_pct", "nzd_guarantee_rate_pct"):
        if not points[column].between(0.0, 100.0).all():
            raise ValueError(f"Invalid guarantee rate in {column}")
    return points.sort_values(["algorithm", "failure_penalty_gwh"]).reset_index(drop=True)


def build_nearest_reference_table(points: pd.DataFrame) -> pd.DataFrame:
    records: list[dict] = []
    reservoirs = {
        "XW": "xw_guarantee_rate_pct",
        "NZD": "nzd_guarantee_rate_pct",
    }
    for reservoir, rate_column in reservoirs.items():
        for reference in REFERENCE_RATES_PCT:
            for algorithm, group in points.groupby("algorithm", sort=False):
                distances = (group[rate_column] - reference).abs()
                row = group.loc[distances.idxmin()]
                records.append(
                    {
                        "reservoir": reservoir,
                        "reference_rate_pct": reference,
                        "algorithm": algorithm,
                        "candidate_id": row["candidate_id"],
                        "failure_penalty_gwh": row["failure_penalty_gwh"],
                        "actual_guarantee_rate_pct": row[rate_column],
                        "absolute_difference_pct_points": abs(row[rate_column] - reference),
                        "mean_annual_generation_gwh": row["mean_annual_generation_gwh"],
                    }
                )
    return pd.DataFrame.from_records(records)


def build_balanced_reference_table(points: pd.DataFrame) -> pd.DataFrame:
    """Find one observed candidate per algorithm that is closest for both reservoirs.

    The primary distance is the larger of the two station-specific absolute
    deviations from the reference rate.  This keeps XW and NZD visible and does
    not replace them with an average guarantee rate.  Mean deviation and then
    higher generation are only tie breakers.
    """
    records: list[dict] = []
    for reference in REFERENCE_RATES_PCT:
        for algorithm, group in points.groupby("algorithm", sort=False):
            candidates = group.copy()
            candidates["xw_abs_difference_pct_points"] = (
                candidates["xw_guarantee_rate_pct"] - reference
            ).abs()
            candidates["nzd_abs_difference_pct_points"] = (
                candidates["nzd_guarantee_rate_pct"] - reference
            ).abs()
            candidates["max_station_abs_difference_pct_points"] = candidates[
                ["xw_abs_difference_pct_points", "nzd_abs_difference_pct_points"]
            ].max(axis=1)
            candidates["mean_station_abs_difference_pct_points"] = candidates[
                ["xw_abs_difference_pct_points", "nzd_abs_difference_pct_points"]
            ].mean(axis=1)
            row = candidates.sort_values(
                [
                    "max_station_abs_difference_pct_points",
                    "mean_station_abs_difference_pct_points",
                    "mean_annual_generation_gwh",
                ],
                ascending=[True, True, False],
            ).iloc[0]
            records.append(
                {
                    "reference_rate_pct": reference,
                    "algorithm": algorithm,
                    "candidate_id": row["candidate_id"],
                    "failure_penalty_gwh": row["failure_penalty_gwh"],
                    "xw_guarantee_rate_pct": row["xw_guarantee_rate_pct"],
                    "nzd_guarantee_rate_pct": row["nzd_guarantee_rate_pct"],
                    "min_guarantee_rate_pct": row["min_guarantee_rate_pct"],
                    "xw_abs_difference_pct_points": row["xw_abs_difference_pct_points"],
                    "nzd_abs_difference_pct_points": row["nzd_abs_difference_pct_points"],
                    "max_station_abs_difference_pct_points": row[
                        "max_station_abs_difference_pct_points"
                    ],
                    "mean_station_abs_difference_pct_points": row[
                        "mean_station_abs_difference_pct_points"
                    ],
                    "mean_annual_generation_gwh": row["mean_annual_generation_gwh"],
                }
            )
    return pd.DataFrame.from_records(records)


def _annotation_offset(algorithm: str, index: int) -> tuple[int, int]:
    if algorithm == "DDP":
        return (4, 7 if index % 2 == 0 else -11)
    if algorithm == "SDP":
        return (4, -11 if index % 2 == 0 else 7)
    return (7, 8)


def compute_pareto_front(points: pd.DataFrame, rate_column: str) -> pd.DataFrame:
    """Return points not dominated in guarantee rate and annual generation.

    Both objectives are maximized.  The result is sorted from lower to higher
    guarantee rate so joining the points produces the observed Pareto frontier
    without interpolation or smoothing.
    """
    valid = points.dropna(subset=[rate_column, "mean_annual_generation_gwh"]).copy()
    keep: list[bool] = []
    for index, row in valid.iterrows():
        at_least_as_good = (
            (valid[rate_column] >= row[rate_column])
            & (valid["mean_annual_generation_gwh"] >= row["mean_annual_generation_gwh"])
        )
        strictly_better = (
            (valid[rate_column] > row[rate_column])
            | (valid["mean_annual_generation_gwh"] > row["mean_annual_generation_gwh"])
        )
        dominated = bool((at_least_as_good & strictly_better).drop(index=index).any())
        keep.append(not dominated)
    return valid.loc[keep].sort_values(
        [rate_column, "mean_annual_generation_gwh"],
        ascending=[True, False],
    )


def _short_iso_candidate_id(candidate_id: str) -> str:
    suffix = candidate_id.rsplit("_", maxsplit=1)[-1]
    return f"RF{suffix}"


def draw_tradeoff_panel(
    ax: plt.Axes,
    points: pd.DataFrame,
    rate_column: str,
    reservoir_name: str,
    panel_label: str | None = None,
) -> None:
    for algorithm in POINT_LOADERS:
        group = points.loc[points["algorithm"] == algorithm].sort_values("failure_penalty_gwh")
        if group.empty:
            continue
        style = ALGORITHM_STYLES[algorithm]
        x = group[rate_column].to_numpy(dtype=float)
        y = group["mean_annual_generation_gwh"].to_numpy(dtype=float) / 1000.0

        if algorithm == "ISO":
            ax.scatter(
                x,
                y,
                label="ISO validation candidates",
                color=style["color"],
                marker=style["marker"],
                s=25,
                alpha=0.38,
                edgecolor="none",
                zorder=2,
            )
            frontier = compute_pareto_front(group, rate_column)
            frontier_y = frontier["mean_annual_generation_gwh"].to_numpy(dtype=float) / 1000.0
            ax.plot(
                frontier[rate_column].to_numpy(dtype=float),
                frontier_y,
                label="ISO validation Pareto frontier",
                color=style["color"],
                linestyle="-",
                marker="o",
                markersize=4.2,
                linewidth=1.7,
                zorder=4,
            )

            selected = group.loc[group["is_selected"]]
            if len(selected) != 1:
                raise ValueError(f"Expected one selected ISO model, found {len(selected)}")
            selected_row = selected.iloc[0]
            ax.scatter(
                [float(selected_row[rate_column])],
                [float(selected_row["mean_annual_generation_gwh"]) / 1000.0],
                label="ISO selected model (RF41)",
                color="#f28e2b",
                marker="D",
                s=58,
                edgecolor="black",
                linewidth=0.7,
                zorder=6,
            )

            annotation_indices = set(frontier.index) | set(selected.index)
            for annotation_number, (row_index, row) in enumerate(group.iterrows()):
                if row_index not in annotation_indices:
                    continue
                dx, dy = (5, 7 if annotation_number % 2 == 0 else -10)
                ax.annotate(
                    _short_iso_candidate_id(str(row["candidate_id"])),
                    (
                        float(row[rate_column]),
                        float(row["mean_annual_generation_gwh"]) / 1000.0,
                    ),
                    xytext=(dx, dy),
                    textcoords="offset points",
                    fontsize=ANNOTATION_FT,
                    color=style["color"],
                    zorder=7,
                )
            continue

        if len(group) > 1:
            ax.plot(
                x,
                y,
                label=algorithm,
                color=style["color"],
                linestyle=style["linestyle"],
                marker=style["marker"],
                markersize=5.0,
                linewidth=1.5,
                markeredgecolor="white",
                markeredgewidth=0.45,
                zorder=3,
            )
        annotation_indices = {group.index[0], group.index[-1]}
        for reference in REFERENCE_RATES_PCT:
            annotation_indices.add((group[rate_column] - reference).abs().idxmin())

        for index, (row_index, row) in enumerate(group.iterrows()):
            if row_index not in annotation_indices:
                continue
            penalty = _penalty_token(float(row["failure_penalty_gwh"]))
            label = f"λ={penalty}"
            dx, dy = _annotation_offset(algorithm, index)
            ax.annotate(
                label,
                (float(row[rate_column]), float(row["mean_annual_generation_gwh"]) / 1000.0),
                xytext=(dx, dy),
                textcoords="offset points",
                fontsize=ANNOTATION_FT,
                color=style["color"],
                alpha=0.95,
                zorder=5,
            )

    ax.axvline(
        80.0,
        color="#7f7f7f",
        linestyle=":",
        linewidth=1.2,
        label="80% candidate reference",
        zorder=1,
    )
    ax.axvline(
        90.0,
        color="#4d4d4d",
        linestyle="--",
        linewidth=1.2,
        label="90% target reference",
        zorder=1,
    )

    all_rates = points[rate_column]
    ax.set_xlim(max(0.0, float(all_rates.min()) - 4.0), 100.5)
    ax.set_xlabel(f"{reservoir_name} firm-power guarantee rate (%)", fontsize=LABEL_FT)
    ax.set_ylabel("Mean annual generation (TWh/yr)", fontsize=LABEL_FT)
    ax.tick_params(axis="both", labelsize=TICK_FT)
    ax.grid(True, color="0.82", linewidth=0.6, alpha=0.65)
    ax.set_axisbelow(True)
    for spine in ax.spines.values():
        spine.set_color("0.35")
        spine.set_linewidth(0.8)
    if panel_label:
        ax.text(
            0.015,
            0.985,
            panel_label,
            transform=ax.transAxes,
            ha="left",
            va="top",
            fontsize=12,
            fontweight="bold",
        )


def save_single_panel(points: pd.DataFrame, rate_column: str, reservoir_name: str, stem: str) -> None:
    with plt.rc_context(FONT_RC):
        fig, ax = plt.subplots(figsize=(8.8, 5.4), dpi=600)
        draw_tradeoff_panel(ax, points, rate_column, reservoir_name)
        ax.legend(loc="best", frameon=False, fontsize=LEGEND_FT, ncol=2)
        fig.tight_layout()
        fig.savefig(FIGURES_DIR / f"{stem}.png", dpi=600, bbox_inches="tight", pad_inches=0.03)
        fig.savefig(FIGURES_DIR / f"{stem}.pdf", format="pdf", bbox_inches="tight", pad_inches=0.03)
        plt.close(fig)


def save_combined_panel(points: pd.DataFrame) -> None:
    with plt.rc_context(FONT_RC):
        fig, axes = plt.subplots(1, 2, figsize=(14.0, 5.4), dpi=600, sharey=True)
        draw_tradeoff_panel(axes[0], points, "xw_guarantee_rate_pct", "Xiaowan", "(a)")
        draw_tradeoff_panel(axes[1], points, "nzd_guarantee_rate_pct", "Nuozhadu", "(b)")
        axes[1].set_ylabel("")

        handles, labels = axes[0].get_legend_handles_labels()
        fig.legend(
            handles,
            labels,
            loc="upper center",
            bbox_to_anchor=(0.5, 1.02),
            ncol=4,
            frameon=False,
            fontsize=LEGEND_FT,
        )
        fig.tight_layout(rect=(0.0, 0.0, 1.0, 0.84))
        stem = "fig02_generation_reliability_tradeoff_combined"
        fig.savefig(FIGURES_DIR / f"{stem}.png", dpi=600, bbox_inches="tight", pad_inches=0.03)
        fig.savefig(FIGURES_DIR / f"{stem}.pdf", format="pdf", bbox_inches="tight", pad_inches=0.03)
        plt.close(fig)


def main() -> None:
    FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    TABLES_DIR.mkdir(parents=True, exist_ok=True)

    points = load_tradeoff_points()
    nearest = build_nearest_reference_table(points)
    balanced = build_balanced_reference_table(points)
    points.to_csv(TABLES_DIR / "tradeoff_points.csv", index=False, encoding="utf-8-sig")
    nearest.to_csv(TABLES_DIR / "reference_nearest_points.csv", index=False, encoding="utf-8-sig")
    balanced.to_csv(TABLES_DIR / "reference_balanced_candidates.csv", index=False, encoding="utf-8-sig")

    iso_points = points.loc[points["algorithm"] == "ISO"]
    pareto_definitions = {
        "xw": "xw_guarantee_rate_pct",
        "nzd": "nzd_guarantee_rate_pct",
        "rmin": "min_guarantee_rate_pct",
    }
    pareto_counts: dict[str, int] = {}
    for label, rate_column in pareto_definitions.items():
        frontier = compute_pareto_front(iso_points, rate_column)
        pareto_counts[label] = len(frontier)
        frontier.to_csv(
            TABLES_DIR / f"iso_validation_pareto_front_{label}.csv",
            index=False,
            encoding="utf-8-sig",
        )

    save_single_panel(points, "xw_guarantee_rate_pct", "Xiaowan", "fig02_tradeoff_xw")
    save_single_panel(points, "nzd_guarantee_rate_pct", "Nuozhadu", "fig02_tradeoff_nzd")
    save_single_panel(
        points,
        "min_guarantee_rate_pct",
        "Weakest-station min(XW, NZD)",
        "fig02_tradeoff_rmin_auxiliary",
    )
    save_combined_panel(points)

    counts = points.groupby("algorithm").size().to_dict()
    print(f"Loaded observed points: {counts}")
    print(
        "Data split: DDP/SDP use 400-year evaluation results; "
        "ISO uses 48 existing 80-year validation candidates."
    )
    print(f"ISO validation Pareto counts: {pareto_counts}")
    print(f"Figures: {FIGURES_DIR}")
    print(f"Tables: {TABLES_DIR}")
    print("\nNearest observed points to the 80% and 90% references:")
    print(nearest.to_string(index=False))
    print("\nBalanced candidates when both station-specific rates are considered:")
    print(balanced.to_string(index=False))


if __name__ == "__main__":
    main()
