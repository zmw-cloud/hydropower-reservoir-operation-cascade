"""Generate the frozen-rank02 DQN learning-rate diagnostic configs."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
from typing import Any

import yaml


NEW_LEARNING_RATES = (3.0e-4, 1.0e-4, 3.0e-5, 1.0e-5)
CONTROL_LEARNING_RATE = 8.0e-4


def _load_yaml(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError(f"Configuration must be a mapping: {path}")
    return payload


def _lr_code(value: float) -> str:
    return f"{value:.0e}".replace("-", "m").replace("+", "p")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-config", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    parser.add_argument("--output-root", required=True)
    args = parser.parse_args()

    source_path = args.source_config.resolve()
    source = _load_yaml(source_path)
    if source.get("experiment_id") != "dqn_1m_confirmation_rank02_A3B1C1D3":
        raise ValueError(
            "The learning-rate sweep source must be actual confirmation rank02."
        )
    if float(source["agent"]["learning_rate"]) != CONTROL_LEARNING_RATE:
        raise ValueError("The confirmation control learning rate must be 8e-4.")
    expected = {
        "replay_buffer_size": 50000,
        "learning_starts": 10000,
        "batch_size": 32,
        "epsilon_decay_steps": 288000,
    }
    actual = {name: int(source["agent"][name]) for name in expected}
    if actual != expected:
        raise ValueError(
            f"Confirmation rank02 hyperparameters changed: {actual}."
        )
    if float(source["reward"]["firm_power_failure_penalty_gwh"]) != 0.0:
        raise ValueError("Learning-rate diagnostics require lambda=0.")
    if int(source["training"]["episodes"]) != 3000:
        raise ValueError("Learning-rate diagnostics require 3000 episodes.")
    if list(source["training"]["seeds"]) != [1, 42, 100]:
        raise ValueError("Learning-rate diagnostics require seeds 1, 42, 100.")

    args.destination.mkdir(parents=True, exist_ok=True)
    source_output_root = str(source["outputs"]["root"])
    records: list[dict[str, Any]] = [
        {
            "learning_rate": CONTROL_LEARNING_RATE,
            "learning_rate_code": _lr_code(CONTROL_LEARNING_RATE),
            "experiment_id": source["experiment_id"],
            "configuration": source_path.as_posix(),
            "output_root": source_output_root,
            "existing_control": True,
        }
    ]
    for learning_rate in NEW_LEARNING_RATES:
        payload = copy.deepcopy(source)
        code = _lr_code(learning_rate)
        experiment_id = f"dqn_1m_v6_lr_{code}"
        payload["experiment_id"] = experiment_id
        payload["agent"]["learning_rate"] = float(learning_rate)
        payload["outputs"]["root"] = args.output_root
        payload["learning_rate_diagnostic"] = {
            "source_config": source_path.as_posix(),
            "source_experiment_id": source["experiment_id"],
            "learning_rate": float(learning_rate),
            "all_other_hyperparameters_frozen": True,
            "firm_power_failure_penalty_gwh": 0.0,
        }
        target = args.destination / f"{experiment_id}.yaml"
        target.write_text(
            yaml.safe_dump(payload, sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        records.append(
            {
                "learning_rate": float(learning_rate),
                "learning_rate_code": code,
                "experiment_id": experiment_id,
                "configuration": target.as_posix(),
                "output_root": args.output_root,
                "existing_control": False,
            }
        )

    manifest = {
        "schema_version": 1,
        "purpose": "DQN_learning_rate_convergence_diagnostic",
        "source_experiment_id": source["experiment_id"],
        "frozen_hyperparameters": expected,
        "seeds": [1, 42, 100],
        "episodes": 3000,
        "validation_interval_episodes": 100,
        "candidates": records,
    }
    (args.destination / "learning_rate_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(manifest, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
