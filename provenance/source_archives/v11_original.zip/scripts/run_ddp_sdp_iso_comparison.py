from __future__ import annotations

"""Generate selected-result comparison figures and paper-ready CSV tables."""

import argparse
import sys
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SRC_ROOT = PROJECT_ROOT / "src"
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from cascade_reservoir_benchmark.comparison import (  # noqa: E402
    build_analysis_tables,
    load_comparison_bundle,
)
from cascade_reservoir_benchmark.comparison.plots import (  # noqa: E402
    generate_all_selected_result_outputs,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Plot selected DDP, SDP, and ISO evaluation results without rerunning algorithms."
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=PROJECT_ROOT / "configs" / "comparison_ddp_sdp_iso.yaml",
        help="Comparison configuration YAML.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_path = args.config if args.config.is_absolute() else PROJECT_ROOT / args.config
    bundle = load_comparison_bundle(PROJECT_ROOT, config_path)
    tables = build_analysis_tables(bundle)
    generate_all_selected_result_outputs(bundle, tables)

    print("Selected-result comparison completed.")
    print("No algorithm training, policy generation, or evaluation was executed.")
    print("\nSelected candidates:")
    print(
        tables.selected_performance[
            [
                "algorithm",
                "candidate_id",
                "failure_penalty_gwh",
                "mean_annual_generation_gwh",
                "xw_guarantee_rate_pct",
                "nzd_guarantee_rate_pct",
            ]
        ].to_string(index=False)
    )
    print(f"\nFigures: {bundle.output_directory / 'figures'}")
    print(f"Tables:  {bundle.output_directory / 'tables'}")


if __name__ == "__main__":
    main()
