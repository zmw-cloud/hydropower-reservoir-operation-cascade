"""Analyze the formal 1 m DQN L9 sweep and prepare confirmation candidates.

This command is deliberately post-processing only.  It reads completed
development metadata/history files, estimates L9 main effects, ranks all
3^4 additive main-effect combinations, and writes three unseen candidate
configurations.  With ``--include-confirmations`` it also writes the final
six-page twelve-configuration selection report.  It never trains, validates,
evaluates, or submits a job.
"""

from __future__ import annotations

import argparse
import copy
import itertools
import json
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
import yaml

from cascade_reservoir_benchmark.environment import CascadeSpecError


DEFAULT_CONFIG_DIR = ROOT / "configs" / "dqn_sweeps_1m"
DEFAULT_ANALYSIS_DIR = (
    ROOT / "outputs" / "xiaowan_nuozhadu" / "dqn_1m_v6_formal" / "analysis"
)
SEEDS = (1, 42, 100)
FACTOR_ORDER = (
    "replay_buffer_size",
    "learning_starts",
    "batch_size",
    "epsilon_decay_steps",
)
FACTOR_LABELS = {
    "replay_buffer_size": "Replay buffer size",
    "learning_starts": "Learning starts",
    "batch_size": "Batch size",
    "epsilon_decay_steps": "Epsilon decay steps",
}
FACTOR_CODES = {
    "replay_buffer_size": "A",
    "learning_starts": "B",
    "batch_size": "C",
    "epsilon_decay_steps": "D",
}
LEVEL_VALUES = {
    "replay_buffer_size": (10000, 20000, 50000),
    "learning_starts": (10000, 20000, 40000),
    "batch_size": (32, 64, 128),
    "epsilon_decay_steps": (72000, 144000, 288000),
}
L9_LEVELS = (
    (1, 1, 1, 1),
    (1, 2, 2, 2),
    (1, 3, 3, 3),
    (2, 1, 2, 3),
    (2, 2, 3, 1),
    (2, 3, 1, 2),
    (3, 1, 3, 2),
    (3, 2, 1, 3),
    (3, 3, 2, 1),
)
FINAL_REPORT_FILENAME = "dqn_1m_final_hyperparameter_report.pdf"


def _load_yaml(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise CascadeSpecError(f"Configuration must be a mapping: {path}")
    return payload


def _mapping(parent: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    value = parent.get(key)
    if not isinstance(value, Mapping):
        raise CascadeSpecError(f"Configuration section {key!r} must be a mapping.")
    return value


def _resolve_project_path(value: str | Path) -> Path:
    path = Path(value)
    return path.resolve() if path.is_absolute() else (ROOT / path).resolve()


def _expected_level_values(levels: Sequence[int]) -> dict[str, int]:
    return {
        factor: LEVEL_VALUES[factor][int(level) - 1]
        for factor, level in zip(FACTOR_ORDER, levels)
    }


def _level_code(levels: Sequence[int]) -> str:
    return "".join(
        f"{FACTOR_CODES[factor]}{int(level)}"
        for factor, level in zip(FACTOR_ORDER, levels)
    )


def _validate_l9_configs(config_dir: Path) -> list[tuple[Path, dict[str, Any]]]:
    loaded: list[tuple[Path, dict[str, Any]]] = []
    experiment_ids: set[str] = set()
    output_roots: set[str] = set()

    for run_number, levels in enumerate(L9_LEVELS, start=1):
        path = config_dir / f"l9_run{run_number:02d}.yaml"
        if not path.is_file():
            raise FileNotFoundError(f"Missing L9 configuration: {path}")
        config = _load_yaml(path)
        expected_id = f"dqn_1m_l9_run{run_number:02d}"
        if config.get("experiment_id") != expected_id:
            raise CascadeSpecError(
                f"{path.name} experiment_id must be {expected_id!r}."
            )
        if expected_id in experiment_ids:
            raise CascadeSpecError(f"Duplicate experiment_id: {expected_id}")
        experiment_ids.add(expected_id)

        problem = _mapping(config, "problem")
        reward = _mapping(config, "reward")
        agent = _mapping(config, "agent")
        network = _mapping(config, "network")
        training = _mapping(config, "training")
        validation = _mapping(config, "validation")
        outputs = _mapping(config, "outputs")

        if float(problem.get("action_level_step_m")) != 1.0:
            raise CascadeSpecError(f"{path.name} must use a 1.0 m action grid.")
        if int(problem.get("episode_months")) != 240:
            raise CascadeSpecError(f"{path.name} must use 240-month episodes.")
        if list(network.get("hidden_dimensions", [])) != [1536, 768, 384]:
            raise CascadeSpecError(f"{path.name} has an unexpected network shape.")
        if int(training.get("episodes")) != 3000:
            raise CascadeSpecError(f"{path.name} must use 3000 episodes.")
        if int(training.get("episode_months")) != 240:
            raise CascadeSpecError(f"{path.name} must use 240 training transitions.")
        if list(training.get("seeds", [])) != list(SEEDS):
            raise CascadeSpecError(f"{path.name} must use seeds {list(SEEDS)}.")
        if int(validation.get("interval_episodes")) != 100:
            raise CascadeSpecError(f"{path.name} must validate every 100 episodes.")
        if (
            reward.get("objective")
            != "generation_gwh_minus_penalty_gwh_per_failed_station_month"
            or float(reward.get("firm_power_failure_penalty_gwh")) != 0.0
            or float(reward.get("scale_gwh")) != 7332.48
            or reward.get("failure_definition")
            != "station_specific_monthly_power_below_firm_power"
        ):
            raise CascadeSpecError(
                f"{path.name} does not use the frozen lambda=0 V6 reward contract."
            )
        if validation.get("score") != "mean_annual_penalized_objective_gwh":
            raise CascadeSpecError(
                f"{path.name} must select checkpoints by the penalized objective."
            )

        expected_values = _expected_level_values(levels)
        for factor, expected_value in expected_values.items():
            if int(agent.get(factor)) != expected_value:
                raise CascadeSpecError(
                    f"{path.name} {factor} must be {expected_value}; "
                    f"received {agent.get(factor)!r}."
                )

        output_root = str(outputs.get("root"))
        output_roots.add(output_root)
        loaded.append((path, config))

    if len(output_roots) != 1:
        raise CascadeSpecError(
            "All formal 1 m L9 configurations must share one isolated output root."
        )
    if output_roots != {"outputs/xiaowan_nuozhadu/dqn_1m_v6_formal"}:
        raise CascadeSpecError(
            "Formal V6 DQN L9 configurations must use the isolated V6 root."
        )
    return loaded


def _late_validation_statistics(validation: pd.DataFrame) -> tuple[float, float]:
    ordered = validation.sort_values("episode")
    late = ordered.tail(5)
    late_mean = float(late["score"].mean())
    if len(late) < 2:
        return late_mean, float("nan")
    slope_per_episode = float(
        np.polyfit(
            late["episode"].to_numpy(dtype=float),
            late["score"].to_numpy(dtype=float),
            1,
        )[0]
    )
    return late_mean, slope_per_episode * 100.0


def _read_actual_runs(
    configurations: Sequence[tuple[Path, Mapping[str, Any]]],
    *,
    output_root_override: Path | None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    seed_rows: list[dict[str, Any]] = []
    validation_frames: list[pd.DataFrame] = []

    for config_path, config in configurations:
        experiment_id = str(config["experiment_id"])
        outputs = _mapping(config, "outputs")
        output_root = (
            output_root_override
            if output_root_override is not None
            else _resolve_project_path(str(outputs["root"]))
        )
        agent = _mapping(config, "agent")
        training = _mapping(config, "training")
        expected_episodes = int(training["episodes"])
        expected_validation_rows = int(
            np.ceil(
                expected_episodes
                / int(_mapping(config, "validation")["interval_episodes"])
            )
        )

        for seed in SEEDS:
            run_root = (
                output_root
                / "experiments"
                / experiment_id
                / f"seed_{seed}"
                / "development"
            )
            metadata_path = run_root / "metadata.json"
            training_path = run_root / "training" / "history.csv"
            validation_path = run_root / "validation" / "history.csv"
            best_checkpoint = run_root / "checkpoints" / "best_validation.pt"
            for required in (
                metadata_path,
                training_path,
                validation_path,
                best_checkpoint,
            ):
                if not required.is_file():
                    raise FileNotFoundError(
                        f"Incomplete result for {experiment_id} seed={seed}: {required}"
                    )

            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            training_history = pd.read_csv(training_path)
            validation_history = pd.read_csv(validation_path)
            if len(training_history) != expected_episodes:
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} has {len(training_history)} "
                    f"training rows; expected {expected_episodes}."
                )
            if len(validation_history) != expected_validation_rows:
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} has {len(validation_history)} "
                    f"validation rows; expected {expected_validation_rows}."
                )

            late_mean, late_slope = _late_validation_statistics(validation_history)
            final_validation_score = float(
                validation_history.sort_values("episode").iloc[-1]["score"]
            )
            seed_rows.append(
                {
                    "experiment_id": experiment_id,
                    "seed": seed,
                    "configuration": str(config_path),
                    "replay_buffer_size": int(agent["replay_buffer_size"]),
                    "learning_starts": int(agent["learning_starts"]),
                    "batch_size": int(agent["batch_size"]),
                    "epsilon_decay_steps": int(agent["epsilon_decay_steps"]),
                    "best_validation_score": float(
                        metadata["best_validation_score"]
                    ),
                    "best_validation_episode": int(
                        metadata["best_validation_episode"]
                    ),
                    "final_validation_score": final_validation_score,
                    "late5_validation_mean": late_mean,
                    "late5_slope_gwh_per_100_episodes": late_slope,
                    "training_wall_time_seconds": float(
                        metadata["training_wall_time_seconds"]
                    ),
                    "validation_wall_time_seconds": float(
                        metadata["validation_wall_time_seconds"]
                    ),
                    "environment_steps": int(metadata["environment_steps"]),
                    "learning_steps": int(metadata["learning_steps"]),
                }
            )
            validation_copy = validation_history.copy()
            validation_copy.insert(0, "seed", seed)
            validation_copy.insert(0, "experiment_id", experiment_id)
            validation_frames.append(validation_copy)

    return (
        pd.DataFrame(seed_rows),
        pd.concat(validation_frames, ignore_index=True),
    )


def _summarize_actual_runs(seed_summary: pd.DataFrame) -> pd.DataFrame:
    summary = (
        seed_summary.groupby("experiment_id", as_index=False)
        .agg(
            three_seed_mean_best_validation=("best_validation_score", "mean"),
            seed_std_best_validation=("best_validation_score", "std"),
            seed_min_best_validation=("best_validation_score", "min"),
            seed_max_best_validation=("best_validation_score", "max"),
            best_validation_episode_mean=("best_validation_episode", "mean"),
            best_validation_episode_min=("best_validation_episode", "min"),
            best_validation_episode_max=("best_validation_episode", "max"),
            final_validation_mean=("final_validation_score", "mean"),
            late5_validation_mean=("late5_validation_mean", "mean"),
            late5_slope_mean_gwh_per_100_episodes=(
                "late5_slope_gwh_per_100_episodes",
                "mean",
            ),
            training_wall_time_mean_seconds=("training_wall_time_seconds", "mean"),
            validation_wall_time_mean_seconds=(
                "validation_wall_time_seconds",
                "mean",
            ),
            replay_buffer_size=("replay_buffer_size", "first"),
            learning_starts=("learning_starts", "first"),
            batch_size=("batch_size", "first"),
            epsilon_decay_steps=("epsilon_decay_steps", "first"),
        )
        .sort_values(
            ["three_seed_mean_best_validation", "seed_std_best_validation"],
            ascending=[False, True],
        )
        .reset_index(drop=True)
    )
    summary.insert(0, "actual_rank", np.arange(1, len(summary) + 1))
    return summary


def _l9_seed_annotations(seed_summary: pd.DataFrame) -> pd.DataFrame:
    annotated = seed_summary.copy()
    run_lookup = {
        f"dqn_1m_l9_run{run_number:02d}": (run_number, levels)
        for run_number, levels in enumerate(L9_LEVELS, start=1)
    }
    runs: list[int] = []
    level_columns = {factor: [] for factor in FACTOR_ORDER}
    for experiment_id in annotated["experiment_id"]:
        run_number, levels = run_lookup[str(experiment_id)]
        runs.append(run_number)
        for factor, level in zip(FACTOR_ORDER, levels):
            level_columns[factor].append(int(level))
    annotated.insert(0, "l9_run", runs)
    for factor in FACTOR_ORDER:
        annotated[f"{factor}_level"] = level_columns[factor]
    return annotated


def _main_effects(
    annotated_seed_summary: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows: list[dict[str, Any]] = []
    factor_rows: list[dict[str, Any]] = []
    for factor in FACTOR_ORDER:
        level_column = f"{factor}_level"
        level_means: list[float] = []
        for level, value in enumerate(LEVEL_VALUES[factor], start=1):
            subset = annotated_seed_summary[
                annotated_seed_summary[level_column] == level
            ]
            if len(subset) != 9:
                raise CascadeSpecError(
                    f"{factor} level {level} must contain nine seed observations."
                )
            mean_score = float(subset["best_validation_score"].mean())
            run_means = subset.groupby("l9_run")[
                "best_validation_score"
            ].mean()
            level_means.append(mean_score)
            rows.append(
                {
                    "factor_code": FACTOR_CODES[factor],
                    "factor": factor,
                    "factor_label": FACTOR_LABELS[factor],
                    "level": level,
                    "value": value,
                    "observation_count": len(subset),
                    "mean_best_validation": mean_score,
                    "std_best_validation": float(
                        subset["best_validation_score"].std(ddof=1)
                    ),
                    "std_across_three_l9_run_means": float(
                        run_means.std(ddof=1)
                    ),
                    "min_best_validation": float(
                        subset["best_validation_score"].min()
                    ),
                    "max_best_validation": float(
                        subset["best_validation_score"].max()
                    ),
                    "mean_best_validation_episode": float(
                        subset["best_validation_episode"].mean()
                    ),
                    "mean_late5_validation": float(
                        subset["late5_validation_mean"].mean()
                    ),
                    "mean_late5_slope_gwh_per_100_episodes": float(
                        subset["late5_slope_gwh_per_100_episodes"].mean()
                    ),
                }
            )
        factor_rows.append(
            {
                "factor_code": FACTOR_CODES[factor],
                "factor": factor,
                "factor_label": FACTOR_LABELS[factor],
                "range_R": max(level_means) - min(level_means),
                "predicted_best_level": int(np.argmax(level_means)) + 1,
                "predicted_best_value": LEVEL_VALUES[factor][
                    int(np.argmax(level_means))
                ],
            }
        )
    factor_summary = pd.DataFrame(factor_rows).sort_values(
        "range_R", ascending=False
    )
    factor_summary.insert(
        0, "main_effect_rank", np.arange(1, len(factor_summary) + 1)
    )
    return pd.DataFrame(rows), factor_summary


def _predicted_combinations(
    annotated_seed_summary: pd.DataFrame,
    level_effects: pd.DataFrame,
) -> pd.DataFrame:
    grand_mean = float(annotated_seed_summary["best_validation_score"].mean())
    tested = {
        tuple(levels): run_number
        for run_number, levels in enumerate(L9_LEVELS, start=1)
    }
    level_mean_lookup = {
        (str(row.factor), int(row.level)): float(row.mean_best_validation)
        for row in level_effects.itertuples(index=False)
    }
    rows: list[dict[str, Any]] = []
    for levels in itertools.product((1, 2, 3), repeat=4):
        predicted = grand_mean
        for factor, level in zip(FACTOR_ORDER, levels):
            predicted += level_mean_lookup[(factor, level)] - grand_mean
        values = _expected_level_values(levels)
        row: dict[str, Any] = {
            "level_code": _level_code(levels),
            "predicted_validation_score": float(predicted),
            "already_tested_in_l9": levels in tested,
            "matching_l9_run": tested.get(levels),
        }
        for factor, level in zip(FACTOR_ORDER, levels):
            row[f"{factor}_level"] = int(level)
            row[factor] = int(values[factor])
        rows.append(row)
    ranking = pd.DataFrame(rows).sort_values(
        ["predicted_validation_score", "level_code"],
        ascending=[False, True],
        kind="stable",
    )
    ranking.insert(0, "prediction_rank", np.arange(1, len(ranking) + 1))
    return ranking.reset_index(drop=True)


def _write_confirmation_configs(
    *,
    template: Mapping[str, Any],
    candidates: pd.DataFrame,
    directory: Path,
) -> pd.DataFrame:
    directory.mkdir(parents=True, exist_ok=True)
    manifest_rows: list[dict[str, Any]] = []
    for confirmation_rank, candidate in enumerate(
        candidates.itertuples(index=False), start=1
    ):
        payload = copy.deepcopy(dict(template))
        experiment_id = (
            f"dqn_1m_confirmation_rank{confirmation_rank:02d}_"
            f"{candidate.level_code}"
        )
        payload["experiment_id"] = experiment_id
        agent = payload["agent"]
        for factor in FACTOR_ORDER:
            agent[factor] = int(getattr(candidate, factor))
        payload["problem"]["action_level_step_m"] = 1.0
        payload["network"]["hidden_dimensions"] = [1536, 768, 384]
        payload["training"]["episodes"] = 3000
        payload["training"]["episode_months"] = 240
        payload["training"]["seeds"] = list(SEEDS)
        payload["outputs"]["root"] = (
            "outputs/xiaowan_nuozhadu/dqn_1m_v6_formal"
        )
        path = directory / f"confirmation_rank{confirmation_rank:02d}.yaml"
        path.write_text(
            yaml.safe_dump(payload, sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        manifest_rows.append(
            {
                "confirmation_rank": confirmation_rank,
                "configuration": str(path),
                "experiment_id": experiment_id,
                "prediction_rank": int(candidate.prediction_rank),
                "level_code": candidate.level_code,
                "predicted_validation_score": float(
                    candidate.predicted_validation_score
                ),
                **{
                    factor: int(getattr(candidate, factor))
                    for factor in FACTOR_ORDER
                },
            }
        )
    return pd.DataFrame(manifest_rows)


def _write_pdf_report(
    *,
    run_summary: pd.DataFrame,
    level_effects: pd.DataFrame,
    validation_history: pd.DataFrame,
    path: Path,
) -> None:
    with PdfPages(path) as pdf:
        ranked = run_summary.sort_values(
            "three_seed_mean_best_validation", ascending=True
        )
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        positions = np.arange(len(ranked))
        ax.barh(
            positions,
            ranked["three_seed_mean_best_validation"],
            xerr=ranked["seed_std_best_validation"],
            color="#4472C4",
            alpha=0.85,
            capsize=4,
        )
        ax.set_yticks(positions)
        ax.set_yticklabels(ranked["experiment_id"])
        ax.set_xlabel("Three-seed mean best validation score (GWh)")
        ax.set_title("Formal 1 m DQN L9 run ranking")
        ax.grid(axis="x", alpha=0.25)
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)

        fig, axes = plt.subplots(2, 2, figsize=(11.7, 8.3))
        for ax, factor in zip(axes.flat, FACTOR_ORDER):
            subset = level_effects[level_effects["factor"] == factor]
            positions = np.arange(3)
            ax.errorbar(
                positions,
                subset["mean_best_validation"],
                yerr=subset["std_best_validation"],
                marker="o",
                linewidth=2,
                capsize=5,
                color="#C00000",
            )
            ax.set_xticks(positions)
            ax.set_xticklabels([str(value) for value in subset["value"]])
            ax.set_title(FACTOR_LABELS[factor])
            ax.set_ylabel("Mean best validation score (GWh)")
            ax.grid(alpha=0.25)
        fig.suptitle("L9 main effects: level mean with seed/run variability")
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)

        fig, axes = plt.subplots(3, 3, figsize=(11.7, 10.5), sharex=True)
        for run_number, ax in enumerate(axes.flat, start=1):
            experiment_id = f"dqn_1m_l9_run{run_number:02d}"
            subset = validation_history[
                validation_history["experiment_id"] == experiment_id
            ]
            pivot = subset.pivot(
                index="episode", columns="seed", values="score"
            ).sort_index()
            for seed in pivot.columns:
                ax.plot(pivot.index, pivot[seed], alpha=0.35, linewidth=1)
            mean = pivot.mean(axis=1)
            std = pivot.std(axis=1)
            ax.plot(mean.index, mean, color="black", linewidth=2)
            ax.fill_between(
                mean.index, mean - std, mean + std, color="black", alpha=0.1
            )
            ax.set_title(f"L9 Run {run_number:02d}", fontsize=9)
            ax.grid(alpha=0.2)
        for ax in axes[-1, :]:
            ax.set_xlabel("Episode")
        for ax in axes[:, 0]:
            ax.set_ylabel("Validation score (GWh)")
        fig.suptitle("Validation histories: seeds and three-seed mean ± std")
        fig.tight_layout(rect=(0, 0, 1, 0.97))
        pdf.savefig(fig)
        plt.close(fig)


def _read_report_csv(
    analysis_dir: Path,
    filename: str,
    required_columns: Sequence[str],
) -> pd.DataFrame:
    path = analysis_dir / filename
    if not path.is_file():
        raise FileNotFoundError(f"Final DQN report input is missing: {path}")
    frame = pd.read_csv(path)
    missing = set(required_columns) - set(frame.columns)
    if missing:
        raise CascadeSpecError(
            f"{filename} is missing report columns: {sorted(missing)}"
        )
    return frame


def _short_experiment_label(experiment_id: str) -> str:
    if experiment_id.startswith("dqn_1m_l9_run"):
        return f"L9 Run {int(experiment_id[-2:]):02d}"
    if experiment_id.startswith("dqn_1m_confirmation_rank"):
        marker = experiment_id.split("confirmation_rank", 1)[1][:2]
        return f"Confirmation {int(marker):02d}"
    return experiment_id


def _write_final_hyperparameter_report(
    *,
    analysis_dir: Path,
    selected_config: Mapping[str, Any],
) -> Path:
    """Write the six-page report from persisted analysis CSV/history inputs."""
    actual_ranking = _read_report_csv(
        analysis_dir,
        "all_12_actual_ranking.csv",
        (
            "actual_rank",
            "experiment_id",
            "three_seed_mean_best_validation",
            "seed_std_best_validation",
            "best_validation_episode_mean",
            "best_validation_episode_min",
            "best_validation_episode_max",
        ),
    )
    all_seed_summary = _read_report_csv(
        analysis_dir,
        "all_12_seed_summary.csv",
        (
            "experiment_id",
            "seed",
            "best_validation_score",
            "best_validation_episode",
        ),
    )
    level_effects = _read_report_csv(
        analysis_dir,
        "l9_factor_level_effects.csv",
        (
            "factor",
            "level",
            "value",
            "mean_best_validation",
            "std_best_validation",
            "std_across_three_l9_run_means",
        ),
    )
    factor_summary = _read_report_csv(
        analysis_dir,
        "l9_factor_summary.csv",
        ("factor", "range_R", "predicted_best_level", "predicted_best_value"),
    )
    l9_validation = _read_report_csv(
        analysis_dir,
        "l9_validation_history.csv",
        ("experiment_id", "seed", "episode", "score"),
    )
    all_validation = _read_report_csv(
        analysis_dir,
        "all_12_validation_history.csv",
        ("experiment_id", "seed", "episode", "score"),
    )
    top3_predictions = _read_report_csv(
        analysis_dir,
        "l9_top3_unseen_predictions.csv",
        ("prediction_rank", "level_code", "predicted_validation_score"),
    )
    confirmation_manifest = _read_report_csv(
        analysis_dir,
        "confirmation_manifest.csv",
        (
            "confirmation_rank",
            "experiment_id",
            "level_code",
            "predicted_validation_score",
        ),
    ).sort_values("confirmation_rank")

    if len(actual_ranking) != 12 or actual_ranking["experiment_id"].nunique() != 12:
        raise CascadeSpecError("The final DQN report requires twelve actual configurations.")
    if len(all_seed_summary) != 36:
        raise CascadeSpecError("The final DQN report requires 36 completed seed runs.")
    winner = actual_ranking.sort_values("actual_rank").iloc[0]
    selected_experiment_id = str(winner["experiment_id"])
    if str(selected_config.get("experiment_id")) != selected_experiment_id:
        raise CascadeSpecError(
            "The selected YAML does not match the actual twelve-configuration winner."
        )
    if len(confirmation_manifest) != 3 or len(top3_predictions) != 3:
        raise CascadeSpecError("The final DQN report requires three confirmations.")
    prediction_check = confirmation_manifest.merge(
        top3_predictions[["level_code", "predicted_validation_score"]],
        on="level_code",
        how="inner",
        suffixes=("_manifest", "_top3"),
    )
    if len(prediction_check) != 3 or not np.allclose(
        prediction_check["predicted_validation_score_manifest"],
        prediction_check["predicted_validation_score_top3"],
        rtol=0.0,
        atol=1.0e-9,
    ):
        raise CascadeSpecError(
            "Confirmation manifest predictions differ from the persisted top-three CSV."
        )

    report_path = analysis_dir / FINAL_REPORT_FILENAME
    with PdfPages(report_path) as pdf:
        # Page 1: final ranking of all twelve actually trained configurations.
        ranked = actual_ranking.sort_values(
            "three_seed_mean_best_validation", ascending=True
        ).reset_index(drop=True)
        labels = [
            _short_experiment_label(str(value))
            + ("  [SELECTED]" if value == selected_experiment_id else "")
            for value in ranked["experiment_id"]
        ]
        colors = [
            "#2E8B57"
            if value == selected_experiment_id
            else (
                "#ED7D31"
                if str(value).startswith("dqn_1m_confirmation_rank")
                else "#4472C4"
            )
            for value in ranked["experiment_id"]
        ]
        positions = np.arange(len(ranked))
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        ax.barh(
            positions,
            ranked["three_seed_mean_best_validation"],
            xerr=ranked["seed_std_best_validation"],
            color=colors,
            alpha=0.9,
            capsize=4,
        )
        ax.set_yticks(positions)
        ax.set_yticklabels(labels)
        ax.set_xlabel("Three-seed mean best validation score (GWh)")
        ax.set_title("Final ranking of 12 actually trained DQN configurations")
        ax.grid(axis="x", alpha=0.25)
        ax.margins(x=0.12)
        ax.legend(
            handles=[
                Patch(color="#4472C4", label="L9 configuration"),
                Patch(color="#ED7D31", label="Confirmation configuration"),
                Patch(color="#2E8B57", label="Selected final configuration"),
            ],
            loc="lower right",
        )
        for position, mean, std in zip(
            positions,
            ranked["three_seed_mean_best_validation"],
            ranked["seed_std_best_validation"],
            strict=True,
        ):
            ax.text(float(mean + std), position, f"  {mean:.2f}", va="center", fontsize=8)
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)

        # Page 2: persisted L9 main effects and variability.
        fig, axes = plt.subplots(2, 2, figsize=(11.7, 8.3))
        factor_lookup = factor_summary.set_index("factor")
        for ax, factor in zip(axes.flat, FACTOR_ORDER, strict=True):
            subset = level_effects[level_effects["factor"] == factor].sort_values(
                "level"
            )
            positions = np.arange(len(subset))
            ax.errorbar(
                positions,
                subset["mean_best_validation"],
                yerr=subset["std_best_validation"],
                marker="o",
                linewidth=2,
                capsize=5,
                color="#C00000",
                label="mean ± seed/run std",
            )
            best = factor_lookup.loc[factor]
            best_level = int(best["predicted_best_level"])
            selected_point = subset[subset["level"] == best_level].iloc[0]
            ax.scatter(
                [best_level - 1],
                [selected_point["mean_best_validation"]],
                marker="*",
                s=150,
                color="#2E8B57",
                zorder=4,
            )
            ax.set_xticks(positions)
            ax.set_xticklabels([str(int(value)) for value in subset["value"]])
            ax.set_title(FACTOR_LABELS[factor])
            ax.set_ylabel("Mean best validation score (GWh)")
            ax.grid(alpha=0.25)
            ax.text(
                0.02,
                0.03,
                "Run-mean std by level: "
                + ", ".join(
                    f"{value:.1f}"
                    for value in subset["std_across_three_l9_run_means"]
                ),
                transform=ax.transAxes,
                fontsize=7,
            )
        predicted = ", ".join(
            f"{FACTOR_CODES[factor]}{int(factor_lookup.loc[factor]['predicted_best_level'])}"
            for factor in FACTOR_ORDER
        )
        fig.suptitle(f"L9 main effects and variability; predicted levels: {predicted}")
        fig.text(
            0.5,
            0.015,
            "Main-effect prediction only; confirmation experiments are required because interactions are not fully represented.",
            ha="center",
            fontsize=9,
        )
        fig.tight_layout(rect=(0, 0.04, 1, 0.95))
        pdf.savefig(fig)
        plt.close(fig)

        # Page 3: original nine L9 validation histories.
        fig, axes = plt.subplots(3, 3, figsize=(11.7, 10.5), sharex=True)
        for run_number, ax in enumerate(axes.flat, start=1):
            experiment_id = f"dqn_1m_l9_run{run_number:02d}"
            subset = l9_validation[l9_validation["experiment_id"] == experiment_id]
            pivot = subset.pivot(index="episode", columns="seed", values="score").sort_index()
            for seed in pivot.columns:
                ax.plot(pivot.index, pivot[seed], alpha=0.35, linewidth=1)
            mean = pivot.mean(axis=1)
            std = pivot.std(axis=1)
            episodes = mean.index.to_numpy(dtype=float)
            mean_values = mean.to_numpy(dtype=float)
            std_values = std.to_numpy(dtype=float)
            ax.plot(episodes, mean_values, color="black", linewidth=2)
            ax.fill_between(
                episodes,
                mean_values - std_values,
                mean_values + std_values,
                color="black",
                alpha=0.1,
            )
            ax.set_title(f"L9 Run {run_number:02d}", fontsize=9)
            ax.grid(alpha=0.2)
        for ax in axes[-1, :]:
            ax.set_xlabel("Episode")
        for ax in axes[:, 0]:
            ax.set_ylabel("Validation score (GWh)")
        fig.suptitle("L9 validation histories: three seeds and mean ± std")
        fig.tight_layout(rect=(0, 0, 1, 0.97))
        pdf.savefig(fig)
        plt.close(fig)

        # Page 4: best actual L9 and confirmation results plus prediction accuracy.
        best_l9_experiment_id = str(
            actual_ranking[
                actual_ranking["experiment_id"].astype(str).str.startswith(
                    "dqn_1m_l9_run"
                )
            ]
            .sort_values("actual_rank")
            .iloc[0]["experiment_id"]
        )
        comparison_ids = [
            best_l9_experiment_id,
            *confirmation_manifest["experiment_id"].astype(str).tolist(),
        ]
        indexed_actual = actual_ranking.set_index("experiment_id")
        missing_ids = set(comparison_ids) - set(indexed_actual.index)
        if missing_ids:
            raise CascadeSpecError(
                f"Final DQN report is missing confirmation results: {sorted(missing_ids)}"
            )
        comparison = indexed_actual.loc[comparison_ids].reset_index()
        confirmation_actual = indexed_actual.loc[
            confirmation_manifest["experiment_id"].astype(str).tolist()
        ].reset_index()
        fig, axes = plt.subplots(1, 2, figsize=(11.7, 8.3))
        comparison_labels = [
            _short_experiment_label(value) for value in comparison["experiment_id"]
        ]
        axes[0].bar(
            np.arange(4),
            comparison["three_seed_mean_best_validation"],
            yerr=comparison["seed_std_best_validation"],
            color=["#2E8B57", "#ED7D31", "#ED7D31", "#ED7D31"],
            capsize=5,
        )
        axes[0].set_xticks(np.arange(4))
        axes[0].set_xticklabels(comparison_labels, rotation=20, ha="right")
        axes[0].set_ylabel("Actual three-seed mean best validation (GWh)")
        axes[0].set_title("Best L9 versus actual confirmation results")
        axes[0].grid(axis="y", alpha=0.25)
        actual_lower = float(
            (
                comparison["three_seed_mean_best_validation"]
                - comparison["seed_std_best_validation"]
            ).min()
        )
        actual_upper = float(
            (
                comparison["three_seed_mean_best_validation"]
                + comparison["seed_std_best_validation"]
            ).max()
        )
        actual_padding = max((actual_upper - actual_lower) * 0.2, 1.0)
        axes[0].set_ylim(actual_lower - actual_padding, actual_upper + actual_padding)

        confirmation_positions = np.arange(3)
        width = 0.36
        predicted_values = confirmation_manifest[
            "predicted_validation_score"
        ].to_numpy(dtype=float)
        actual_values = confirmation_actual[
            "three_seed_mean_best_validation"
        ].to_numpy(dtype=float)
        axes[1].bar(
            confirmation_positions - width / 2,
            predicted_values,
            width,
            label="L9 additive prediction",
            color="#A5A5A5",
        )
        axes[1].bar(
            confirmation_positions + width / 2,
            actual_values,
            width,
            label="Actual confirmation",
            color="#ED7D31",
        )
        axes[1].set_xticks(confirmation_positions)
        axes[1].set_xticklabels(["Confirmation 01", "Confirmation 02", "Confirmation 03"])
        axes[1].set_ylabel("Validation score (GWh)")
        axes[1].set_title("Predicted versus actual confirmation score")
        axes[1].legend()
        axes[1].grid(axis="y", alpha=0.25)
        comparison_lower = float(min(predicted_values.min(), actual_values.min()))
        comparison_upper = float(max(predicted_values.max(), actual_values.max()))
        comparison_padding = max(
            (comparison_upper - comparison_lower) * 0.2,
            1.0,
        )
        axes[1].set_ylim(
            comparison_lower - comparison_padding,
            comparison_upper + comparison_padding,
        )
        fig.suptitle("Best L9 and confirmation configurations under V6 physics")
        fig.tight_layout(rect=(0, 0, 1, 0.96))
        pdf.savefig(fig)
        plt.close(fig)

        # Page 5: complete validation process for the selected configuration.
        selected_history = all_validation[
            all_validation["experiment_id"] == selected_experiment_id
        ]
        selected_seeds = all_seed_summary[
            all_seed_summary["experiment_id"] == selected_experiment_id
        ].sort_values("seed")
        if set(selected_history["seed"].astype(int)) != set(SEEDS) or len(
            selected_seeds
        ) != 3:
            raise CascadeSpecError(
                "The selected configuration does not contain all three seed histories."
            )
        pivot = selected_history.pivot(
            index="episode", columns="seed", values="score"
        ).sort_index()
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        seed_colors = {1: "#4472C4", 42: "#ED7D31", 100: "#70AD47"}
        for seed in SEEDS:
            series = pivot[seed]
            ax.plot(
                series.index,
                series,
                linewidth=1.4,
                alpha=0.75,
                color=seed_colors[seed],
                label=f"seed {seed}",
            )
            seed_row = selected_seeds[selected_seeds["seed"] == seed].iloc[0]
            ax.scatter(
                [seed_row["best_validation_episode"]],
                [seed_row["best_validation_score"]],
                marker="*",
                s=160,
                color=seed_colors[seed],
                edgecolor="black",
                linewidth=0.5,
                zorder=5,
            )
        mean = pivot.mean(axis=1)
        std = pivot.std(axis=1)
        episodes = mean.index.to_numpy(dtype=float)
        mean_values = mean.to_numpy(dtype=float)
        std_values = std.to_numpy(dtype=float)
        ax.plot(episodes, mean_values, color="black", linewidth=2.5, label="three-seed mean")
        ax.fill_between(
            episodes,
            mean_values - std_values,
            mean_values + std_values,
            color="black",
            alpha=0.12,
            label="mean ± std",
        )
        selected_result = indexed_actual.loc[selected_experiment_id]
        ax.set_xlim(0, 3000)
        ax.set_xlabel("Episode")
        ax.set_ylabel("Validation score (GWh)")
        ax.set_title(
            f"Selected {selected_experiment_id} validation process\n"
            f"best episode range {int(selected_result['best_validation_episode_min'])}–"
            f"{int(selected_result['best_validation_episode_max'])}; "
            f"mean {selected_result['best_validation_episode_mean']:.1f}"
        )
        ax.grid(alpha=0.25)
        ax.legend(ncol=2)
        ax.text(
            0.01,
            0.02,
            "Stars mark each seed's persisted best-validation checkpoint. V6 training stability must be judged from the new histories rather than inherited from the earlier unmasked experiment.",
            transform=ax.transAxes,
            fontsize=9,
        )
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)

        # Page 6: frozen final configuration, read from the selected YAML.
        problem = _mapping(selected_config, "problem")
        agent = _mapping(selected_config, "agent")
        network = _mapping(selected_config, "network")
        training = _mapping(selected_config, "training")
        actual = {
            "action_level_step_m": float(problem["action_level_step_m"]),
            "replay_buffer_size": int(agent["replay_buffer_size"]),
            "learning_starts": int(agent["learning_starts"]),
            "batch_size": int(agent["batch_size"]),
            "epsilon_decay_steps": int(agent["epsilon_decay_steps"]),
            "gamma": float(agent["gamma"]),
            "episodes": int(training["episodes"]),
        }
        if (
            actual["action_level_step_m"] != 1.0
            or actual["gamma"] != 0.97
            or actual["episodes"] != 3000
            or actual["replay_buffer_size"] not in LEVEL_VALUES["replay_buffer_size"]
            or actual["learning_starts"] not in LEVEL_VALUES["learning_starts"]
            or actual["batch_size"] not in LEVEL_VALUES["batch_size"]
            or actual["epsilon_decay_steps"] not in LEVEL_VALUES["epsilon_decay_steps"]
        ):
            raise CascadeSpecError(
                "The selected YAML is outside the frozen V6 L9/confirmation design."
            )
        table_rows = [
            ("Selected development configuration", selected_experiment_id),
            ("Action discretization", f"{problem['action_level_step_m']} m"),
            ("Joint action count", "3600"),
            ("State dimension", "5"),
            ("Hidden layers", str(list(network["hidden_dimensions"]))),
            ("Learning rate", str(agent["learning_rate"])),
            ("Gamma", str(agent["gamma"])),
            ("Replay buffer size", str(agent["replay_buffer_size"])),
            ("Learning starts", str(agent["learning_starts"])),
            ("Batch size", str(agent["batch_size"])),
            ("Epsilon schedule", str(agent["epsilon_schedule"])),
            ("Epsilon start / end", f"{agent['epsilon_start']} / {agent['epsilon_end']}"),
            ("Epsilon decay steps", str(agent["epsilon_decay_steps"])),
            ("Target update interval", str(agent["target_update_interval"])),
            ("Development search budget", f"{training['episodes']} episodes"),
            ("Search interactions", str(int(training["episodes"]) * int(training["episode_months"]))),
            ("Final training budget", "to be fixed after V6 stability review"),
            ("Development seeds", " / ".join(str(seed) for seed in training["seeds"])),
            ("Selection criterion", "three-seed mean best validation score"),
        ]
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        ax.axis("off")
        ax.set_title("Final selected DQN hyperparameters", fontsize=16, pad=18)
        table = ax.table(
            cellText=table_rows,
            colLabels=["Item", "Frozen value"],
            cellLoc="left",
            colLoc="left",
            bbox=[0.05, 0.14, 0.90, 0.76],
            colWidths=[0.42, 0.58],
        )
        table.auto_set_font_size(False)
        table.set_fontsize(9)
        for column in range(2):
            table[(0, column)].set_facecolor("#D9EAD3")
            table[(0, column)].set_text_props(weight="bold")
        ax.text(
            0.5,
            0.075,
            f"Actual selected result: {selected_result['three_seed_mean_best_validation']:.6f} ± "
            f"{selected_result['seed_std_best_validation']:.6f} GWh",
            ha="center",
            fontsize=10,
            weight="bold",
        )
        ax.text(
            0.5,
            0.025,
            "Selected from twelve actually trained configurations, rather than solely from the additive L9 main-effect prediction.",
            ha="center",
            fontsize=9,
        )
        pdf.savefig(fig)
        plt.close(fig)

    return report_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Analyze completed formal 1 m DQN L9 results and generate the "
            "three highest-ranked unseen confirmation configurations."
        )
    )
    parser.add_argument(
        "--config-dir",
        default=str(DEFAULT_CONFIG_DIR),
        help="Directory containing l9_run01.yaml through l9_run09.yaml.",
    )
    parser.add_argument(
        "--analysis-dir",
        default=str(DEFAULT_ANALYSIS_DIR),
        help="Output directory for CSV, PDF, and generated candidate YAML files.",
    )
    parser.add_argument(
        "--output-root",
        default=None,
        help="Optional override of the configured formal 1 m result root.",
    )
    parser.add_argument(
        "--include-confirmations",
        action="store_true",
        help=(
            "After the nine confirmation tasks finish, also rank all twelve "
            "actually tested L9 and confirmation configurations."
        ),
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_dir = _resolve_project_path(args.config_dir)
    analysis_dir = _resolve_project_path(args.analysis_dir)
    output_root_override = (
        None if args.output_root is None else _resolve_project_path(args.output_root)
    )
    analysis_dir.mkdir(parents=True, exist_ok=True)

    configurations = _validate_l9_configs(config_dir)
    seed_summary, validation_history = _read_actual_runs(
        configurations,
        output_root_override=output_root_override,
    )
    annotated = _l9_seed_annotations(seed_summary)
    run_summary = _summarize_actual_runs(seed_summary)
    run_summary.insert(
        1,
        "l9_run",
        run_summary["experiment_id"].str.extract(r"run(\d+)")[0].astype(int),
    )
    level_effects, factor_summary = _main_effects(annotated)
    predictions = _predicted_combinations(annotated, level_effects)
    unseen_candidates = predictions[~predictions["already_tested_in_l9"]].head(3)
    generated_directory = analysis_dir / "generated_confirmation_configs"
    confirmation_manifest = _write_confirmation_configs(
        template=configurations[0][1],
        candidates=unseen_candidates,
        directory=generated_directory,
    )

    annotated.to_csv(analysis_dir / "l9_seed_summary.csv", index=False)
    run_summary.to_csv(analysis_dir / "l9_run_ranking.csv", index=False)
    level_effects.to_csv(analysis_dir / "l9_factor_level_effects.csv", index=False)
    factor_summary.to_csv(analysis_dir / "l9_factor_summary.csv", index=False)
    predictions.to_csv(analysis_dir / "l9_all_81_predictions.csv", index=False)
    unseen_candidates.to_csv(
        analysis_dir / "l9_top3_unseen_predictions.csv", index=False
    )
    confirmation_manifest.to_csv(
        analysis_dir / "confirmation_manifest.csv", index=False
    )
    validation_history.to_csv(
        analysis_dir / "l9_validation_history.csv", index=False
    )
    _write_pdf_report(
        run_summary=run_summary,
        level_effects=level_effects,
        validation_history=validation_history,
        path=analysis_dir / "l9_report.pdf",
    )

    if args.include_confirmations:
        confirmation_configurations = [
            (path, _load_yaml(path))
            for path in sorted(generated_directory.glob("confirmation_rank*.yaml"))
        ]
        if len(confirmation_configurations) != 3:
            raise CascadeSpecError(
                "Exactly three generated confirmation configurations are required."
            )
        confirmation_seed_summary, confirmation_validation_history = _read_actual_runs(
            confirmation_configurations,
            output_root_override=output_root_override,
        )
        all_seed_summary = pd.concat(
            [seed_summary, confirmation_seed_summary], ignore_index=True
        )
        all_validation_history = pd.concat(
            [validation_history, confirmation_validation_history],
            ignore_index=True,
        )
        all_actual_ranking = _summarize_actual_runs(all_seed_summary)
        all_seed_summary.to_csv(
            analysis_dir / "all_12_seed_summary.csv", index=False
        )
        all_actual_ranking.to_csv(
            analysis_dir / "all_12_actual_ranking.csv", index=False
        )
        all_validation_history.to_csv(
            analysis_dir / "all_12_validation_history.csv", index=False
        )
        selected_experiment_id = str(
            all_actual_ranking.sort_values("actual_rank").iloc[0][
                "experiment_id"
            ]
        )
        all_configurations = [
            *configurations,
            *confirmation_configurations,
        ]
        selected_matches = [
            config
            for _, config in all_configurations
            if str(config.get("experiment_id")) == selected_experiment_id
        ]
        if len(selected_matches) != 1:
            raise CascadeSpecError(
                "Cannot resolve exactly one YAML for the selected configuration."
            )
        final_report_path = _write_final_hyperparameter_report(
            analysis_dir=analysis_dir,
            selected_config=selected_matches[0],
        )

    print(f"Read {len(seed_summary)} completed L9 seed runs.")
    print("\nL9 run ranking:")
    print(
        run_summary[
            [
                "actual_rank",
                "l9_run",
                "experiment_id",
                "three_seed_mean_best_validation",
                "seed_std_best_validation",
                "best_validation_episode_mean",
                "late5_slope_mean_gwh_per_100_episodes",
            ]
        ].to_string(index=False)
    )
    print("\nFactor main-effect ranking:")
    print(factor_summary.to_string(index=False))
    print("\nTop three unseen additive predictions:")
    print(confirmation_manifest.to_string(index=False))
    print(f"\nAnalysis directory: {analysis_dir}")
    if args.include_confirmations:
        print("Wrote all_12_actual_ranking.csv after confirmation analysis.")
        print(f"Wrote final hyperparameter report: {final_report_path}")


if __name__ == "__main__":
    main()
