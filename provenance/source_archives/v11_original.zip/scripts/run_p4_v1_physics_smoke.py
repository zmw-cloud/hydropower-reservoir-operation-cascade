"""Run the configured 400-year evaluation record through the P4 V1 physics core.

This is an environment integration check, not a DDP/SDP/ISO-SURF/DQN result.
It holds both reservoirs at normal level to verify the data interface, routing,
tailwater handling, energy calculation, and water-balance accounting.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from cascade_reservoir_benchmark.data import load_configured_joint_inflows
from cascade_reservoir_benchmark.environment import CascadeReservoirEnv, load_specs_from_yaml


CONFIG = ROOT / "configs" / "xiaowan_nuozhadu_v1.yaml"
OUTPUT = ROOT / "outputs" / "xiaowan_nuozhadu" / "smoke" / "p4_v1_hold_normal_evaluation_400y.csv"


def main() -> None:
    reservoir_1, reservoir_2, config = load_specs_from_yaml(CONFIG)
    joint = load_configured_joint_inflows(config, "evaluation")
    env = CascadeReservoirEnv(
        reservoir_1,
        reservoir_2,
        local_inflows_m3s=joint[["xiaowan_inflow_m3s", "nuozhadu_local_inflow_m3s"]].to_numpy(),
        timestamps=joint["date"],
        initial_levels_m=(
            config["reservoirs"]["xiaowan"]["initial_level_m"],
            config["reservoirs"]["nuozhadu"]["initial_level_m"],
        ),
        require_energy_parameters=True,
    )
    _, reset_info = env.reset()
    rows = []
    for _ in range(len(joint)):
        _, reward, terminated, truncated, info = env.step(
            [reservoir_1.normal_level_m, reservoir_2.normal_level_m]
        )
        r1, r2 = info["reservoir_1"], info["reservoir_2"]
        rows.append(
            {
                "date": joint.iloc[len(rows)]["date"],
                "month": info["month"],
                "inflow_1_m3s": info["inflow_1_m3s"],
                "inflow_2_local_m3s": info["inflow_2_local_m3s"],
                "routed_inflow_m3s": info["routed_inflow_m3s"],
                "effective_inflow_2_m3s": info["effective_inflow_2_m3s"],
                "target_level_1_m": reservoir_1.normal_level_m,
                "target_level_2_m": reservoir_2.normal_level_m,
                "end_level_1_m": r1["end_level_m"],
                "end_level_2_m": r2["end_level_m"],
                "total_discharge_1_m3s": r1["total_discharge_m3s"],
                "total_discharge_2_m3s": r2["total_discharge_m3s"],
                "turbine_discharge_1_m3s": r1["turbine_discharge_m3s"],
                "turbine_discharge_2_m3s": r2["turbine_discharge_m3s"],
                "spill_1_m3s": r1["spill_discharge_m3s"],
                "spill_2_m3s": r2["spill_discharge_m3s"],
                "power_1_kw": r1["power_kw"],
                "power_2_kw": r2["power_kw"],
                "energy_1_gwh": r1["energy_gwh"],
                "energy_2_gwh": r2["energy_gwh"],
                "reward_gwh": reward,
                "tailwater_1_m": r1["tailwater_level_m"],
                "tailwater_2_m": r2["tailwater_level_m"],
                "tailwater_1_extrapolated": r1["tailwater_discharge_extrapolated"],
                "tailwater_2_extrapolated": r2["tailwater_discharge_extrapolated"],
                "water_balance_error_1_m3": r1["water_balance_error_m3"],
                "water_balance_error_2_m3": r2["water_balance_error_m3"],
            }
        )
        if terminated or truncated:
            break
    result = pd.DataFrame(rows)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(OUTPUT, index=False)
    summary = {
        "configuration": CONFIG.name,
        "scenario": "hold_normal_levels_evaluation_400y_physics_smoke_not_an_algorithm_result",
        "inflow_split": "evaluation_400y",
        "inflow_source": config["data"]["evaluation_inflow_file"],
        "months": int(len(result)),
        "period_start": str(result.date.min().date()),
        "period_end": str(result.date.max().date()),
        "total_energy_gwh": float(result.energy_1_gwh.sum() + result.energy_2_gwh.sum()),
        "max_abs_water_balance_error_m3": float(
            max(result.water_balance_error_1_m3.abs().max(), result.water_balance_error_2_m3.abs().max())
        ),
        "xiaowan_tailwater_extrapolated_months": int(result.tailwater_1_extrapolated.sum()),
        "nuozhadu_tailwater_extrapolated_months": int(result.tailwater_2_extrapolated.sum()),
        "assumption_register": "docs/audit/uncertain_parameter_register_p4_v1.md",
        "reset_info": reset_info,
    }
    summary_path = OUTPUT.with_suffix(".json")
    summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(f"Wrote {OUTPUT}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
