"""Analyze formal PPO L9 results and generate three unseen confirmations."""

from __future__ import annotations

import argparse
import copy
import itertools
import json
from pathlib import Path
import sys
from typing import Any, Mapping, Sequence


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
import yaml

from cascade_reservoir_benchmark.environment import CascadeSpecError


DEFAULT_CONFIG_DIR = ROOT / "configs" / "ppo_sweeps_1m"
DEFAULT_OUTPUT_ROOT = (
    ROOT
    / "outputs"
    / "xiaowan_nuozhadu"
    / "ppo_1m_v11_action_conditioned_formal"
)
SEEDS = (1, 42, 100)
FACTOR_ORDER = (
    "learning_rate",
    "clip_range",
    "normalized_entropy_coefficient",
    "gae_lambda",
)
FACTOR_CODES = {
    "learning_rate": "A",
    "clip_range": "B",
    "normalized_entropy_coefficient": "C",
    "gae_lambda": "D",
}
FACTOR_LABELS = {
    "learning_rate": "Learning rate",
    "clip_range": "Clip range",
    "normalized_entropy_coefficient": "Normalized entropy coefficient",
    "gae_lambda": "GAE lambda",
}
LEVEL_VALUES = {
    "learning_rate": (0.0001, 0.0003, 0.0006),
    "clip_range": (0.10, 0.20, 0.30),
    "normalized_entropy_coefficient": (0.00, 0.01, 0.03),
    "gae_lambda": (0.90, 0.95, 0.98),
}
L9_LEVELS = (
    (1, 1, 1, 1),
    (1, 2, 2, 2),
    (1, 3, 3, 3),
    (2, 1, 2, 3),
    (2, 2, 3, 1),
    (2, 3, 1, 2),
    (3, 1, 3, 2),
    (3, 2, 1, 3),
    (3, 3, 2, 1),
)


def _load_yaml(path: Path) -> dict[str, Any]:
    payload = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise CascadeSpecError(f"Configuration must be a mapping: {path}")
    return payload


def _mapping(parent: Mapping[str, Any], key: str) -> Mapping[str, Any]:
    value = parent.get(key)
    if not isinstance(value, Mapping):
        raise CascadeSpecError(f"Configuration section {key!r} is missing.")
    return value


def _level_values(levels: Sequence[int]) -> dict[str, float]:
    return {
        factor: LEVEL_VALUES[factor][int(level) - 1]
        for factor, level in zip(FACTOR_ORDER, levels)
    }


def _level_code(levels: Sequence[int]) -> str:
    return "".join(
        f"{FACTOR_CODES[factor]}{int(level)}"
        for factor, level in zip(FACTOR_ORDER, levels)
    )


def _validate_l9_configs(config_dir: Path) -> list[tuple[Path, dict[str, Any]]]:
    configurations: list[tuple[Path, dict[str, Any]]] = []
    for run, levels in enumerate(L9_LEVELS, start=1):
        path = config_dir / f"l9_run{run:02d}.yaml"
        if not path.is_file():
            raise FileNotFoundError(path)
        config = _load_yaml(path)
        expected_id = f"ppo_1m_l9_run{run:02d}"
        if config.get("experiment_id") != expected_id:
            raise CascadeSpecError(f"{path.name} has an invalid experiment_id.")
        problem = _mapping(config, "problem")
        reward = _mapping(config, "reward")
        ppo = _mapping(config, "ppo")
        training = _mapping(config, "training")
        network = _mapping(config, "network")
        if float(problem.get("action_level_step_m")) != 1.0:
            raise CascadeSpecError(f"{path.name} is not a 1 m configuration.")
        if float(reward.get("scale_gwh")) != 7332.48:
            raise CascadeSpecError(f"{path.name} has an invalid reward scale.")
        if int(training.get("total_environment_steps")) != 720000:
            raise CascadeSpecError(f"{path.name} must use 720000 steps.")
        if [int(item) for item in training.get("seeds", [])] != list(SEEDS):
            raise CascadeSpecError(f"{path.name} has invalid seeds.")
        if list(network.get("actor_hidden_dimensions", [])) != [512, 256]:
            raise CascadeSpecError(f"{path.name} has an invalid Actor network.")
        if list(network.get("critic_hidden_dimensions", [])) != [256, 256]:
            raise CascadeSpecError(f"{path.name} has an invalid Critic network.")
        if network.get("action_representation") != "action_conditioned":
            raise CascadeSpecError(
                f"{path.name} must use the action-conditioned Actor."
            )
        if int(network.get("action_feature_dimension", -1)) != 2:
            raise CascadeSpecError(f"{path.name} has invalid action features.")
        if int(network.get("action_score_chunk_size", -1)) != 256:
            raise CascadeSpecError(f"{path.name} has an invalid score chunk size.")
        expected = _level_values(levels)
        for factor, value in expected.items():
            if not np.isclose(float(ppo.get(factor)), value, rtol=0.0, atol=0.0):
                raise CascadeSpecError(
                    f"{path.name} {factor} is {ppo.get(factor)!r}; expected {value}."
                )
        configurations.append((path, config))
    return configurations


def _read_actual_runs(
    configurations: Sequence[tuple[Path, Mapping[str, Any]]],
    output_root: Path,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    seed_rows: list[dict[str, Any]] = []
    validation_frames: list[pd.DataFrame] = []
    for config_path, config in configurations:
        experiment_id = str(config["experiment_id"])
        ppo = _mapping(config, "ppo")
        training = _mapping(config, "training")
        for seed in SEEDS:
            run_root = (
                output_root
                / "experiments"
                / experiment_id
                / f"seed_{seed}"
                / "development"
            )
            metadata_path = run_root / "metadata.json"
            training_path = run_root / "training" / "history.csv"
            validation_path = run_root / "validation" / "history.csv"
            checkpoint_path = run_root / "checkpoints" / "best_validation.pt"
            for required in (
                metadata_path,
                training_path,
                validation_path,
                checkpoint_path,
            ):
                if not required.is_file():
                    raise FileNotFoundError(
                        f"Incomplete PPO result {experiment_id} seed={seed}: {required}"
                    )
            metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            training_history = pd.read_csv(training_path).sort_values(
                "environment_steps"
            )
            validation_history = pd.read_csv(validation_path).sort_values(
                "environment_steps"
            )
            expected_steps = int(training["total_environment_steps"])
            expected_updates = expected_steps // (
                int(training["num_envs"]) * int(training["n_steps"])
            )
            if metadata.get("experiment_id") != experiment_id:
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} metadata experiment_id differs."
                )
            if int(metadata.get("seed", -1)) != seed:
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} metadata seed differs."
                )
            if int(metadata.get("environment_steps", -1)) != expected_steps:
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} did not finish its step budget."
                )
            if int(metadata.get("completed_updates", -1)) != expected_updates:
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} has an invalid update count."
                )
            if len(training_history) != expected_updates:
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} has incomplete training history."
                )
            if (
                int(training_history.iloc[-1]["environment_steps"])
                != expected_steps
                or training_history["update_number"].duplicated().any()
                or training_history["environment_steps"].duplicated().any()
            ):
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} training history is inconsistent."
                )
            if validation_history.empty or int(
                validation_history.iloc[-1]["environment_steps"]
            ) != expected_steps:
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} lacks final-budget validation."
                )
            best_row = validation_history.loc[validation_history["score"].idxmax()]
            if not np.isclose(
                float(metadata["best_validation_score"]),
                float(best_row["score"]),
                rtol=0.0,
                atol=1.0e-9,
            ) or int(metadata["best_validation_step"]) != int(
                best_row["environment_steps"]
            ):
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} best validation metadata differs."
                )
            late_validation = validation_history.tail(5)
            slope = float(
                np.polyfit(
                    late_validation["environment_steps"].to_numpy(dtype=float),
                    late_validation["score"].to_numpy(dtype=float),
                    1,
                )[0]
                * 24000.0
            )
            late_training = training_history.tail(20)
            diagnostic_columns = (
                "policy_loss",
                "value_loss",
                "normalized_entropy",
                "effective_action_count",
                "max_action_probability",
                "approx_kl",
                "clip_fraction",
                "explained_variance",
                "gradient_norm",
            )
            missing_diagnostics = set(diagnostic_columns) - set(
                training_history.columns
            )
            if missing_diagnostics:
                raise CascadeSpecError(
                    f"{experiment_id} seed={seed} training history lacks "
                    f"diagnostics: {sorted(missing_diagnostics)}"
                )
            seed_rows.append(
                {
                    "experiment_id": experiment_id,
                    "seed": seed,
                    "configuration": str(config_path),
                    "learning_rate": float(ppo["learning_rate"]),
                    "clip_range": float(ppo["clip_range"]),
                    "normalized_entropy_coefficient": float(
                        ppo["normalized_entropy_coefficient"]
                    ),
                    "gae_lambda": float(ppo["gae_lambda"]),
                    "best_validation_score": float(
                        metadata["best_validation_score"]
                    ),
                    "best_validation_step": int(metadata["best_validation_step"]),
                    "final_validation_score": float(
                        validation_history.iloc[-1]["score"]
                    ),
                    "late5_validation_mean": float(late_validation["score"].mean()),
                    "late5_validation_slope_per_24k_steps": slope,
                    "late_normalized_entropy_mean": float(
                        late_training["normalized_entropy"].mean()
                    ),
                    "late_approx_kl_mean": float(
                        late_training["approx_kl"].mean()
                    ),
                    "late_clip_fraction_mean": float(
                        late_training["clip_fraction"].mean()
                    ),
                    "late_explained_variance_mean": float(
                        late_training["explained_variance"].mean()
                    ),
                    "late_policy_loss_mean": float(
                        late_training["policy_loss"].mean()
                    ),
                    "late_value_loss_mean": float(
                        late_training["value_loss"].mean()
                    ),
                    "late_effective_action_count_mean": float(
                        late_training["effective_action_count"].mean()
                    ),
                    "late_max_action_probability_mean": float(
                        late_training["max_action_probability"].mean()
                    ),
                    "late_gradient_norm_mean": float(
                        late_training["gradient_norm"].mean()
                    ),
                    "training_wall_time_seconds": float(
                        metadata["training_wall_time_seconds"]
                    ),
                    "validation_wall_time_seconds": float(
                        metadata["validation_wall_time_seconds"]
                    ),
                }
            )
            validation_copy = validation_history.copy()
            validation_copy.insert(0, "seed", seed)
            validation_copy.insert(0, "experiment_id", experiment_id)
            validation_frames.append(validation_copy)
    return pd.DataFrame(seed_rows), pd.concat(validation_frames, ignore_index=True)


def _run_summary(seed_summary: pd.DataFrame) -> pd.DataFrame:
    summary = seed_summary.groupby("experiment_id", as_index=False).agg(
        three_seed_mean_best_validation=("best_validation_score", "mean"),
        seed_std_best_validation=("best_validation_score", "std"),
        seed_min_best_validation=("best_validation_score", "min"),
        seed_max_best_validation=("best_validation_score", "max"),
        best_validation_step_mean=("best_validation_step", "mean"),
        best_validation_step_min=("best_validation_step", "min"),
        best_validation_step_max=("best_validation_step", "max"),
        final_validation_mean=("final_validation_score", "mean"),
        late5_validation_mean=("late5_validation_mean", "mean"),
        late5_slope_mean_per_24k_steps=(
            "late5_validation_slope_per_24k_steps", "mean"
        ),
        late_normalized_entropy_mean=("late_normalized_entropy_mean", "mean"),
        late_normalized_entropy_seed_std=("late_normalized_entropy_mean", "std"),
        late_approx_kl_mean=("late_approx_kl_mean", "mean"),
        late_approx_kl_seed_std=("late_approx_kl_mean", "std"),
        late_clip_fraction_mean=("late_clip_fraction_mean", "mean"),
        late_clip_fraction_seed_std=("late_clip_fraction_mean", "std"),
        late_explained_variance_mean=("late_explained_variance_mean", "mean"),
        late_explained_variance_seed_std=(
            "late_explained_variance_mean", "std"
        ),
        late_policy_loss_mean=("late_policy_loss_mean", "mean"),
        late_value_loss_mean=("late_value_loss_mean", "mean"),
        late_value_loss_seed_std=("late_value_loss_mean", "std"),
        late_effective_action_count_mean=(
            "late_effective_action_count_mean", "mean"
        ),
        late_effective_action_count_seed_std=(
            "late_effective_action_count_mean", "std"
        ),
        late_max_action_probability_mean=(
            "late_max_action_probability_mean", "mean"
        ),
        late_gradient_norm_mean=("late_gradient_norm_mean", "mean"),
        late_gradient_norm_seed_std=("late_gradient_norm_mean", "std"),
        training_wall_time_mean_seconds=("training_wall_time_seconds", "mean"),
        validation_wall_time_mean_seconds=("validation_wall_time_seconds", "mean"),
        learning_rate=("learning_rate", "first"),
        clip_range=("clip_range", "first"),
        normalized_entropy_coefficient=(
            "normalized_entropy_coefficient", "first"
        ),
        gae_lambda=("gae_lambda", "first"),
    )
    summary = summary.sort_values(
        ["three_seed_mean_best_validation", "seed_std_best_validation"],
        ascending=[False, True],
    ).reset_index(drop=True)
    summary.insert(0, "actual_rank", np.arange(1, len(summary) + 1))
    return summary


def _annotate_l9(seed_summary: pd.DataFrame) -> pd.DataFrame:
    result = seed_summary.copy()
    lookup = {
        f"ppo_1m_l9_run{run:02d}": (run, levels)
        for run, levels in enumerate(L9_LEVELS, start=1)
    }
    result["l9_run"] = [lookup[item][0] for item in result["experiment_id"]]
    for factor_index, factor in enumerate(FACTOR_ORDER):
        result[f"{factor}_level"] = [
            lookup[item][1][factor_index] for item in result["experiment_id"]
        ]
    return result


def _annotate_l9_run_summary(run_summary: pd.DataFrame) -> pd.DataFrame:
    result = run_summary.copy()
    lookup = {
        f"ppo_1m_l9_run{run:02d}": (run, levels)
        for run, levels in enumerate(L9_LEVELS, start=1)
    }
    result.insert(
        1,
        "l9_run",
        [lookup[str(item)][0] for item in result["experiment_id"]],
    )
    result.insert(
        2,
        "level_code",
        [_level_code(lookup[str(item)][1]) for item in result["experiment_id"]],
    )
    for factor_index, factor in enumerate(FACTOR_ORDER):
        code = FACTOR_CODES[factor]
        result[f"{code}_level"] = [
            lookup[str(item)][1][factor_index]
            for item in result["experiment_id"]
        ]
    result["normalized_entropy_coef"] = result[
        "normalized_entropy_coefficient"
    ]
    return result


def _main_effects(
    annotated: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    level_rows: list[dict[str, Any]] = []
    factor_rows: list[dict[str, Any]] = []
    for factor in FACTOR_ORDER:
        means: list[float] = []
        for level, value in enumerate(LEVEL_VALUES[factor], start=1):
            subset = annotated[annotated[f"{factor}_level"] == level]
            if len(subset) != 9:
                raise CascadeSpecError(
                    f"{factor} level {level} must have nine seed observations."
                )
            mean_score = float(subset["best_validation_score"].mean())
            run_means = subset.groupby("l9_run")["best_validation_score"].mean()
            means.append(mean_score)
            level_rows.append(
                {
                    "factor_code": FACTOR_CODES[factor],
                    "factor": factor,
                    "factor_label": FACTOR_LABELS[factor],
                    "level": level,
                    "value": value,
                    "observations": len(subset),
                    "mean_best_validation": mean_score,
                    "std_across_seed_observations": float(
                        subset["best_validation_score"].std(ddof=1)
                    ),
                    "std_across_three_run_means": float(run_means.std(ddof=1)),
                    "mean_best_validation_step": float(
                        subset["best_validation_step"].mean()
                    ),
                    "mean_late5_validation": float(
                        subset["late5_validation_mean"].mean()
                    ),
                    "mean_late5_slope_per_24k_steps": float(
                        subset["late5_validation_slope_per_24k_steps"].mean()
                    ),
                }
            )
        best_index = int(np.argmax(means))
        factor_rows.append(
            {
                "factor_code": FACTOR_CODES[factor],
                "factor": factor,
                "factor_label": FACTOR_LABELS[factor],
                "max_mean": max(means),
                "min_mean": min(means),
                "range_R": max(means) - min(means),
                "best_level": best_index + 1,
                "best_level_value": LEVEL_VALUES[factor][best_index],
                "predicted_best_level": best_index + 1,
                "predicted_best_value": LEVEL_VALUES[factor][best_index],
            }
        )
    factor_summary = pd.DataFrame(factor_rows).sort_values(
        "range_R", ascending=False
    ).reset_index(drop=True)
    factor_summary.insert(0, "main_effect_rank", np.arange(1, 5))
    factor_summary["influence_rank"] = factor_summary["main_effect_rank"]
    return pd.DataFrame(level_rows), factor_summary


def _predictions(
    annotated: pd.DataFrame,
    level_effects: pd.DataFrame,
) -> pd.DataFrame:
    grand_mean = float(annotated["best_validation_score"].mean())
    tested = {
        tuple(levels): run
        for run, levels in enumerate(L9_LEVELS, start=1)
    }
    mean_lookup = {
        (str(row.factor), int(row.level)): float(row.mean_best_validation)
        for row in level_effects.itertuples(index=False)
    }
    rows: list[dict[str, Any]] = []
    for levels in itertools.product((1, 2, 3), repeat=4):
        predicted = grand_mean + sum(
            mean_lookup[(factor, level)] - grand_mean
            for factor, level in zip(FACTOR_ORDER, levels)
        )
        values = _level_values(levels)
        row: dict[str, Any] = {
            "level_code": _level_code(levels),
            "predicted_validation_score": predicted,
            "already_tested_in_l9": levels in tested,
            "matching_l9_run": tested.get(levels),
            "already_trained_l9": levels in tested,
            "matched_l9_run_if_any": tested.get(levels),
        }
        for factor, level in zip(FACTOR_ORDER, levels):
            row[f"{factor}_level"] = level
            row[f"{FACTOR_CODES[factor]}_level"] = level
            row[factor] = values[factor]
        row["normalized_entropy_coef"] = values[
            "normalized_entropy_coefficient"
        ]
        rows.append(row)
    result = pd.DataFrame(rows).sort_values(
        ["predicted_validation_score", "level_code"],
        ascending=[False, True],
        kind="stable",
    ).reset_index(drop=True)
    result.insert(0, "prediction_rank", np.arange(1, 82))
    return result


def _write_confirmation_configs(
    template: Mapping[str, Any],
    candidates: pd.DataFrame,
    directory: Path,
) -> pd.DataFrame:
    directory.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    for confirmation_rank, candidate in enumerate(
        candidates.itertuples(index=False), start=1
    ):
        config = copy.deepcopy(dict(template))
        experiment_id = (
            f"ppo_1m_confirmation_rank{confirmation_rank:02d}_"
            f"{candidate.level_code}"
        )
        config["experiment_id"] = experiment_id
        for factor in FACTOR_ORDER:
            config["ppo"][factor] = float(getattr(candidate, factor))
        config["training"]["total_environment_steps"] = 720000
        config["training"]["seeds"] = list(SEEDS)
        config["outputs"]["root"] = (
            "outputs/xiaowan_nuozhadu/ppo_1m_v11_action_conditioned_formal"
        )
        path = directory / f"confirmation_rank{confirmation_rank:02d}.yaml"
        path.write_text(
            yaml.safe_dump(config, sort_keys=False, allow_unicode=True),
            encoding="utf-8",
        )
        rows.append(
            {
                "confirmation_rank": confirmation_rank,
                "configuration": str(path),
                "experiment_id": experiment_id,
                "prediction_rank": int(candidate.prediction_rank),
                "level_code": candidate.level_code,
                "predicted_validation_score": float(
                    candidate.predicted_validation_score
                ),
                "source_method": "additive_L9_main_effect_prediction",
                "A_level": int(candidate.A_level),
                "B_level": int(candidate.B_level),
                "C_level": int(candidate.C_level),
                "D_level": int(candidate.D_level),
                **{
                    factor: float(getattr(candidate, factor))
                    for factor in FACTOR_ORDER
                },
                "normalized_entropy_coef": float(
                    candidate.normalized_entropy_coefficient
                ),
            }
        )
    return pd.DataFrame(rows)


def _write_report(
    run_summary: pd.DataFrame,
    level_effects: pd.DataFrame,
    factor_summary: pd.DataFrame,
    predictions: pd.DataFrame,
    confirmation_manifest: pd.DataFrame,
    validation_history: pd.DataFrame,
    path: Path,
) -> None:
    with PdfPages(path) as pdf:
        ranked = run_summary.sort_values(
            "three_seed_mean_best_validation", ascending=True
        )
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        positions = np.arange(len(ranked))
        ax.barh(
            positions,
            ranked["three_seed_mean_best_validation"],
            xerr=ranked["seed_std_best_validation"],
            color="#4472C4",
            capsize=4,
        )
        ax.set_yticks(positions)
        ax.set_yticklabels(ranked["experiment_id"])
        ax.set_xlabel("Three-seed mean best validation score (GWh)")
        ax.set_title("Formal 1 m PPO L9 ranking")
        ax.grid(axis="x", alpha=0.25)
        ax.margins(x=0.12)
        for position, mean, std in zip(
            positions,
            ranked["three_seed_mean_best_validation"],
            ranked["seed_std_best_validation"],
            strict=True,
        ):
            ax.text(
                float(mean + std),
                position,
                f"  {mean:.3f}",
                va="center",
                fontsize=8,
            )
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)
        _append_effect_and_validation_pages(
            pdf,
            level_effects,
            validation_history,
        )
        _append_prediction_page(
            pdf,
            factor_summary,
            predictions,
            confirmation_manifest,
        )
        _append_diagnostics_page(pdf, run_summary)


def _append_effect_and_validation_pages(
    pdf: PdfPages,
    level_effects: pd.DataFrame,
    validation_history: pd.DataFrame,
) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(11.7, 8.3))
    factor_ranges: list[tuple[str, float]] = []
    for ax, factor in zip(axes.flat, FACTOR_ORDER):
        subset = level_effects[level_effects["factor"] == factor].sort_values(
            "level"
        )
        positions = np.arange(3)
        ax.errorbar(
            positions,
            subset["mean_best_validation"],
            yerr=subset["std_across_seed_observations"],
            marker="o",
            linewidth=2,
            capsize=5,
        )
        ax.set_xticks(positions)
        ax.set_xticklabels([str(value) for value in subset["value"]])
        range_r = float(
            subset["mean_best_validation"].max()
            - subset["mean_best_validation"].min()
        )
        factor_ranges.append((FACTOR_CODES[factor], range_r))
        ax.set_title(f"{FACTOR_LABELS[factor]}  (R={range_r:.4f})")
        ax.grid(alpha=0.25)
        for position, value in zip(
            positions,
            subset["mean_best_validation"],
            strict=True,
        ):
            ax.annotate(
                f"{value:.3f}",
                (position, value),
                xytext=(0, 7),
                textcoords="offset points",
                ha="center",
                fontsize=7,
            )
        ax.text(
            0.02,
            0.03,
            "Run-mean std: "
            + ", ".join(
                f"{value:.3f}"
                for value in subset["std_across_three_run_means"]
            ),
            transform=ax.transAxes,
            fontsize=7,
        )
    influence_order = " > ".join(
        f"{code} (R={value:.4f})"
        for code, value in sorted(
            factor_ranges, key=lambda item: item[1], reverse=True
        )
    )
    fig.suptitle("PPO L9 main effects: exact level means and variability")
    fig.text(
        0.5,
        0.015,
        f"Influence order by range R: {influence_order}",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.04, 1, 0.96))
    pdf.savefig(fig)
    plt.close(fig)

    fig, axes = plt.subplots(3, 3, figsize=(11.7, 10.5), sharex=True)
    for run, ax in enumerate(axes.flat, start=1):
        experiment_id = f"ppo_1m_l9_run{run:02d}"
        subset = validation_history[
            validation_history["experiment_id"] == experiment_id
        ]
        pivot = subset.pivot(
            index="environment_steps", columns="seed", values="score"
        ).sort_index()
        for seed in pivot.columns:
            ax.plot(pivot.index, pivot[seed], alpha=0.35, linewidth=1)
        mean = pivot.mean(axis=1)
        std = pivot.std(axis=1)
        ax.plot(mean.index, mean, color="black", linewidth=2)
        ax.fill_between(mean.index, mean - std, mean + std, color="black", alpha=0.1)
        ax.set_title(f"L9 Run {run:02d}", fontsize=9)
        ax.grid(alpha=0.2)
    for ax in axes[-1, :]:
        ax.set_xlabel("Environment interactions")
    for ax in axes[:, 0]:
        ax.set_ylabel("Validation score (GWh)")
    fig.suptitle("PPO validation histories: seeds and mean ± std")
    fig.text(
        0.5,
        0.01,
        "720000 interactions = 375 PPO rollout updates = 3000 logical 240-month windows.",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.035, 1, 0.97))
    pdf.savefig(fig)
    plt.close(fig)


def _append_prediction_page(
    pdf: PdfPages,
    factor_summary: pd.DataFrame,
    predictions: pd.DataFrame,
    confirmation_manifest: pd.DataFrame,
) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(11.7, 8.3))
    axes[0].axis("off")
    factor_table = factor_summary.sort_values("influence_rank")[
        [
            "influence_rank",
            "factor_code",
            "factor_label",
            "best_level",
            "best_level_value",
            "range_R",
        ]
    ].copy()
    factor_table["range_R"] = factor_table["range_R"].map(
        lambda value: f"{value:.4f}"
    )
    table = axes[0].table(
        cellText=factor_table.values,
        colLabels=["Rank", "Factor", "Name", "Best level", "Value", "R"],
        cellLoc="center",
        colLoc="center",
        bbox=[0.0, 0.35, 1.0, 0.48],
    )
    table.auto_set_font_size(False)
    table.set_fontsize(7.5)
    axes[0].set_title("Main-effect best levels and influence")

    axes[1].axis("off")
    unseen_top10 = predictions[~predictions["already_trained_l9"]].head(10).copy()
    confirmation_rank_by_code = {
        str(row.level_code): int(row.confirmation_rank)
        for row in confirmation_manifest.itertuples(index=False)
    }
    unseen_top10["candidate"] = [
        f"Confirmation {confirmation_rank_by_code[str(code)]:02d}"
        if str(code) in confirmation_rank_by_code
        else ""
        for code in unseen_top10["level_code"]
    ]
    unseen_top10["predicted_validation_score"] = unseen_top10[
        "predicted_validation_score"
    ].map(lambda value: f"{value:.4f}")
    candidate_table = axes[1].table(
        cellText=unseen_top10[
            [
                "prediction_rank",
                "level_code",
                "learning_rate",
                "clip_range",
                "normalized_entropy_coef",
                "gae_lambda",
                "predicted_validation_score",
                "candidate",
            ]
        ].values,
        colLabels=["Rank", "Code", "LR", "Clip", "Entropy", "GAE", "Pred.", "Selected"],
        cellLoc="center",
        colLoc="center",
        bbox=[0.0, 0.18, 1.0, 0.68],
    )
    candidate_table.auto_set_font_size(False)
    candidate_table.set_fontsize(6.7)
    axes[1].set_title("Top 10 unseen additive predictions")
    fig.suptitle("PPO L9 additive prediction and confirmation candidates")
    fig.text(
        0.5,
        0.05,
        "These are additive main-effect predictions only. Final hyperparameters must be selected from actual multi-seed validation results after confirmation.",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.08, 1, 0.95))
    pdf.savefig(fig)
    plt.close(fig)


def _append_diagnostics_page(pdf: PdfPages, run_summary: pd.DataFrame) -> None:
    diagnostics = (
        ("late_normalized_entropy", "Normalized entropy"),
        ("late_effective_action_count", "Effective action count"),
        ("late_approx_kl", "Approx KL"),
        ("late_clip_fraction", "Clip fraction"),
        ("late_value_loss", "Value loss"),
        ("late_explained_variance", "Explained variance"),
        ("late_gradient_norm", "Gradient norm"),
    )
    ordered = run_summary.sort_values("l9_run")
    positions = np.arange(1, 10)
    fig, axes = plt.subplots(2, 4, figsize=(11.7, 8.3))
    for ax, (prefix, label) in zip(axes.flat, diagnostics):
        ax.errorbar(
            positions,
            ordered[f"{prefix}_mean"],
            yerr=ordered[f"{prefix}_seed_std"],
            marker="o",
            capsize=3,
        )
        ax.set_xticks(positions)
        ax.set_xticklabels([f"R{value:02d}" for value in positions], rotation=45)
        ax.set_title(label)
        ax.grid(alpha=0.22)
    axes.flat[-1].axis("off")
    fig.suptitle(
        "PPO training diagnostics across L9 configurations\n"
        "late 20 rollout updates: three-seed mean ± std"
    )
    fig.text(
        0.5,
        0.02,
        "Diagnostics assess policy-update and critic stability; development validation remains the selection criterion.",
        ha="center",
        fontsize=9,
    )
    fig.tight_layout(rect=(0, 0.05, 1, 0.93))
    pdf.savefig(fig)
    plt.close(fig)


def _write_final_hyperparameter_report(
    *,
    l9_run_summary: pd.DataFrame,
    all_run_ranking: pd.DataFrame,
    all_seed_summary: pd.DataFrame,
    level_effects: pd.DataFrame,
    factor_summary: pd.DataFrame,
    l9_validation: pd.DataFrame,
    all_validation: pd.DataFrame,
    confirmation_manifest: pd.DataFrame,
    path: Path,
) -> None:
    winner = all_run_ranking.sort_values("actual_rank").iloc[0]
    selected_id = str(winner["experiment_id"])
    selected_seed_rows = all_seed_summary[
        all_seed_summary["experiment_id"] == selected_id
    ].sort_values("seed")
    selected_validation = all_validation[
        all_validation["experiment_id"] == selected_id
    ]
    if len(selected_seed_rows) != 3 or set(
        selected_seed_rows["seed"].astype(int)
    ) != set(SEEDS):
        raise CascadeSpecError("Selected PPO configuration lacks three seed results.")
    selected_config_path = Path(str(selected_seed_rows.iloc[0]["configuration"]))
    selected_config = _load_yaml(selected_config_path)

    with PdfPages(path) as pdf:
        ranked = all_run_ranking.sort_values(
            "three_seed_mean_best_validation", ascending=True
        ).reset_index(drop=True)
        colors = [
            "#2E8B57"
            if value == selected_id
            else (
                "#ED7D31"
                if str(value).startswith("ppo_1m_confirmation_rank")
                else "#4472C4"
            )
            for value in ranked["experiment_id"]
        ]
        labels = [
            str(value) + (" [SELECTED]" if value == selected_id else "")
            for value in ranked["experiment_id"]
        ]
        positions = np.arange(len(ranked))
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        ax.barh(
            positions,
            ranked["three_seed_mean_best_validation"],
            xerr=ranked["seed_std_best_validation"],
            color=colors,
            capsize=4,
        )
        ax.set_yticks(positions)
        ax.set_yticklabels(labels, fontsize=8)
        ax.set_xlabel("Three-seed mean best validation score (GWh)")
        ax.set_title("PPO final ranking of 12 actually trained configurations")
        ax.grid(axis="x", alpha=0.25)
        ax.margins(x=0.12)
        ax.legend(
            handles=[
                Patch(color="#4472C4", label="L9"),
                Patch(color="#ED7D31", label="Confirmation"),
                Patch(color="#2E8B57", label="Selected actual best"),
            ],
            loc="lower right",
        )
        for position, mean, std in zip(
            positions,
            ranked["three_seed_mean_best_validation"],
            ranked["seed_std_best_validation"],
            strict=True,
        ):
            ax.text(float(mean + std), position, f"  {mean:.3f}", va="center", fontsize=7)
        fig.tight_layout()
        pdf.savefig(fig)
        plt.close(fig)

        _append_effect_and_validation_pages(pdf, level_effects, l9_validation)

        manifest = confirmation_manifest.sort_values("confirmation_rank")
        indexed = all_run_ranking.set_index("experiment_id")
        confirmation_ids = manifest["experiment_id"].astype(str).tolist()
        missing = set(confirmation_ids) - set(indexed.index)
        if missing:
            raise CascadeSpecError(
                f"Actual confirmation results are missing: {sorted(missing)}"
            )
        actual = indexed.loc[confirmation_ids]
        predicted = manifest["predicted_validation_score"].to_numpy(dtype=float)
        actual_mean = actual["three_seed_mean_best_validation"].to_numpy(dtype=float)
        actual_std = actual["seed_std_best_validation"].to_numpy(dtype=float)
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        positions = np.arange(3)
        width = 0.36
        ax.bar(
            positions - width / 2,
            predicted,
            width,
            color="#A5A5A5",
            label="Additive L9 prediction",
        )
        ax.bar(
            positions + width / 2,
            actual_mean,
            width,
            yerr=actual_std,
            capsize=5,
            color="#ED7D31",
            label="Actual confirmation mean ± std",
        )
        ax.set_xticks(positions)
        ax.set_xticklabels(
            [
                f"Confirmation {int(rank):02d}\n{code}"
                for rank, code in zip(
                    manifest["confirmation_rank"],
                    manifest["level_code"],
                    strict=True,
                )
            ]
        )
        ax.set_ylabel("Validation score (GWh)")
        ax.set_title("Additive Top3 predictions versus actual confirmation results")
        ax.grid(axis="y", alpha=0.25)
        ax.legend()
        lower = float(min(predicted.min(), (actual_mean - actual_std).min()))
        upper = float(max(predicted.max(), (actual_mean + actual_std).max()))
        padding = max((upper - lower) * 0.2, 1.0)
        ax.set_ylim(lower - padding, upper + padding)
        fig.text(
            0.5,
            0.02,
            "Final selection uses the actual 12-configuration ranking, not the additive prediction.",
            ha="center",
            fontsize=9,
        )
        fig.tight_layout(rect=(0, 0.04, 1, 1))
        pdf.savefig(fig)
        plt.close(fig)

        pivot = selected_validation.pivot(
            index="environment_steps", columns="seed", values="score"
        ).sort_index()
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        colors_by_seed = {1: "#4472C4", 42: "#ED7D31", 100: "#70AD47"}
        for seed in SEEDS:
            ax.plot(
                pivot.index,
                pivot[seed],
                color=colors_by_seed[seed],
                alpha=0.65,
                label=f"seed {seed}",
            )
            seed_row = selected_seed_rows[selected_seed_rows["seed"] == seed].iloc[0]
            ax.scatter(
                [seed_row["best_validation_step"]],
                [seed_row["best_validation_score"]],
                marker="*",
                s=150,
                color=colors_by_seed[seed],
                edgecolor="black",
                linewidth=0.5,
                zorder=5,
            )
        mean = pivot.mean(axis=1)
        std = pivot.std(axis=1)
        x = mean.index.to_numpy(dtype=float)
        y = mean.to_numpy(dtype=float)
        spread = std.to_numpy(dtype=float)
        ax.plot(x, y, color="black", linewidth=2.5, label="three-seed mean")
        ax.fill_between(x, y - spread, y + spread, color="black", alpha=0.12, label="mean ± std")
        ax.set_xlabel("Environment interactions")
        ax.set_ylabel("Validation score (GWh)")
        ax.set_title(f"Selected actual configuration validation: {selected_id}")
        ax.grid(alpha=0.25)
        ax.legend(ncol=2)
        fig.text(
            0.5,
            0.02,
            "Stars are each seed's best-validation checkpoint; 720000 interactions equal 3000 logical windows.",
            ha="center",
            fontsize=9,
        )
        fig.tight_layout(rect=(0, 0.04, 1, 1))
        pdf.savefig(fig)
        plt.close(fig)

        diagnostic_fields = (
            ("late_normalized_entropy_mean", "Normalized entropy"),
            ("late_effective_action_count_mean", "Effective action count"),
            ("late_approx_kl_mean", "Approx KL"),
            ("late_clip_fraction_mean", "Clip fraction"),
            ("late_value_loss_mean", "Value loss"),
            ("late_explained_variance_mean", "Explained variance"),
            ("late_gradient_norm_mean", "Gradient norm"),
        )
        fig, axes = plt.subplots(2, 4, figsize=(11.7, 8.3))
        positions = np.arange(3)
        for ax, (field, label) in zip(axes.flat, diagnostic_fields):
            ax.bar(
                positions,
                selected_seed_rows[field],
                color=[colors_by_seed[seed] for seed in SEEDS],
            )
            ax.set_xticks(positions)
            ax.set_xticklabels(["seed 1", "seed 42", "seed 100"], rotation=25)
            ax.set_title(label)
            ax.grid(axis="y", alpha=0.22)
        axes.flat[-1].axis("off")
        fig.suptitle(
            f"Selected PPO training diagnostics: {selected_id}\n"
            "late 20 rollout-update means"
        )
        fig.text(
            0.5,
            0.02,
            "Entropy, KL, clipping, critic and gradient diagnostics support stability review; validation determines selection.",
            ha="center",
            fontsize=9,
        )
        fig.tight_layout(rect=(0, 0.05, 1, 0.93))
        pdf.savefig(fig)
        plt.close(fig)

        ppo = _mapping(selected_config, "ppo")
        network = _mapping(selected_config, "network")
        training = _mapping(selected_config, "training")
        table_rows = [
            ("Selected configuration", selected_id),
            ("Selection basis", "actual 3-seed mean best validation among 12 configurations"),
            ("Action discretization / count", "1 m / 3600"),
            ("State dimension", "5"),
            ("Actor hidden dimensions", str(list(network["actor_hidden_dimensions"]))),
            ("Critic hidden dimensions", str(list(network["critic_hidden_dimensions"]))),
            ("Learning rate", str(ppo["learning_rate"])),
            ("Clip range", str(ppo["clip_range"])),
            ("Normalized entropy coefficient", str(ppo["normalized_entropy_coefficient"])),
            ("GAE lambda", str(ppo["gae_lambda"])),
            ("Gamma", str(ppo["gamma"])),
            ("Num envs / n_steps", f"{training['num_envs']} / {training['n_steps']}"),
            ("Rollout batch / minibatch", "1920 / 320"),
            ("Update epochs / optimizer steps", f"{ppo['update_epochs']} / 60 per rollout"),
            ("Value coefficient / max grad norm", f"{ppo['value_loss_coefficient']} / {ppo['max_gradient_norm']}"),
            ("Development interactions", str(training["total_environment_steps"])),
            ("Development seeds", "1 / 42 / 100"),
            ("Final budget status", "not yet frozen; inspect selected validation convergence"),
        ]
        fig, ax = plt.subplots(figsize=(11.7, 8.3))
        ax.axis("off")
        ax.set_title("Final selected PPO hyperparameters", fontsize=16, pad=18)
        table = ax.table(
            cellText=table_rows,
            colLabels=["Item", "Selected value"],
            cellLoc="left",
            colLoc="left",
            bbox=[0.04, 0.10, 0.92, 0.80],
            colWidths=[0.40, 0.60],
        )
        table.auto_set_font_size(False)
        table.set_fontsize(8.5)
        ax.text(
            0.5,
            0.04,
            f"Actual validation: {winner['three_seed_mean_best_validation']:.6f} ± {winner['seed_std_best_validation']:.6f} GWh",
            ha="center",
            fontsize=10,
            weight="bold",
        )
        pdf.savefig(fig)
        plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Analyze completed formal 1 m PPO L9 results and generate the "
            "three highest-ranked unseen confirmation configurations."
        )
    )
    parser.add_argument(
        "--config-dir",
        default=str(DEFAULT_CONFIG_DIR),
    )
    parser.add_argument(
        "--output-root",
        default=str(DEFAULT_OUTPUT_ROOT),
    )
    parser.add_argument(
        "--analysis-dir",
        default=str(DEFAULT_OUTPUT_ROOT / "analysis"),
    )
    parser.add_argument(
        "--include-confirmations",
        action="store_true",
        help="Also rank the three completed generated confirmation configurations.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config_dir = Path(args.config_dir).resolve()
    output_root = Path(args.output_root).resolve()
    analysis_dir = Path(args.analysis_dir).resolve()
    analysis_dir.mkdir(parents=True, exist_ok=True)

    configurations = _validate_l9_configs(config_dir)
    seed_summary, validation_history = _read_actual_runs(
        configurations, output_root
    )
    annotated = _annotate_l9(seed_summary)
    run_summary = _annotate_l9_run_summary(_run_summary(seed_summary))
    level_effects, factor_summary = _main_effects(annotated)
    predictions = _predictions(annotated, level_effects)
    unseen = predictions[~predictions["already_tested_in_l9"]].head(3)
    generated_dir = analysis_dir / "generated_confirmation_configs"
    confirmation_manifest = _write_confirmation_configs(
        configurations[0][1], unseen, generated_dir
    )

    annotated.to_csv(analysis_dir / "l9_seed_summary.csv", index=False)
    run_summary.to_csv(analysis_dir / "l9_run_ranking.csv", index=False)
    run_summary.to_csv(analysis_dir / "ppo_l9_run_ranking.csv", index=False)
    level_effects.to_csv(
        analysis_dir / "l9_factor_level_effects.csv", index=False
    )
    level_effects.to_csv(
        analysis_dir / "ppo_l9_factor_level_effects.csv", index=False
    )
    factor_summary.to_csv(analysis_dir / "l9_factor_summary.csv", index=False)
    factor_summary.to_csv(
        analysis_dir / "ppo_l9_factor_summary.csv", index=False
    )
    predictions.to_csv(analysis_dir / "l9_all_81_predictions.csv", index=False)
    predictions.to_csv(
        analysis_dir / "ppo_l9_all_81_predictions.csv", index=False
    )
    unseen.to_csv(analysis_dir / "l9_top3_unseen_predictions.csv", index=False)
    unseen.to_csv(
        analysis_dir / "ppo_l9_top3_unseen_predictions.csv", index=False
    )
    confirmation_manifest.to_csv(
        analysis_dir / "confirmation_manifest.csv", index=False
    )
    run_summary.to_csv(
        analysis_dir / "ppo_l9_training_diagnostics_summary.csv", index=False
    )
    validation_history.to_csv(
        analysis_dir / "l9_validation_history.csv", index=False
    )
    _write_report(
        run_summary,
        level_effects,
        factor_summary,
        predictions,
        confirmation_manifest,
        validation_history,
        analysis_dir / "l9_report.pdf",
    )

    print("PPO L9 analysis completed.")
    print(f"Analysis directory: {analysis_dir}")
    print("L9 ranking:")
    print(
        run_summary[
            [
                "l9_run",
                "experiment_id",
                "three_seed_mean_best_validation",
                "seed_std_best_validation",
            ]
        ].to_string(index=False)
    )
    print("Top three unseen additive-main-effect predictions:")
    print(
        confirmation_manifest[
            [
                "confirmation_rank",
                "experiment_id",
                "level_code",
                "predicted_validation_score",
                "configuration",
            ]
        ].to_string(index=False)
    )

    if args.include_confirmations:
        confirmation_configurations: list[tuple[Path, dict[str, Any]]] = []
        for rank in range(1, 4):
            path = generated_dir / f"confirmation_rank{rank:02d}.yaml"
            if not path.is_file():
                raise FileNotFoundError(
                    f"Missing generated confirmation configuration: {path}"
                )
            confirmation_configurations.append((path, _load_yaml(path)))
        confirmation_seed_summary, confirmation_validation = _read_actual_runs(
            confirmation_configurations,
            output_root,
        )
        all_seed_summary = pd.concat(
            [seed_summary, confirmation_seed_summary],
            ignore_index=True,
        )
        all_validation_history = pd.concat(
            [validation_history, confirmation_validation],
            ignore_index=True,
        )
        all_run_ranking = _run_summary(all_seed_summary)
        all_seed_summary.to_csv(
            analysis_dir / "all_12_seed_summary.csv",
            index=False,
        )
        all_run_ranking.to_csv(
            analysis_dir / "all_12_actual_ranking.csv",
            index=False,
        )
        all_validation_history.to_csv(
            analysis_dir / "all_12_validation_history.csv",
            index=False,
        )
        final_report_path = (
            analysis_dir / "ppo_1m_final_hyperparameter_report.pdf"
        )
        _write_final_hyperparameter_report(
            l9_run_summary=run_summary,
            all_run_ranking=all_run_ranking,
            all_seed_summary=all_seed_summary,
            level_effects=level_effects,
            factor_summary=factor_summary,
            l9_validation=validation_history,
            all_validation=all_validation_history,
            confirmation_manifest=confirmation_manifest,
            path=final_report_path,
        )
        print("Actual ranking across all 12 completed configurations:")
        print(
            all_run_ranking[
                [
                    "experiment_id",
                    "three_seed_mean_best_validation",
                    "seed_std_best_validation",
                ]
            ].to_string(index=False)
        )
        print(f"Final PPO hyperparameter report: {final_report_path}")


if __name__ == "__main__":
    main()
