"""Summarize the V11 action-conditioned PPO learning-rate pilot."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
OUTPUT_ROOT = (
    ROOT
    / "outputs"
    / "xiaowan_nuozhadu"
    / "ppo_1m_v11_action_conditioned_lr_pilot_lambda4000"
)
EXPERIMENTS = (
    (3.0e-5, "ppo_1m_v11_action_conditioned_lr3em05_lambda4000_pilot"),
    (1.0e-4, "ppo_1m_v11_action_conditioned_lr1em04_lambda4000_pilot"),
    (3.0e-4, "ppo_1m_v11_action_conditioned_lr3em04_lambda4000_pilot"),
)
SEED = 42


def main() -> None:
    rows: list[dict[str, float | int | str]] = []
    for learning_rate, experiment_id in EXPERIMENTS:
        run_root = (
            OUTPUT_ROOT
            / "experiments"
            / experiment_id
            / f"seed_{SEED}"
            / "development"
        )
        history_path = run_root / "training" / "history.csv"
        validation_path = run_root / "validation" / "validation_monthly.csv"
        summary_path = validation_path.with_suffix(".json")
        metadata_path = run_root / "metadata.json"
        required = (history_path, validation_path, summary_path, metadata_path)
        missing = [str(path) for path in required if not path.is_file()]
        if missing:
            raise FileNotFoundError(
                f"Incomplete pilot {experiment_id}; missing: {missing}"
            )

        history = pd.read_csv(history_path)
        trajectory = pd.read_csv(validation_path)
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        reliability = summary["firm_power_reliability"]
        final = history.iloc[-1]
        rows.append(
            {
                "learning_rate": learning_rate,
                "best_validation_step": int(metadata["best_validation_step"]),
                "best_validation_score_twh_per_year": (
                    float(metadata["best_validation_score"]) / 1000.0
                ),
                "validation_generation_twh_per_year": (
                    float(summary["mean_annual_cascade_generation_gwh"]) / 1000.0
                ),
                "xiaowan_reliability_pct": 100.0 * float(reliability["xiaowan"]),
                "nuozhadu_reliability_pct": 100.0 * float(reliability["nuozhadu"]),
                "failed_station_months": int(summary["failed_station_months"]),
                "xiaowan_mean_level_m": float(trajectory["r1_end_level_m"].mean()),
                "nuozhadu_mean_level_m": float(trajectory["r2_end_level_m"].mean()),
                "final_approx_kl": float(final["approx_kl"]),
                "final_clip_fraction": float(final["clip_fraction"]),
                "final_normalized_entropy": float(final["normalized_entropy"]),
                "final_explained_variance": float(final["explained_variance"]),
            }
        )

    frame = pd.DataFrame(rows).sort_values("learning_rate")
    analysis_dir = OUTPUT_ROOT / "analysis"
    analysis_dir.mkdir(parents=True, exist_ok=True)
    output_path = analysis_dir / "ppo_action_conditioned_lr_pilot_summary.csv"
    frame.to_csv(output_path, index=False, float_format="%.6f")
    with pd.option_context("display.max_columns", None, "display.width", 240):
        print(frame.to_string(index=False))
    print(f"Wrote: {output_path}")


if __name__ == "__main__":
    main()
